import { createTRPCReact } from "@trpc/react-query";
import { httpBatchLink } from "@trpc/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import superjson from "superjson";
import type { AppRouter } from "../../api/router";
import type { ReactNode } from "react";
import { apiUrl } from "@/lib/apiBase";

export const trpc = createTRPCReact<AppRouter>();

const queryClient = new QueryClient();
const trpcClient = trpc.createClient({
  links: [
    httpBatchLink({
      // 后端地址优先级：页面「服务器设置」中用户填写的地址（localStorage）
      // > 构建期环境变量 VITE_API_URL > 同源 /api/trpc。
      // 这样静态包只需打一次，后端地址在页面上随时改。
      url:
        apiUrl("/api/trpc") !== "/api/trpc"
          ? apiUrl("/api/trpc")
          : import.meta.env.VITE_API_URL
            ? `${import.meta.env.VITE_API_URL}/api/trpc`
            : "/api/trpc",
      transformer: superjson,
      fetch(input, init) {
        return globalThis.fetch(input, {
          ...(init ?? {}),
          credentials: "include",
        });
      },
    }),
  ],
});

export function TRPCProvider({ children }: { children: ReactNode }) {
  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        {children}
      </QueryClientProvider>
    </trpc.Provider>
  );
}
