import { useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import type { Variants } from 'framer-motion'
import {
  AudioLines,
  Check,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  LogOut,
  Mic,
  Play,
  Radio,
  RefreshCw,
  Square,
  TriangleAlert,
  User,
  XCircle,
  Zap,
} from 'lucide-react'
import { toast } from 'sonner'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { cn } from '@/lib/utils'
import { Toaster } from '@/components/ui/sonner'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'

/* ---------------- 常量 ---------------- */

const TOKEN_QUOTA = 500_000

const MODELS = [
  { value: 'kimi-k2.6', name: 'kimi-k2.6', desc: '均衡表现 · 性价比之选' },
  { value: 'kimi-k3', name: 'kimi-k3', desc: '最新旗舰 · 话术更生动' },
]

const VOICES = [
  { value: 'zh-CN-XiaoxiaoNeural', name: '晨曦', desc: '亲切女声 · 活泼自然（默认）' },
  { value: 'zh-CN-YunjianNeural', name: '云舟', desc: '沉稳男声 · 专业可信' },
  { value: 'zh-CN-XiaoyiNeural', name: '小满', desc: '元气少女 · 适合美妆零食' },
  { value: 'zh-CN-YunxiNeural', name: '老白', desc: '醇厚大叔 · 适合酒水茶器' },
]

const DEFAULT_WELCOME =
  '欢迎 {观众昵称} 来到直播间！我是 {主播名}，今天给大家准备了超多福利～'
const DEFAULT_PREVIEW_TEXT = '家人们晚上好！欢迎来到直播间，今天给大家带来一款超值好物～'

const SECTIONS = [
  { id: 'kimi', label: 'Kimi API 配置', icon: Zap },
  { id: 'tts', label: 'TTS 语音配置', icon: Mic },
  { id: 'room', label: '直播间信息', icon: Radio },
  { id: 'account', label: '账号与安全', icon: User },
] as const

type SectionId = (typeof SECTIONS)[number]['id']

/* ---------------- 通用小部件 ---------------- */

const inputCls =
  'h-[38px] w-full rounded-[10px] border border-line bg-ink-input px-3 text-sm text-fg placeholder:text-fg-tertiary outline-none transition-all focus:border-brand focus:shadow-[0_0_0_3px_rgba(108,92,231,0.15)]'

const fieldItem: Variants = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: { duration: 0.3, ease: [0.16, 1, 0.3, 1] } },
}

function Field({
  label,
  required,
  hint,
  extra,
  children,
}: {
  label: string
  required?: boolean
  hint?: string
  extra?: ReactNode
  children: ReactNode
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <label className="text-[13px] font-medium text-fg">
          {label}
          {required && <span className="ml-0.5 text-live">*</span>}
        </label>
        {extra}
      </div>
      {children}
      {hint && <p className="mt-1.5 text-xs text-fg-tertiary">{hint}</p>}
    </div>
  )
}

function SectionCard({
  icon: Icon,
  title,
  desc,
  dirty,
  saving,
  onReset,
  onSave,
  children,
}: {
  icon: typeof Zap
  title: string
  desc: string
  dirty?: boolean
  saving?: boolean
  onReset?: () => void
  onSave?: () => void
  children: ReactNode
}) {
  return (
    <motion.section
      variants={{ hidden: {}, show: { transition: { staggerChildren: 0.04 } } }}
      initial="hidden"
      animate="show"
      className="rounded-[14px] border border-line bg-ink-card p-5 card-shadow"
    >
      <motion.div variants={fieldItem} className="flex items-start gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] bg-brand-soft text-brand-hover">
          <Icon className="h-[18px] w-[18px]" />
        </div>
        <div>
          <h2 className="text-[17px] font-semibold leading-[26px] text-fg">{title}</h2>
          <p className="mt-0.5 text-sm text-fg-secondary">{desc}</p>
        </div>
      </motion.div>

      <div className="mt-5 space-y-5">{children}</div>

      {onSave && (
        <motion.div
          variants={fieldItem}
          className="mt-6 flex items-center justify-end gap-3 border-t border-line pt-4"
        >
          <button
            type="button"
            onClick={onReset}
            disabled={!dirty || saving}
            className="h-[38px] rounded-[10px] px-4 text-sm font-medium text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg disabled:cursor-not-allowed disabled:opacity-40"
          >
            重置
          </button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={onSave}
            disabled={!dirty || saving}
            animate={
              dirty && !saving
                ? { boxShadow: ['0 0 0px rgba(108,92,231,0)', '0 0 20px rgba(108,92,231,0.35)', '0 0 0px rgba(108,92,231,0)'] }
                : { boxShadow: '0 0 0px rgba(108,92,231,0)' }
            }
            transition={
              dirty && !saving ? { duration: 1.6, repeat: Infinity } : { duration: 0.3 }
            }
            className="flex h-[38px] items-center gap-2 rounded-[10px] px-[18px] text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-50"
            style={{ background: 'var(--accent-gradient)' }}
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            保存更改
          </motion.button>
        </motion.div>
      )}
    </motion.section>
  )
}

/** 数值滑块（标签 + 数值气泡） */
function ValueSlider({
  label,
  value,
  min,
  max,
  step,
  format,
  onChange,
}: {
  label: string
  value: number
  min: number
  max: number
  step: number
  format: (v: number) => string
  onChange: (v: number) => void
}) {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <label className="text-[13px] font-medium text-fg">{label}</label>
        <motion.span
          key={value}
          initial={{ scale: 0.8, y: 4 }}
          animate={{ scale: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 260, damping: 24 }}
          className="rounded-[6px] bg-brand-soft px-2 py-0.5 font-mono text-xs text-brand-hover"
        >
          {format(value)}
        </motion.span>
      </div>
      <Slider
        value={[value]}
        min={min}
        max={max}
        step={step}
        onValueChange={(v) => onChange(v[0] ?? value)}
      />
      <div className="mt-1 flex justify-between font-mono text-[10px] text-fg-tertiary">
        <span>{format(min)}</span>
        <span>{format(max)}</span>
      </div>
    </div>
  )
}

/** Kimi Token 用量条 */
function TokenMeter({ used, total }: { used: number; total: number }) {
  const pct = Math.min(100, Math.round((used / total) * 100))
  const color =
    pct > 90 ? 'var(--danger)' : pct > 70 ? 'var(--warning)' : undefined
  return (
    <div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-[rgba(30,36,48,0.12)]">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="h-full rounded-full"
          style={{ background: color ?? 'var(--accent-gradient)' }}
        />
      </div>
      <div className="mt-1.5 flex items-center justify-between">
        <span className="font-mono text-xs text-fg-secondary">
          {used.toLocaleString()} / {total.toLocaleString()} tokens
        </span>
        <span
          className="font-mono text-xs"
          style={{ color: pct > 90 ? 'var(--danger)' : pct > 70 ? 'var(--warning)' : 'var(--text-tertiary)' }}
        >
          {pct}%
        </span>
      </div>
    </div>
  )
}

/* ======================================================================
 * 主页面
 * ==================================================================== */

export default function Settings() {
  const { user, isLoading: authLoading, logout } = useAuth()
  const settingsQuery = trpc.settings.get.useQuery()
  const statsQuery = trpc.dashboard.stats.useQuery()
  const utils = trpc.useUtils()

  /* ---- 表单状态 ---- */
  const [baseUrl, setBaseUrl] = useState('')
  const [keyInput, setKeyInput] = useState('')
  const [keyEditing, setKeyEditing] = useState(false)
  const [showKey, setShowKey] = useState(false)
  const [model, setModel] = useState('kimi-k2.6')
  const [temperature, setTemperature] = useState(0.8)

  const [voice, setVoice] = useState(VOICES[0].value)
  const [rate, setRate] = useState(1.0)
  const [previewText, setPreviewText] = useState(DEFAULT_PREVIEW_TEXT)
  const [previewing, setPreviewing] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const [hostName, setHostName] = useState('')
  const [welcome, setWelcome] = useState('')
  const welcomeRef = useRef<HTMLTextAreaElement | null>(null)

  const [testResult, setTestResult] = useState<
    { ok: true; message: string } | { ok: false; message: string } | null
  >(null)
  const [activeSection, setActiveSection] = useState<SectionId>('kimi')
  const sectionRefs = useRef<Record<string, HTMLDivElement | null>>({})

  const s = settingsQuery.data

  /* 服务端数据 → 本地表单（仅首次 / 保存后回同步） */
  useEffect(() => {
    if (!s) return
    setBaseUrl(s.kimiBaseUrl)
    setModel(s.kimiModel)
    setTemperature(Number(s.temperature))
    setVoice(s.ttsVoice)
    setRate(Number(s.ttsRate))
    setHostName(s.hostName ?? '小播')
    setWelcome(s.welcomeTemplate ?? DEFAULT_WELCOME)
    setKeyInput('')
    setKeyEditing(false)
  }, [s])

  useEffect(
    () => () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current = null
      }
    },
    [],
  )

  /* scroll-spy */
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActiveSection(e.target.id as SectionId)
        }
      },
      { rootMargin: '-80px 0px -60% 0px' },
    )
    for (const id of Object.keys(sectionRefs.current)) {
      const el = sectionRefs.current[id]
      if (el) observer.observe(el)
    }
    return () => observer.disconnect()
  }, [settingsQuery.isLoading])

  /* ---- 脏状态 ---- */
  const kimiDirty = useMemo(() => {
    if (!s) return false
    return (
      baseUrl !== s.kimiBaseUrl ||
      model !== s.kimiModel ||
      Math.abs(temperature - Number(s.temperature)) > 1e-9 ||
      (keyEditing && keyInput.trim().length > 0)
    )
  }, [s, baseUrl, model, temperature, keyEditing, keyInput])

  const ttsDirty = useMemo(() => {
    if (!s) return false
    return voice !== s.ttsVoice || Math.abs(rate - Number(s.ttsRate)) > 1e-9
  }, [s, voice, rate])

  const roomDirty = useMemo(() => {
    if (!s) return false
    return hostName !== (s.hostName ?? '小播') || welcome !== (s.welcomeTemplate ?? DEFAULT_WELCOME)
  }, [s, hostName, welcome])

  const anyDirty = kimiDirty || ttsDirty || roomDirty

  /* ---- 变更 ---- */
  const updateMutation = trpc.settings.update.useMutation({
    onSuccess: async () => {
      toast.success('设置已保存')
      await utils.settings.get.invalidate()
    },
    onError: (e) => toast.error(e.message),
  })

  const testMutation = trpc.settings.testConnection.useMutation({
    onSuccess: (res) => {
      setTestResult({ ok: true, message: res.message })
      toast.success('连接正常')
    },
    onError: (e) => {
      setTestResult({ ok: false, message: e.message })
      toast.error('连接失败')
    },
  })

  const saveKimi = () => {
    updateMutation.mutate({
      kimiBaseUrl: baseUrl.trim() || undefined,
      kimiModel: model,
      temperature,
      ...(keyEditing && keyInput.trim() ? { kimiApiKey: keyInput.trim() } : {}),
    })
  }
  const resetKimi = () => {
    if (!s) return
    setBaseUrl(s.kimiBaseUrl)
    setModel(s.kimiModel)
    setTemperature(Number(s.temperature))
    setKeyInput('')
    setKeyEditing(false)
  }

  const saveTts = () => updateMutation.mutate({ ttsVoice: voice, ttsRate: rate })
  const resetTts = () => {
    if (!s) return
    setVoice(s.ttsVoice)
    setRate(Number(s.ttsRate))
  }

  const saveRoom = () =>
    updateMutation.mutate({ hostName: hostName.trim(), welcomeTemplate: welcome })
  const resetRoom = () => {
    if (!s) return
    setHostName(s.hostName ?? '小播')
    setWelcome(s.welcomeTemplate ?? DEFAULT_WELCOME)
  }

  /* 试听（真实 TTS：调用后端 Edge TTS 合成并播放） */
  const ttsPreview = trpc.tts.preview.useMutation()

  const stopPreview = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current = null
    }
    setPreviewing(null)
  }

  const togglePreview = (id: string, text: string, voiceId: string) => {
    if (previewing === id) {
      stopPreview()
      return
    }
    stopPreview()
    const trimmed = text.trim()
    if (!trimmed) {
      toast.warning('请先输入试听文本')
      return
    }
    setPreviewing(id)
    ttsPreview.mutate(
      { text: trimmed.slice(0, 300), voice: voiceId, rate },
      {
        onSuccess: (res) => {
          const audio = new Audio(`data:${res.mime};base64,${res.audioBase64}`)
          audioRef.current = audio
          audio.onended = () => {
            audioRef.current = null
            setPreviewing((p) => (p === id ? null : p))
          }
          audio.onerror = () => {
            audioRef.current = null
            setPreviewing(null)
            toast.error('音频播放失败')
          }
          audio.play().catch(() => {
            audioRef.current = null
            setPreviewing(null)
            toast.error('浏览器阻止了播放，请再点击一次')
          })
        },
        onError: (e) => {
          setPreviewing(null)
          toast.error(e.message)
        },
      },
    )
  }

  /* 变量插入（光标处） */
  const insertVar = (v: string) => {
    const el = welcomeRef.current
    if (!el) {
      setWelcome((w) => w + v)
      return
    }
    const start = el.selectionStart ?? welcome.length
    const end = el.selectionEnd ?? welcome.length
    const next = welcome.slice(0, start) + v + welcome.slice(end)
    setWelcome(next)
    requestAnimationFrame(() => {
      el.focus()
      const pos = start + v.length
      el.setSelectionRange(pos, pos)
    })
  }

  const scrollTo = (id: SectionId) => {
    sectionRefs.current[id]?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  const tokensUsed = statsQuery.data?.totalTokensUsed ?? 0
  const scriptCount = statsQuery.data?.scriptCount ?? 0
  const avgTokens = scriptCount > 0 ? Math.round(tokensUsed / scriptCount) : 0

  /* ---- 渲染 ---- */
  return (
    <div className="mx-auto max-w-[1560px] p-6 lg:p-8">
      <Toaster theme="light" position="top-right" />

      {/* 页头 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      >
        <h1 className="text-2xl font-bold leading-8 text-fg">设置中心</h1>
        <p className="mt-1 text-[13px] text-fg-tertiary">
          密钥脱敏展示 · 改动即时校验 · 保存有反馈
        </p>
      </motion.div>

      {/* 未保存提示条 */}
      <AnimatePresence>
        {anyDirty && (
          <motion.div
            initial={{ y: -8, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -8, opacity: 0 }}
            className="sticky top-[72px] z-30 mt-4 flex items-center gap-2 rounded-[10px] border border-[rgba(251,191,36,0.3)] bg-[rgba(251,191,36,0.08)] px-4 py-2.5 text-[13px] text-warn backdrop-blur"
          >
            <TriangleAlert className="h-4 w-4" />
            有未保存的更改
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[200px_1fr]">
        {/* 锚点导航（桌面粘性） */}
        <nav className="hidden lg:block">
          <div className="sticky top-[84px] space-y-1">
            {SECTIONS.map((sec) => (
              <button
                key={sec.id}
                type="button"
                onClick={() => scrollTo(sec.id)}
                className={cn(
                  'relative flex h-10 w-full items-center gap-2.5 rounded-[10px] px-3 text-sm transition-colors',
                  activeSection === sec.id
                    ? 'bg-brand-soft font-medium text-brand-hover'
                    : 'text-fg-secondary hover:bg-ink-hover hover:text-fg',
                )}
              >
                {activeSection === sec.id && (
                  <motion.span
                    layoutId="settings-nav-indicator"
                    className="absolute left-0 top-1/2 h-4 w-[3px] -translate-y-1/2 rounded-full bg-brand"
                    transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                  />
                )}
                <sec.icon className="h-4 w-4" />
                {sec.label}
              </button>
            ))}
          </div>
        </nav>

        {/* 移动端横向 Tabs */}
        <div className="flex gap-1 overflow-x-auto border-b border-line lg:hidden">
          {SECTIONS.map((sec) => (
            <button
              key={sec.id}
              type="button"
              onClick={() => scrollTo(sec.id)}
              className={cn(
                'relative shrink-0 px-3 pb-2.5 pt-1 text-sm font-medium transition-colors',
                activeSection === sec.id ? 'text-brand-hover' : 'text-fg-secondary',
              )}
            >
              {sec.label}
              {activeSection === sec.id && (
                <motion.span
                  layoutId="settings-tab-indicator"
                  className="absolute inset-x-2 bottom-0 h-0.5 rounded-full bg-brand"
                  transition={{ duration: 0.25 }}
                />
              )}
            </button>
          ))}
        </div>

        {/* 表单区 */}
        <div className="w-full max-w-[720px] space-y-6">
          {/* ============ Kimi API 配置 ============ */}
          <div
            id="kimi"
            ref={(el) => {
              sectionRefs.current.kimi = el
            }}
            className="scroll-mt-[84px]"
          >
            <SectionCard
              icon={Zap}
              title="Kimi API 配置"
              desc="中控台通过你的 Kimi API Key 生成直播话术，Key 仅存储在本地服务器并加密保存。"
              dirty={kimiDirty}
              saving={updateMutation.isPending}
              onReset={resetKimi}
              onSave={saveKimi}
            >
              {/* API Key */}
              <motion.div variants={fieldItem}>
                <Field
                  label="API Key"
                  required
                  extra={
                    keyEditing ? undefined : (
                      <button
                        type="button"
                        onClick={() => {
                          setKeyEditing(true)
                          setKeyInput('')
                        }}
                        className="text-xs font-medium text-brand-hover transition-colors hover:text-brand"
                      >
                        更换
                      </button>
                    )
                  }
                >
                  <div className="relative">
                    <input
                      type={showKey ? 'text' : 'password'}
                      value={keyEditing ? keyInput : (s?.kimiApiKey ?? '')}
                      onChange={(e) => setKeyInput(e.target.value)}
                      readOnly={!keyEditing}
                      placeholder={s?.hasKey ? '' : 'sk-…'}
                      className={cn(
                        inputCls,
                        'pr-10 font-mono',
                        !keyEditing && 'cursor-default text-fg-secondary',
                      )}
                    />
                    <button
                      type="button"
                      onClick={() => setShowKey((v) => !v)}
                      className="absolute right-2 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-[8px] text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg"
                      aria-label={showKey ? '隐藏 Key' : '查看 Key'}
                    >
                      {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {keyEditing && (
                    <p className="mt-1.5 flex items-center gap-1 text-xs text-warn">
                      <TriangleAlert className="h-3 w-3" />
                      新 Key 保存后建议先测试连接
                    </p>
                  )}
                </Field>
              </motion.div>

              {/* Base URL */}
              <motion.div variants={fieldItem}>
                <Field label="Base URL" hint="一般无需修改">
                  <input
                    value={baseUrl}
                    onChange={(e) => setBaseUrl(e.target.value)}
                    placeholder="https://api.moonshot.cn/v1"
                    className={cn(inputCls, 'font-mono')}
                  />
                </Field>
              </motion.div>

              {/* 默认模型 */}
              <motion.div variants={fieldItem}>
                <Field label="默认模型">
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {MODELS.map((m) => (
                      <button
                        key={m.value}
                        type="button"
                        onClick={() => setModel(m.value)}
                        className={cn(
                          'rounded-[10px] border p-3 text-left transition-all',
                          model === m.value
                            ? 'border-brand bg-brand-soft'
                            : 'border-line bg-ink-input hover:border-line-strong',
                        )}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-sm font-medium text-fg">{m.name}</span>
                          {model === m.value && <Check className="h-4 w-4 text-brand-hover" />}
                        </div>
                        <p className="mt-1 text-xs text-fg-tertiary">{m.desc}</p>
                      </button>
                    ))}
                  </div>
                </Field>
              </motion.div>

              {/* 温度 */}
              <motion.div variants={fieldItem}>
                <ValueSlider
                  label="创意温度"
                  value={temperature}
                  min={0}
                  max={1}
                  step={0.05}
                  format={(v) => v.toFixed(2)}
                  onChange={setTemperature}
                />
              </motion.div>

              {/* 连接测试 */}
              <motion.div variants={fieldItem}>
                <div className="flex items-center gap-3">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => {
                      setTestResult(null)
                      testMutation.mutate()
                    }}
                    disabled={testMutation.isPending}
                    className="flex h-[38px] items-center gap-2 rounded-[10px] border border-line-strong bg-ink-hover px-4 text-sm font-medium text-fg transition-colors hover:border-fg-tertiary/40 disabled:opacity-60"
                  >
                    {testMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Zap className="h-4 w-4" />
                    )}
                    {testMutation.isPending ? '测试中…' : '测试连接'}
                  </motion.button>
                  {!s?.hasKey && (
                    <span className="text-xs text-fg-tertiary">
                      尚未配置 API Key，请先填写并保存后再测试
                    </span>
                  )}
                </div>
                <AnimatePresence>
                  {testResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={cn(
                        'mt-3 flex items-start gap-2.5 rounded-[10px] border p-3',
                        testResult.ok
                          ? 'border-[rgba(52,211,153,0.3)] bg-[rgba(52,211,153,0.08)]'
                          : 'border-[rgba(248,113,113,0.3)] bg-[rgba(248,113,113,0.08)]',
                      )}
                    >
                      {testResult.ok ? (
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-ok" />
                      ) : (
                        <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-bad" />
                      )}
                      {testResult.ok ? (
                        <p className="text-[13px] text-ok">{testResult.message}</p>
                      ) : (
                        <pre className="whitespace-pre-wrap break-all font-mono text-xs leading-5 text-bad">
                          {testResult.message}
                        </pre>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>

              {/* Token 用量 */}
              <motion.div
                variants={fieldItem}
                className="rounded-[10px] border border-line bg-ink-input p-4"
              >
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-[13px] font-medium text-fg">本月 Token 用量</span>
                  <button
                    type="button"
                    onClick={() => statsQuery.refetch()}
                    className="flex items-center gap-1 text-xs text-fg-tertiary transition-colors hover:text-fg"
                  >
                    <RefreshCw className="h-3 w-3" />
                    刷新
                  </button>
                </div>
                <TokenMeter used={tokensUsed} total={TOKEN_QUOTA} />
                <p className="mt-2.5 text-xs text-fg-tertiary">
                  生成话术 {scriptCount} 次 · 平均每次 {avgTokens.toLocaleString()} tokens
                </p>
              </motion.div>
            </SectionCard>
          </div>

          {/* ============ TTS 语音配置 ============ */}
          <div
            id="tts"
            ref={(el) => {
              sectionRefs.current.tts = el
            }}
            className="scroll-mt-[84px]"
          >
            <SectionCard
              icon={Mic}
              title="TTS 语音配置"
              desc="AI 主播的声音。点试听即可听到真实合成语音（Edge TTS 免费通道）。"
              dirty={ttsDirty}
              saving={updateMutation.isPending}
              onReset={resetTts}
              onSave={saveTts}
            >
              {/* 音色 */}
              <motion.div variants={fieldItem}>
                <Field label="音色选择">
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    {VOICES.map((v) => {
                      const isActive = voice === v.value
                      const isPreviewing = previewing === v.value
                      return (
                        <button
                          key={v.value}
                          type="button"
                          onClick={() => setVoice(v.value)}
                          className={cn(
                            'flex items-center gap-3 rounded-[10px] border p-3 text-left transition-all',
                            isActive
                              ? 'border-brand bg-brand-soft'
                              : 'border-line bg-ink-input hover:border-line-strong',
                          )}
                        >
                          <span
                            className={cn(
                              'flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px]',
                              isActive ? 'bg-brand/20 text-brand-hover' : 'bg-ink-hover text-fg-tertiary',
                            )}
                          >
                            <AudioLines
                              className={cn('h-4 w-4', isPreviewing && 'animate-pulse text-signal')}
                            />
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block text-sm font-medium text-fg">{v.name}</span>
                            <span className="block truncate text-xs text-fg-tertiary">{v.desc}</span>
                          </span>
                          <span
                            role="button"
                            tabIndex={0}
                            title={isPreviewing ? '停止' : '试听'}
                            onClick={(e) => {
                              e.stopPropagation()
                              togglePreview(v.value, previewText, v.value)
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.stopPropagation()
                                togglePreview(v.value, previewText, v.value)
                              }
                            }}
                            className={cn(
                              'flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition-colors',
                              isPreviewing
                                ? 'border-signal/60 text-signal'
                                : 'border-line-strong text-fg-secondary hover:text-fg',
                            )}
                          >
                            {isPreviewing ? (
                              <Square className="h-3 w-3" />
                            ) : (
                              <Play className="ml-0.5 h-3.5 w-3.5" />
                            )}
                          </span>
                        </button>
                      )
                    })}
                  </div>
                </Field>
              </motion.div>

              {/* 语速 */}
              <motion.div variants={fieldItem}>
                <ValueSlider
                  label="语速"
                  value={rate}
                  min={0.5}
                  max={2}
                  step={0.05}
                  format={(v) => `${v.toFixed(2)}×`}
                  onChange={setRate}
                />
              </motion.div>

              {/* 试听文本 */}
              <motion.div variants={fieldItem}>
                <Field label="试听文本">
                  <textarea
                    value={previewText}
                    onChange={(e) => setPreviewText(e.target.value)}
                    rows={2}
                    className="w-full resize-none rounded-[10px] border border-line bg-ink-input px-3 py-2.5 text-sm leading-[22px] text-fg placeholder:text-fg-tertiary outline-none transition-all focus:border-brand focus:shadow-[0_0_0_3px_rgba(108,92,231,0.15)]"
                  />
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    type="button"
                    onClick={() => {
                      togglePreview('__text__', previewText, voice)
                      if (previewing !== '__text__') toast.info('正在合成语音…')
                    }}
                    className="mt-2 flex h-[38px] items-center gap-2 rounded-[10px] border border-line-strong bg-ink-hover px-4 text-sm font-medium text-fg transition-colors hover:border-fg-tertiary/40"
                  >
                    {previewing === '__text__' ? (
                      <Square className="h-3.5 w-3.5 text-signal" />
                    ) : (
                      <Play className="h-4 w-4" />
                    )}
                    {previewing === '__text__' ? '停止' : '播放试听'}
                  </motion.button>
                </Field>
              </motion.div>
            </SectionCard>
          </div>

          {/* ============ 直播间信息 ============ */}
          <div
            id="room"
            ref={(el) => {
              sectionRefs.current.room = el
            }}
            className="scroll-mt-[84px]"
          >
            <SectionCard
              icon={Radio}
              title="直播间信息"
              desc="AI 主播的人格设定，会注入到话术与直播画面中。"
              dirty={roomDirty}
              saving={updateMutation.isPending}
              onReset={resetRoom}
              onSave={saveRoom}
            >
              {/* 主播名 + 头像 */}
              <motion.div variants={fieldItem}>
                <Field label="AI 主播名">
                  <div className="flex items-center gap-4">
                    <input
                      value={hostName}
                      onChange={(e) => setHostName(e.target.value)}
                      maxLength={32}
                      placeholder="小播"
                      className={cn(inputCls, 'flex-1')}
                    />
                    <img
                      src="/avatar-host.webp"
                      alt="AI 主播形象"
                      className="h-16 w-16 shrink-0 rounded-full border border-line-strong object-cover"
                    />
                  </div>
                </Field>
              </motion.div>

              {/* 欢迎语模板 */}
              <motion.div variants={fieldItem}>
                <Field label="欢迎语模板" hint="点击变量插入到光标处">
                  <textarea
                    ref={welcomeRef}
                    value={welcome}
                    onChange={(e) => setWelcome(e.target.value)}
                    rows={3}
                    className="w-full resize-none rounded-[10px] border border-line bg-ink-input px-3 py-2.5 text-sm leading-[22px] text-fg placeholder:text-fg-tertiary outline-none transition-all focus:border-brand focus:shadow-[0_0_0_3px_rgba(108,92,231,0.15)]"
                  />
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {['{观众昵称}', '{主播名}', '{产品名}', '{日期}'].map((v) => (
                      <button
                        key={v}
                        type="button"
                        onClick={() => insertVar(v)}
                        className="rounded-[6px] bg-brand-soft px-2 py-0.5 font-mono text-xs text-brand-hover transition-colors hover:bg-brand/25"
                      >
                        {v}
                      </button>
                    ))}
                  </div>
                </Field>
              </motion.div>
            </SectionCard>
          </div>

          {/* ============ 账号与安全 ============ */}
          <div
            id="account"
            ref={(el) => {
              sectionRefs.current.account = el
            }}
            className="scroll-mt-[84px]"
          >
            <SectionCard
              icon={User}
              title="账号与安全"
              desc="当前登录账号信息（只读展示）。"
            >
              <motion.div variants={fieldItem}>
                {authLoading ? (
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 animate-pulse rounded-full bg-ink-hover" />
                    <div className="space-y-2">
                      <div className="h-3.5 w-28 animate-pulse rounded bg-ink-hover" />
                      <div className="h-3 w-44 animate-pulse rounded bg-ink-hover" />
                    </div>
                  </div>
                ) : user ? (
                  <div className="flex flex-wrap items-center gap-4">
                    <img
                      src={user.avatar ?? '/avatar-host.webp'}
                      alt={user.name ?? '账号头像'}
                      className="h-12 w-12 rounded-full border border-line-strong object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-fg">{user.name ?? '用户'}</p>
                      <p className="mt-0.5 truncate font-mono text-xs text-fg-tertiary">
                        {user.email ?? '未绑定邮箱'}
                      </p>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => logout()}
                      className="flex h-[38px] items-center gap-2 rounded-[10px] border border-[rgba(248,113,113,0.4)] bg-[rgba(248,113,113,0.12)] px-4 text-sm font-medium text-bad transition-colors hover:bg-[rgba(248,113,113,0.2)]"
                    >
                      <LogOut className="h-4 w-4" />
                      退出登录
                    </motion.button>
                  </div>
                ) : (
                  <p className="text-sm text-fg-secondary">未登录</p>
                )}
              </motion.div>

              <motion.div
                variants={fieldItem}
                className="flex items-center justify-between rounded-[10px] border border-line bg-ink-input px-3 py-2.5"
              >
                <div>
                  <p className="text-sm font-medium text-fg">登录保护</p>
                  <p className="text-xs text-fg-tertiary">下次登录需要密码验证</p>
                </div>
                <Switch
                  defaultChecked
                  onCheckedChange={(v) =>
                    toast.info(v ? '已开启登录保护' : '已关闭登录保护', {
                      description: '演示环境不持久化该选项',
                    })
                  }
                />
              </motion.div>
            </SectionCard>
          </div>
        </div>
      </div>
    </div>
  )
}
