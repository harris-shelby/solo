import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { Link } from 'react-router'
import { animate, motion, useMotionValue, useTransform } from 'framer-motion'
import type { Variants } from 'framer-motion'
import {
  Area,
  Bar,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import {
  ArrowRight,
  BookOpen,
  ChevronRight,
  Clock,
  Package,
  PackagePlus,
  Radio,
  RefreshCw,
  ScrollText,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Zap,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'
import { trpc } from '@/providers/trpc'
import { LOGIN_PATH } from '@/const'
import type { inferRouterOutputs } from '@trpc/server'
import type { AppRouter } from '../../api/router'

/* ======================================================================
 * 类型：从 tRPC 路由签名推导
 * ==================================================================== */

type RouterOutputs = inferRouterOutputs<AppRouter>
type Stats = RouterOutputs['dashboard']['stats']
type SessionItem = Stats['recentSessions'][number]
type ScriptItem = Stats['recentScripts'][number]

/** Kimi Token 演示配额：后端暂无配额字段，沿用设计稿 500,000 */
const TOKEN_QUOTA = 500_000

/* ======================================================================
 * 通用动效与小组件
 * ==================================================================== */

const EASE_OUT_EXPO = [0.16, 1, 0.3, 1] as [number, number, number, number]

const staggerParent: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07 } },
}
const fadeUp: Variants = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: EASE_OUT_EXPO } },
}

const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches

/** 数字滚动（count-up 1200ms easeOutExpo，支持千分位与小数；reduced-motion 直接显示终值） */
function CountUp({
  value,
  decimals = 0,
  duration = 1.2,
  className,
}: {
  value: number
  decimals?: number
  duration?: number
  className?: string
}) {
  const mv = useMotionValue(0)
  const text = useTransform(mv, (v) =>
    v.toLocaleString('en-US', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }),
  )
  useEffect(() => {
    if (prefersReducedMotion()) {
      mv.set(value)
      return
    }
    const controls = animate(mv, value, { duration, ease: EASE_OUT_EXPO })
    return () => controls.stop()
  }, [value, duration, mv])
  return <motion.span className={className}>{text}</motion.span>
}

/** Kimi Token 用量条（紫→青渐变，>70% 黄 / >90% 红） */
function TokenMeter({ used, total }: { used: number; total: number }) {
  const pct = total > 0 ? (used / total) * 100 : 0
  const color = pct > 90 ? 'var(--danger)' : pct > 70 ? 'var(--warning)' : undefined
  return (
    <div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-[rgba(30,36,48,0.12)]">
        <motion.div
          className="h-full w-full origin-left rounded-full"
          style={{ background: color ?? 'var(--accent-gradient)' }}
          initial={{ scaleX: 0 }}
          animate={{ scaleX: pct / 100 }}
          transition={{ duration: 1, ease: EASE_OUT_EXPO }}
        />
      </div>
      <div className="mt-1.5 flex items-center justify-between font-mono text-[11px] text-fg-tertiary">
        <span>
          {used.toLocaleString()} / {total.toLocaleString()} tokens
        </span>
        <span>{pct.toFixed(1)}%</span>
      </div>
    </div>
  )
}

/** 状态徽章（StatusPill 配色约定） */
function StatusPill({ status }: { status: '待开播' | '直播中' | '已结束' }) {
  const styles = {
    待开播: 'bg-[rgba(251,191,36,0.12)] text-warn',
    直播中: 'bg-[rgba(255,77,109,0.12)] text-live',
    已结束: 'bg-[rgba(30,36,48,0.10)] text-fg-secondary',
  } as const
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium',
        styles[status],
      )}
    >
      {status === '直播中' && (
        <span className="h-1.5 w-1.5 rounded-full bg-live animate-live-breathe" />
      )}
      {status}
    </span>
  )
}

/** 迷你趋势 sparkline（无轴 40×64） */
function Sparkline({ data, color }: { data: number[]; color: string }) {
  const points = useMemo(() => data.map((v, i) => ({ i, v })), [data])
  return (
    <LineChart width={64} height={40} data={points}>
      <Line
        type="monotone"
        dataKey="v"
        stroke={color}
        strokeWidth={1.5}
        dot={false}
        isAnimationActive={!prefersReducedMotion()}
        animationDuration={900}
        animationBegin={400}
      />
    </LineChart>
  )
}

function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div className={cn('rounded-[14px] border border-line bg-ink-card p-5 shadow-card', className)}>
      {children}
    </div>
  )
}

/* ======================================================================
 * 数据派生工具
 * ==================================================================== */

/** 相对时间：刚刚 / N 分钟前 / N 小时前 / 昨天 HH:mm / M月D日 */
function relativeTime(input: Date | string | null | undefined): string {
  if (!input) return '—'
  const d = input instanceof Date ? input : new Date(input)
  if (Number.isNaN(d.getTime())) return '—'
  const diff = Date.now() - d.getTime()
  const minutes = Math.floor(diff / 60000)
  if (minutes < 1) return '刚刚'
  if (minutes < 60) return `${minutes} 分钟前`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours} 小时前`
  const pad = (n: number) => String(n).padStart(2, '0')
  const now = new Date()
  const yesterday = new Date(now)
  yesterday.setDate(now.getDate() - 1)
  if (
    d.getFullYear() === yesterday.getFullYear() &&
    d.getMonth() === yesterday.getMonth() &&
    d.getDate() === yesterday.getDate()
  ) {
    return `昨天 ${pad(d.getHours())}:${pad(d.getMinutes())}`
  }
  return `${d.getMonth() + 1}月${d.getDate()}日`
}

/** 分钟 →「4h 12m」 */
function formatHM(minutes: number): string {
  const m = Math.max(0, Math.round(minutes))
  const h = Math.floor(m / 60)
  if (h === 0) return `${m}m`
  return `${h}h ${String(m % 60).padStart(2, '0')}m`
}

const WEEKDAYS = ['日', '一', '二', '三', '四', '五', '六']

type TrendPoint = { day: string; date: string; hours: number; tokens: number }

/**
 * 近 7 日趋势：后端暂未提供时间序列接口，
 * 基于 dashboard.stats 返回的最近任务 / 话术记录按日聚合派生
 * （仅覆盖各最近 5 条，更早的历史不计入）。
 */
function buildTrend7(stats: Stats): TrendPoint[] {
  const days: TrendPoint[] = []
  const now = new Date()
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i)
    days.push({
      day: `周${WEEKDAYS[d.getDay()]}`,
      date: `${d.getMonth() + 1}月${d.getDate()}日`,
      hours: 0,
      tokens: 0,
    })
  }
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6).getTime()
  const indexOf = (t: Date | string | null | undefined) => {
    if (!t) return -1
    const d = t instanceof Date ? t : new Date(t)
    const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()
    const idx = Math.round((dayStart - start) / 86400000)
    return idx >= 0 && idx < 7 ? idx : -1
  }
  for (const s of stats.recentSessions) {
    const idx = indexOf(s.startedAt ?? s.createdAt)
    if (idx < 0 || !s.startedAt) continue
    const startAt = s.startedAt instanceof Date ? s.startedAt : new Date(s.startedAt)
    const end = s.endedAt
      ? s.endedAt instanceof Date
        ? s.endedAt
        : new Date(s.endedAt)
      : s.status === 'live'
        ? new Date()
        : null
    if (!end) continue
    const minutes = Math.max(0, (end.getTime() - startAt.getTime()) / 60000)
    days[idx].hours = Math.round((days[idx].hours + minutes / 60) * 10) / 10
  }
  for (const s of stats.recentScripts) {
    const idx = indexOf(s.createdAt)
    if (idx < 0) continue
    days[idx].tokens += s.tokensUsed ?? 0
  }
  return days
}

/** 近 7 日每日新增话术数（用于话术卡 sparkline，数据源同上派生） */
function buildScriptSpark(stats: Stats): number[] {
  const counts = new Array<number>(7).fill(0)
  const now = new Date()
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6).getTime()
  for (const s of stats.recentScripts) {
    const d = s.createdAt instanceof Date ? s.createdAt : new Date(s.createdAt)
    const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime()
    const idx = Math.round((dayStart - start) / 86400000)
    if (idx >= 0 && idx < 7) counts[idx] += 1
  }
  return counts
}

/**
 * 产品数 sparkline：后端无历史快照，按当前总量生成一条平缓收尾的演示序列。
 */
function buildProductSpark(total: number): number[] {
  if (total <= 0) return [0, 0, 0, 0, 0, 0, 0]
  const ratios = [0.55, 0.62, 0.6, 0.72, 0.8, 0.9, 1]
  return ratios.map((r) => Math.max(0, Math.round(total * r)))
}

/** 趋势百分比：序列后半段均值相对前半段均值的变化；无法计算时返回 null */
function trendPercent(series: number[]): number | null {
  if (series.length < 4) return null
  const half = Math.floor(series.length / 2)
  const prev = series.slice(0, half)
  const next = series.slice(-half)
  const avg = (arr: number[]) => arr.reduce((s, v) => s + v, 0) / arr.length
  const a = avg(prev)
  const b = avg(next)
  if (a === 0) return b > 0 ? 100 : null
  const pct = Math.round(((b - a) / a) * 1000) / 10
  return Number.isFinite(pct) ? pct : null
}

/** 从话术标题「{产品名} 直播话术 v3」解析产品名与版本 */
function parseScriptTitle(title: string): { product: string; version: string | null } {
  const m = title.match(/^(.*?)\s*直播话术\s*v(\d+)\s*$/)
  if (m) return { product: m[1] || title, version: `v${m[2]}` }
  return { product: title, version: null }
}

const SESSION_STATUS_LABEL = {
  pending: '待开播',
  live: '直播中',
  ended: '已结束',
} as const

function sessionStatusLabel(status: string): '待开播' | '直播中' | '已结束' {
  return (SESSION_STATUS_LABEL as Record<string, '待开播' | '直播中' | '已结束'>)[status] ?? '已结束'
}

function asDate(v: Date | string | null | undefined): Date | null {
  if (!v) return null
  const d = v instanceof Date ? v : new Date(v)
  return Number.isNaN(d.getTime()) ? null : d
}

/** 任务时长：已开播按起止时间计算，待开播显示计划时长 */
function sessionDuration(s: SessionItem): string {
  const started = asDate(s.startedAt)
  if (started) {
    const end = asDate(s.endedAt) ?? (s.status === 'live' ? new Date() : null)
    if (end) return formatHM((end.getTime() - started.getTime()) / 60000)
  }
  if (s.status === 'pending' && s.plannedMinutes) return `计划 ${formatHM(s.plannedMinutes)}`
  return '—'
}

function sessionTimeText(s: SessionItem): string {
  if (s.status === 'live') return '进行中'
  if (s.status === 'ended') return relativeTime(asDate(s.endedAt) ?? asDate(s.createdAt))
  return relativeTime(asDate(s.createdAt))
}

/* ======================================================================
 * 图表自定义 Tooltip（深色卡）
 * ==================================================================== */

function TrendTooltip({
  active,
  payload,
}: {
  active?: boolean
  payload?: { payload?: TrendPoint }[]
}) {
  if (!active || !payload?.length) return null
  const d = payload[0]?.payload
  if (!d) return null
  return (
    <div className="rounded-[10px] border border-line-strong bg-ink-hover px-3 py-2 text-xs shadow-overlay">
      <p className="font-medium text-fg">
        {d.date} · 直播 {d.hours}h · 消耗 {d.tokens.toLocaleString()} tokens
      </p>
    </div>
  )
}

/* ======================================================================
 * 区块一：问候头
 * ==================================================================== */

function greetingByHour(h: number) {
  if (h < 6) return '夜深了'
  if (h < 12) return '早上好'
  if (h < 18) return '下午好'
  return '晚上好'
}

function GreetingHeader() {
  const now = new Date()
  const dateLine = `今天是 ${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日 星期${WEEKDAYS[now.getDay()]} · AI 主播随时待命`
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: EASE_OUT_EXPO }}
      >
        <h1 className="text-2xl font-bold leading-8 text-fg">
          {greetingByHour(now.getHours())}，老板
        </h1>
        <p className="mt-1 text-sm text-fg-secondary">{dateLine}</p>
      </motion.div>
      <motion.div
        className="flex items-center gap-3"
        initial="hidden"
        animate="show"
        variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1 } } }}
      >
        <motion.div variants={fadeUp}>
          <Link
            to="/tutorial"
            className="flex h-[38px] items-center gap-2 rounded-[10px] border border-line-strong bg-ink-hover px-[18px] text-sm text-fg transition-all duration-150 hover:brightness-125"
          >
            <BookOpen className="h-4 w-4" />
            查看搭建教程
          </Link>
        </motion.div>
        <motion.div variants={fadeUp}>
          <Link
            to="/live"
            className="flex h-[38px] items-center gap-2 rounded-[10px] px-[18px] text-sm font-medium text-white transition-transform duration-150 hover:scale-[1.02] hover:shadow-glow-accent active:scale-[0.97]"
            style={{ background: 'var(--accent-gradient)' }}
          >
            <Radio className="h-4 w-4" />
            立即开播
          </Link>
        </motion.div>
      </motion.div>
    </div>
  )
}

/* ======================================================================
 * 区块二：核心指标卡
 * ==================================================================== */

function StatCard({
  icon: Icon,
  label,
  sub,
  trend,
  spark,
  children,
}: {
  icon: LucideIcon
  label: string
  sub: string
  trend?: number | null
  spark?: number[]
  children: ReactNode
}) {
  const hasTrend = typeof trend === 'number' && Number.isFinite(trend)
  const up = (trend ?? 0) >= 0
  return (
    <motion.div variants={fadeUp}>
      <Card className="group h-full transition-all duration-250 hover:-translate-y-0.5 hover:border-line-strong">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-[10px] bg-brand-soft text-brand-hover">
            <Icon className="h-5 w-5" />
          </span>
          <span className="text-xs text-fg-tertiary">{label}</span>
        </div>
        <div className="mt-4 font-display text-[30px] font-bold leading-[1.1] text-fg">
          {children}
        </div>
        <div className="mt-3 flex items-end justify-between gap-2">
          <span className="text-[13px] text-fg-secondary">{sub}</span>
          {spark && (
            <span className="flex flex-col items-end gap-1">
              <Sparkline data={spark} color="var(--cyan)" />
              {hasTrend && (
                <span
                  className={cn(
                    'flex items-center gap-0.5 text-xs',
                    up ? 'text-ok' : 'text-fg-tertiary',
                  )}
                >
                  {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {up ? '↑' : '↓'} {Math.abs(trend ?? 0)}%
                </span>
              )}
            </span>
          )}
        </div>
      </Card>
    </motion.div>
  )
}

/* ======================================================================
 * 区块三：图表行
 * ==================================================================== */

type TrendView = 'both' | 'hours' | 'tokens'

function TrendChartCard({ data }: { data: TrendPoint[] }) {
  const [view, setView] = useState<TrendView>('both')
  const animated = !prefersReducedMotion()
  const tabs: { key: TrendView; label: string }[] = [
    { key: 'hours', label: '直播时长' },
    { key: 'tokens', label: 'Token 消耗' },
    { key: 'both', label: '双视图' },
  ]
  return (
    <Card className="min-w-0">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-[17px] font-semibold leading-[26px] text-fg">运营趋势</h2>
        <div className="flex gap-1 rounded-[10px] border border-line bg-ink-input p-1">
          {tabs.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setView(t.key)}
              className={cn(
                'relative rounded-md px-3 py-1 text-[13px] transition-colors',
                view === t.key ? 'text-fg' : 'text-fg-tertiary hover:text-fg-secondary',
              )}
            >
              {view === t.key && (
                <motion.span
                  layoutId="trend-tab"
                  className="absolute inset-0 rounded-md bg-brand-soft"
                  transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                />
              )}
              <span className="relative">{t.label}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="h-[280px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 8, right: 4, bottom: 0, left: -12 }}>
            <defs>
              <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#6C5CE7" stopOpacity={0.95} />
                <stop offset="100%" stopColor="#6C5CE7" stopOpacity={0.35} />
              </linearGradient>
              <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#06B6D4" stopOpacity={0.18} />
                <stop offset="100%" stopColor="#06B6D4" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="rgba(30,36,48,0.08)" vertical={false} />
            <XAxis
              dataKey="day"
              tick={{ fill: '#9AA3B5', fontSize: 12 }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              yAxisId="hours"
              orientation="left"
              tick={{ fill: '#9AA3B5', fontSize: 12 }}
              axisLine={false}
              tickLine={false}
              unit="h"
              hide={view === 'tokens'}
            />
            <YAxis
              yAxisId="tokens"
              orientation="right"
              tick={{ fill: '#9AA3B5', fontSize: 12 }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v: number) => `${Math.round(v / 1000)}k`}
              hide={view === 'hours'}
            />
            <Tooltip content={<TrendTooltip />} cursor={{ fill: 'rgba(30,36,48,0.06)' }} />
            {(view === 'both' || view === 'tokens') && (
              <Bar
                yAxisId="tokens"
                dataKey="tokens"
                fill="url(#barGrad)"
                radius={[4, 4, 0, 0]}
                maxBarSize={28}
                isAnimationActive={animated}
                animationDuration={500}
              />
            )}
            {(view === 'both' || view === 'hours') && (
              <Area
                yAxisId="hours"
                type="monotone"
                dataKey="hours"
                stroke="#06B6D4"
                strokeWidth={2}
                fill="url(#areaGrad)"
                isAnimationActive={animated}
                animationDuration={1200}
              />
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}

const DONUT_ORDER = [
  { key: 'pending', name: '待开播', color: '#F59E0B' },
  { key: 'live', name: '直播中', color: '#FF4D6D' },
  { key: 'ended', name: '已结束', color: '#9AA3B5' },
] as const

function TaskDonutCard({ sessionsByStatus, total }: { sessionsByStatus: Stats['sessionsByStatus']; total: number }) {
  const data = DONUT_ORDER.map((d) => ({
    name: d.name,
    value: sessionsByStatus[d.key] ?? 0,
    color: d.color,
  }))
  const [active, setActive] = useState<number | null>(null)
  return (
    <Card>
      <h2 className="text-[17px] font-semibold leading-[26px] text-fg">任务状态</h2>
      <div className="relative mx-auto mt-2 h-[200px] w-full max-w-[260px]">
        {total > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="name"
                innerRadius="60%"
                outerRadius="88%"
                paddingAngle={3}
                strokeWidth={0}
                isAnimationActive={!prefersReducedMotion()}
                animationDuration={800}
                onMouseEnter={(_, i) => setActive(i)}
                onMouseLeave={() => setActive(null)}
              >
                {data.map((t, i) => (
                  <Cell key={t.name} fill={t.color} opacity={active === null || active === i ? 1 : 0.35} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="absolute inset-[12%] rounded-full border-[14px] border-ink-hover" />
        )}
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-2xl font-bold text-fg">
            <CountUp value={total} />
          </span>
          <span className="text-xs text-fg-tertiary">场</span>
        </div>
      </div>
      <ul className="mt-3 space-y-2">
        {data.map((t, i) => (
          <li
            key={t.name}
            onMouseEnter={() => setActive(i)}
            onMouseLeave={() => setActive(null)}
            className={cn(
              'flex items-center gap-2 rounded-md px-2 py-1 text-[13px] transition-colors',
              active === i && 'bg-ink-hover',
            )}
          >
            <span className="h-2 w-2 rounded-full" style={{ background: t.color }} />
            <span className="flex-1 text-fg-secondary">{t.name}</span>
            <span className="font-mono text-fg">{t.value}</span>
          </li>
        ))}
      </ul>
    </Card>
  )
}

/* ======================================================================
 * 区块四：快捷操作 + 系统健康
 * ==================================================================== */

const QUICK_ACTIONS = [
  {
    icon: PackagePlus,
    title: '新增产品',
    desc: '上传图片与介绍，30 秒建档',
    to: '/products?new=1',
  },
  {
    icon: Sparkles,
    title: '生成话术',
    desc: 'Kimi 流式生成六段话术',
    to: '/scripts',
  },
  {
    icon: Radio,
    title: '创建直播任务',
    desc: '选产品、定排期、一键开播',
    to: '/live?new=1',
  },
]

function QuickActionsCard() {
  return (
    <Card>
      <h2 className="mb-4 text-[17px] font-semibold leading-[26px] text-fg">快捷操作</h2>
      <div className="space-y-3">
        {QUICK_ACTIONS.map((a) => (
          <Link
            key={a.title}
            to={a.to}
            className="group flex h-16 items-center gap-4 rounded-[10px] border border-line px-4 transition-all duration-250 hover:border-brand hover:bg-ink-hover"
          >
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[10px] bg-brand-soft text-brand-hover">
              <a.icon className="h-5 w-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-medium text-fg">{a.title}</span>
              <span className="block truncate text-xs text-fg-tertiary">{a.desc}</span>
            </span>
            <ArrowRight className="h-4 w-4 -translate-x-1 text-brand-hover opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100" />
          </Link>
        ))}
      </div>
    </Card>
  )
}

type HealthStatus = 'checking' | 'ok' | 'bad' | 'idle' | 'live'

type HealthRow = {
  key: string
  name: string
  tab: string
  status: HealthStatus
  text: string
}

const HEALTH_DOT: Record<HealthStatus, string> = {
  checking: 'bg-fg-tertiary animate-pulse',
  ok: 'bg-ok animate-status-breathe',
  live: 'bg-live animate-live-breathe',
  idle: 'bg-fg-tertiary',
  bad: 'bg-bad animate-status-breathe',
}
const HEALTH_TEXT: Record<HealthStatus, string> = {
  checking: 'text-fg-tertiary',
  ok: 'text-ok',
  live: 'text-live',
  idle: 'text-fg-tertiary',
  bad: 'text-bad',
}

const delay = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms))

function SystemHealthCard({ stats }: { stats: Stats }) {
  const testKimi = trpc.settings.testConnection.useMutation()
  const settingsQuery = trpc.settings.get.useQuery(undefined, {
    retry: false,
    staleTime: 60_000,
  })

  const [rows, setRows] = useState<HealthRow[]>([
    { key: 'kimi', name: 'Kimi API 连接', tab: 'kimi', status: 'checking', text: '' },
    { key: 'tts', name: 'TTS 语音服务', tab: 'tts', status: 'checking', text: '' },
    { key: 'obs', name: 'OBS 推流通道', tab: 'obs', status: 'checking', text: '' },
    { key: 'storage', name: '存储空间', tab: 'storage', status: 'checking', text: '' },
  ])
  const [checkedAt, setCheckedAt] = useState<Date | null>(null)
  const [running, setRunning] = useState(false)

  const patchRow = (key: string, patch: Partial<HealthRow>) =>
    setRows((prev) => prev.map((r) => (r.key === key ? { ...r, ...patch } : r)))

  /**
   * 逐项检测：4 行依次进入 skeleton，再按各自数据源恢复。
   * - Kimi：真实调用 settings.testConnection（GET /models），计延迟；
   * - TTS：读取已保存设置的音色；
   * - OBS：由看板统计中的直播中任务数推导；
   * - 存储：后端暂无用量接口，保留演示文案。
   */
  const runChecks = useCallback(async () => {
    setRunning(true)
    setRows((prev) => prev.map((r) => ({ ...r, status: 'checking', text: '' })))

    // Kimi API：真实连通性测试 + 延迟测量（至少展示 200ms，让 skeleton 可被感知）
    const kimiTask = (async () => {
      const t0 = performance.now()
      try {
        const [res] = await Promise.all([testKimi.mutateAsync(), delay(200)])
        const latency = Math.max(1, Math.round(performance.now() - t0))
        patchRow('kimi', {
          status: 'ok',
          text: `正常 · 延迟 ${latency}ms · 可用模型 ${res.modelCount} 个`,
        })
      } catch (err) {
        patchRow('kimi', {
          status: 'bad',
          text: err instanceof Error ? err.message : '连接失败，请检查 API Key',
        })
      }
    })()

    const ttsTask = delay(400).then(async () => {
      const s = (await settingsQuery.refetch()).data
      patchRow('tts', s?.ttsVoice
        ? { status: 'ok', text: `正常 · 音色「${s.ttsVoice}」` }
        : { status: 'idle', text: '未配置音色' })
    })

    const obsTask = delay(600).then(() => {
      const liveCount = stats.sessionsByStatus.live ?? 0
      patchRow('obs', liveCount > 0
        ? { status: 'live', text: `推流中 · ${liveCount} 场直播进行中` }
        : { status: 'idle', text: '未推流' })
    })

    const storageTask = delay(800).then(() => {
      // 演示数据：后端暂无存储用量统计
      patchRow('storage', { status: 'ok', text: '已用 2.1 / 10 GB' })
    })

    await Promise.all([kimiTask, ttsTask, obsTask, storageTask])
    setCheckedAt(new Date())
    setRunning(false)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stats.sessionsByStatus.live])

  const booted = useRef(false)
  useEffect(() => {
    if (booted.current) return
    booted.current = true
    void runChecks()
  }, [runChecks])

  return (
    <Card>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-[17px] font-semibold leading-[26px] text-fg">系统状态</h2>
        <button
          type="button"
          onClick={() => void runChecks()}
          disabled={running}
          className="flex items-center gap-1.5 text-xs text-fg-tertiary transition-colors hover:text-brand-hover disabled:cursor-not-allowed"
        >
          {checkedAt ? relativeTime(checkedAt) : '检测中'} · 重新检测
          <RefreshCw className={cn('h-3.5 w-3.5', running && 'animate-spin')} />
        </button>
      </div>
      <motion.ul
        className="divide-y divide-line"
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.3 }}
        variants={{ hidden: {}, show: { transition: { staggerChildren: 0.06 } } }}
      >
        {rows.map((h) => (
          <motion.li
            key={h.key}
            variants={fadeUp}
            className="flex h-[52px] items-center gap-3"
          >
            <span className={cn('h-2 w-2 shrink-0 rounded-full', HEALTH_DOT[h.status])} />
            <span className="w-28 shrink-0 text-sm text-fg">{h.name}</span>
            {h.status === 'checking' ? (
              <span className="h-4 flex-1 animate-pulse rounded bg-ink-hover" />
            ) : (
              <span className={cn('flex-1 truncate text-[13px]', HEALTH_TEXT[h.status])}>
                ● {h.text}
              </span>
            )}
            <Link
              to={`/settings?tab=${h.tab}`}
              className="shrink-0 text-xs text-fg-tertiary transition-colors hover:text-brand-hover"
            >
              配置
            </Link>
          </motion.li>
        ))}
      </motion.ul>
    </Card>
  )
}

/* ======================================================================
 * 区块五：最近动态
 * ==================================================================== */

const PLATFORM_STYLE: Record<string, string> = {
  抖音: 'bg-[rgba(34,211,238,0.10)] text-signal',
  快手: 'bg-[rgba(251,191,36,0.12)] text-warn',
  视频号: 'bg-[rgba(52,211,153,0.12)] text-ok',
}
const PLATFORM_FALLBACK = 'bg-[rgba(30,36,48,0.10)] text-fg-secondary'

function RecentTasksCard({ sessions }: { sessions: SessionItem[] }) {
  return (
    <Card className="min-w-0">
      <h2 className="mb-2 text-[17px] font-semibold leading-[26px] text-fg">最近直播任务</h2>
      {sessions.length === 0 ? (
        <div className="flex flex-col items-center py-10 text-center">
          <Radio className="h-8 w-8 text-fg-tertiary" />
          <p className="mt-3 text-sm text-fg-secondary">还没有直播任务</p>
          <p className="mt-1 text-xs text-fg-tertiary">创建任务后即可一键开播</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="text-left text-xs font-medium tracking-[0.05em] text-fg-tertiary">
                <th className="py-2 pr-3 font-medium">任务名</th>
                <th className="py-2 pr-3 font-medium">话术版本</th>
                <th className="py-2 pr-3 font-medium">时长</th>
                <th className="py-2 pr-3 font-medium">状态</th>
                <th className="py-2 pr-3 font-medium">时间</th>
                <th className="py-2 text-right font-medium">操作</th>
              </tr>
            </thead>
            <motion.tbody
              initial="hidden"
              whileInView="show"
              viewport={{ once: true, amount: 0.2 }}
              variants={{ hidden: {}, show: { transition: { staggerChildren: 0.05 } } }}
            >
              {sessions.map((s) => {
                const status = sessionStatusLabel(s.status)
                const version = s.scriptTitle
                  ? parseScriptTitle(s.scriptTitle).version
                  : null
                return (
                  <motion.tr
                    key={s.id}
                    variants={{
                      hidden: { opacity: 0, x: -8 },
                      show: { opacity: 1, x: 0, transition: { duration: 0.3, ease: EASE_OUT_EXPO } },
                    }}
                    className="border-t border-line transition-colors hover:bg-ink-hover"
                  >
                    <td className="h-[52px] pr-3">
                      <span className="mr-2 text-fg">{s.title}</span>
                      <span
                        className={cn(
                          'rounded-md px-1.5 py-0.5 text-[11px] font-medium',
                          PLATFORM_STYLE[s.platform] ?? PLATFORM_FALLBACK,
                        )}
                      >
                        {s.platform}
                      </span>
                    </td>
                    <td className="pr-3 font-mono text-[13px] text-fg-secondary">
                      {version ?? '—'}
                    </td>
                    <td className="pr-3 font-mono text-[13px] text-fg-secondary">
                      {sessionDuration(s)}
                    </td>
                    <td className="pr-3">
                      <StatusPill status={status} />
                    </td>
                    <td className="pr-3 text-xs text-fg-tertiary">{sessionTimeText(s)}</td>
                    <td className="text-right">
                      {status === '直播中' ? (
                        <Link to="/live" className="text-[13px] font-medium text-live hover:underline">
                          进入控制台
                        </Link>
                      ) : (
                        <button
                          type="button"
                          className="rounded-md px-2 py-1 text-[13px] text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg"
                        >
                          复盘
                        </button>
                      )}
                    </td>
                  </motion.tr>
                )
              })}
            </motion.tbody>
          </table>
        </div>
      )}
      <Link
        to="/live"
        className="mt-3 flex items-center justify-end gap-1 text-[13px] text-fg-tertiary transition-colors hover:text-brand-hover"
      >
        查看全部 <ChevronRight className="h-3.5 w-3.5" />
      </Link>
    </Card>
  )
}

function ScriptFeedCard({ scripts }: { scripts: ScriptItem[] }) {
  return (
    <Card>
      <h2 className="mb-4 text-[17px] font-semibold leading-[26px] text-fg">话术生成记录</h2>
      {scripts.length === 0 ? (
        <div className="flex flex-col items-center py-10 text-center">
          <ScrollText className="h-8 w-8 text-fg-tertiary" />
          <p className="mt-3 text-sm text-fg-secondary">还没有生成过话术</p>
          <p className="mt-1 text-xs text-fg-tertiary">选择产品，让 Kimi 自动生成六段话术</p>
        </div>
      ) : (
        <motion.ol
          className="relative ml-1 space-y-5 border-l-2 border-line pl-5"
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          variants={{ hidden: {}, show: { transition: { staggerChildren: 0.07 } } }}
        >
          {scripts.map((s, i) => {
            const { product, version } = parseScriptTitle(s.title)
            return (
              <motion.li
                key={s.id}
                className="relative"
                variants={{
                  hidden: { opacity: 0, x: 12 },
                  show: { opacity: 1, x: 0, transition: { duration: 0.35, ease: EASE_OUT_EXPO } },
                }}
              >
                <motion.span
                  className="absolute -left-[26px] top-1.5 h-2.5 w-2.5 rounded-full border-2 border-ink-card bg-brand"
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ type: 'spring', stiffness: 260, damping: 24, delay: i * 0.07 }}
                />
                <div className="flex items-start gap-3">
                  {/* 统计接口不含产品图，用产品名首字符色块代替缩略图 */}
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md border border-line bg-brand-soft text-[13px] font-semibold text-brand-hover">
                    {product.slice(0, 1)}
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm leading-5 text-fg">
                      《{product}》生成了直播话术{' '}
                      {version && (
                        <span className="font-mono text-[13px] text-brand-hover">{version}</span>
                      )}
                    </p>
                    <p className="mt-0.5 text-xs text-fg-tertiary">
                      消耗 {(s.tokensUsed ?? 0).toLocaleString()} tokens ·{' '}
                      {relativeTime(s.createdAt)}
                      {s.model && <span className="font-mono"> · {s.model}</span>}
                    </p>
                  </div>
                </div>
              </motion.li>
            )
          })}
        </motion.ol>
      )}
      <Link
        to="/scripts"
        className="mt-4 flex items-center justify-end gap-1 text-[13px] text-fg-tertiary transition-colors hover:text-brand-hover"
      >
        查看全部 <ChevronRight className="h-3.5 w-3.5" />
      </Link>
    </Card>
  )
}

/** 空状态（首次使用，无任何产品时替换区块三/五） */
function EmptyState() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, ease: EASE_OUT_EXPO }}
    >
      <Card className="flex flex-col items-center py-14 text-center">
        <img src="/empty-products.webp" alt="" className="h-40 w-auto" />
        <h2 className="mt-6 text-[17px] font-semibold text-fg">开始你的一人直播公司</h2>
        <p className="mt-2 max-w-sm text-[13px] text-fg-secondary">
          三步上手：添加产品 → Kimi 生成话术 → 一键开播
        </p>
        <div className="mt-6 flex items-center gap-3">
          <Link
            to="/products?new=1"
            className="flex h-[38px] items-center gap-2 rounded-[10px] px-[18px] text-sm font-medium text-white transition-transform duration-150 hover:scale-[1.02] hover:shadow-glow-accent active:scale-[0.97]"
            style={{ background: 'var(--accent-gradient)' }}
          >
            <PackagePlus className="h-4 w-4" />
            添加第一款产品
          </Link>
          <Link
            to="/tutorial"
            className="flex h-[38px] items-center rounded-[10px] px-4 text-sm text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
          >
            先看搭建教程
          </Link>
        </div>
      </Card>
    </motion.div>
  )
}

/* ======================================================================
 * 加载骨架屏 / 错误态
 * ==================================================================== */

function Bone({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-[10px] bg-ink-hover', className)} />
}

function HomeSkeleton() {
  return (
    <div className="mx-auto max-w-[1560px] space-y-6 p-6 lg:p-8" aria-busy="true" aria-label="加载中">
      {/* 问候头骨架 */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="space-y-2">
          <Bone className="h-8 w-48" />
          <Bone className="h-5 w-72" />
        </div>
        <div className="flex gap-3">
          <Bone className="h-[38px] w-32" />
          <Bone className="h-[38px] w-28" />
        </div>
      </div>
      {/* 指标卡骨架 */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="space-y-4">
            <div className="flex items-center gap-3">
              <Bone className="h-10 w-10" />
              <Bone className="h-4 w-20" />
            </div>
            <Bone className="h-8 w-28" />
            <div className="flex items-end justify-between">
              <Bone className="h-4 w-24" />
              <Bone className="h-10 w-16" />
            </div>
          </Card>
        ))}
      </div>
      {/* 图表行骨架 */}
      <div className="grid grid-cols-1 gap-6 min-[1200px]:grid-cols-[2fr_1fr]">
        <Card>
          <Bone className="mb-4 h-6 w-28" />
          <Bone className="h-[280px] w-full" />
        </Card>
        <Card>
          <Bone className="mb-4 h-6 w-24" />
          <Bone className="mx-auto h-[200px] w-[200px] rounded-full" />
          <div className="mt-3 space-y-2">
            <Bone className="h-6 w-full" />
            <Bone className="h-6 w-full" />
            <Bone className="h-6 w-full" />
          </div>
        </Card>
      </div>
      {/* 快捷操作 + 系统状态骨架 */}
      <div className="grid grid-cols-1 gap-6 min-[1200px]:grid-cols-[1fr_2fr]">
        <Card className="space-y-3">
          <Bone className="mb-1 h-6 w-24" />
          <Bone className="h-16 w-full" />
          <Bone className="h-16 w-full" />
          <Bone className="h-16 w-full" />
        </Card>
        <Card className="space-y-3">
          <Bone className="mb-1 h-6 w-24" />
          {Array.from({ length: 4 }).map((_, i) => (
            <Bone key={i} className="h-[40px] w-full" />
          ))}
        </Card>
      </div>
    </div>
  )
}

function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  const unauthorized = message.includes('登录') || message.includes('UNAUTHORIZED')
  return (
    <div className="mx-auto max-w-[1560px] p-6 lg:p-8">
      <Card className="flex flex-col items-center py-16 text-center">
        <span className="flex h-12 w-12 items-center justify-center rounded-[10px] bg-[rgba(248,113,113,0.12)] text-bad">
          <Zap className="h-6 w-6" />
        </span>
        <h2 className="mt-5 text-[17px] font-semibold text-fg">看板数据加载失败</h2>
        <p className="mt-2 max-w-md text-[13px] text-fg-secondary">{message}</p>
        <div className="mt-6 flex items-center gap-3">
          <button
            type="button"
            onClick={onRetry}
            className="flex h-[38px] items-center gap-2 rounded-[10px] px-[18px] text-sm font-medium text-white transition-transform duration-150 hover:scale-[1.02] hover:shadow-glow-accent active:scale-[0.97]"
            style={{ background: 'var(--accent-gradient)' }}
          >
            <RefreshCw className="h-4 w-4" />
            重新加载
          </button>
          {unauthorized && (
            <Link
              to={LOGIN_PATH}
              className="flex h-[38px] items-center rounded-[10px] border border-line-strong bg-ink-hover px-[18px] text-sm text-fg transition-all duration-150 hover:brightness-125"
            >
              去登录
            </Link>
          )}
        </div>
      </Card>
    </div>
  )
}

/* ======================================================================
 * 数据看板首页
 * ==================================================================== */

export default function Home() {
  const statsQuery = trpc.dashboard.stats.useQuery(undefined, {
    refetchInterval: 60_000,
    retry: 1,
  })
  const stats = statsQuery.data ?? null

  const trend7 = useMemo(() => (stats ? buildTrend7(stats) : []), [stats])
  const scriptSpark = useMemo(() => (stats ? buildScriptSpark(stats) : []), [stats])
  const productSpark = useMemo(
    () => (stats ? buildProductSpark(stats.productCount) : []),
    [stats],
  )

  if (statsQuery.isLoading) return <HomeSkeleton />
  if (!stats) {
    return (
      <ErrorState
        message={statsQuery.error?.message ?? '网络异常，请稍后重试'}
        onRetry={() => void statsQuery.refetch()}
      />
    )
  }

  const totalHours = Math.round((stats.totalLiveMinutes / 60) * 10) / 10
  const hasProducts = stats.productCount > 0
  const hoursSpark = trend7.map((d) => d.hours)

  return (
    <div className="mx-auto max-w-[1560px] space-y-6 p-6 lg:p-8">
      {/* 区块一：问候头 */}
      <GreetingHeader />

      {/* 区块二：核心指标卡 */}
      <motion.div
        className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4"
        initial="hidden"
        animate="show"
        variants={{ hidden: {}, show: { transition: { staggerChildren: 0.08 } } }}
      >
        <StatCard
          icon={Package}
          label="在售产品"
          sub={hasProducts ? '产品库已建档，可随时开播' : '尚未添加产品'}
          trend={trendPercent(productSpark)}
          spark={productSpark}
        >
          <CountUp value={stats.productCount} />
        </StatCard>
        <StatCard
          icon={ScrollText}
          label="已生成话术"
          sub={
            stats.recentScripts[0]
              ? `最近生成 ${relativeTime(stats.recentScripts[0].createdAt)}`
              : '等待首次生成'
          }
          trend={trendPercent(scriptSpark)}
          spark={scriptSpark}
        >
          <CountUp value={stats.scriptCount} />
          <span className="ml-1 text-base font-medium text-fg-tertiary">篇</span>
        </StatCard>
        <StatCard
          icon={Clock}
          label="累计直播时长"
          sub={`共 ${stats.sessionCount} 场直播任务`}
          trend={trendPercent(hoursSpark)}
          spark={hoursSpark}
        >
          <CountUp value={totalHours} decimals={1} />
          <span className="ml-1 text-base font-medium text-fg-tertiary">h</span>
        </StatCard>
        <motion.div variants={fadeUp}>
          <Card className="h-full transition-all duration-250 hover:-translate-y-0.5 hover:border-line-strong">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-[10px] bg-brand-soft text-brand-hover">
                <Zap className="h-5 w-5" />
              </span>
              <span className="text-xs text-fg-tertiary">Kimi Token 用量</span>
            </div>
            <div className="mt-4 font-display text-[30px] font-bold leading-[1.1] text-fg">
              <CountUp value={stats.totalTokensUsed} />
            </div>
            <div className="mt-3">
              <TokenMeter used={stats.totalTokensUsed} total={TOKEN_QUOTA} />
            </div>
          </Card>
        </motion.div>
      </motion.div>

      {/* 区块三：图表行（无产品时替换为空状态） */}
      {hasProducts ? (
        <motion.div
          className="grid grid-cols-1 gap-6 min-[1200px]:grid-cols-[2fr_1fr]"
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.15 }}
          variants={staggerParent}
        >
          <motion.div variants={fadeUp} className="min-w-0">
            <TrendChartCard data={trend7} />
          </motion.div>
          <motion.div variants={fadeUp}>
            <TaskDonutCard
              sessionsByStatus={stats.sessionsByStatus}
              total={stats.sessionCount}
            />
          </motion.div>
        </motion.div>
      ) : (
        <EmptyState />
      )}

      {/* 区块四：快捷操作 + 系统健康 */}
      <motion.div
        className="grid grid-cols-1 gap-6 min-[1200px]:grid-cols-[1fr_2fr]"
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.15 }}
        variants={staggerParent}
      >
        <motion.div variants={fadeUp}>
          <QuickActionsCard />
        </motion.div>
        <motion.div variants={fadeUp} className="min-w-0">
          <SystemHealthCard stats={stats} />
        </motion.div>
      </motion.div>

      {/* 区块五：最近动态 */}
      {hasProducts && (
        <motion.div
          className="grid grid-cols-1 gap-6 min-[1200px]:grid-cols-[3fr_2fr]"
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.15 }}
          variants={staggerParent}
        >
          <motion.div variants={fadeUp} className="min-w-0">
            <RecentTasksCard sessions={stats.recentSessions} />
          </motion.div>
          <motion.div variants={fadeUp}>
            <ScriptFeedCard scripts={stats.recentScripts} />
          </motion.div>
        </motion.div>
      )}
    </div>
  )
}
