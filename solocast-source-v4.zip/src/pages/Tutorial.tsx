import { useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { Link, useLocation } from 'react-router'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import Lenis from 'lenis'
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  Clock,
  Copy,
  Info,
  KeyRound,
  MonitorPlay,
  PartyPopper,
  Radio,
  Server,
  Settings,
  TriangleAlert,
  Volume2,
} from 'lucide-react'
import { toast } from 'sonner'
import { Toaster } from '@/components/ui/sonner'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { cn } from '@/lib/utils'

gsap.registerPlugin(ScrollTrigger, useGSAP)

/* ======================================================================
 * 常量
 * ==================================================================== */

const ANCHORS = [
  { id: 'overview', label: '概览' },
  { id: 'step-1', label: '① 获取 Kimi Key' },
  { id: 'step-2', label: '② 部署中控台' },
  { id: 'step-3', label: '③ 接入 TTS' },
  { id: 'step-4', label: '④ 配置 OBS 推流' },
  { id: 'step-5', label: '⑤ 开播与合规' },
]

const FAQS = [
  {
    q: 'Kimi token 大概烧多快？',
    a: '单场 2 小时直播话术约消耗 2k–5k tokens，月播 30 场建议充值 50 元额度。新用户赠送的 15 元额度足够你测试很长一段时间。',
  },
  {
    q: '可以 24 小时连续播吗？',
    a: '可以。开启「话术循环播报」即可无人值守连播。建议每 4 小时切换一次话术版本，避免观众听出重复感。',
  },
  {
    q: '支持哪些直播平台？',
    a: '任何支持 RTMP 推流的平台都可以：抖音、快手、视频号、淘宝直播、B 站。只需把平台给的推流地址和密钥填进中控台即可。',
  },
  {
    q: '话术会重复吗？',
    a: '每次调用 Kimi 生成都是全新内容；开启「每场循环后随机插入互动话术」可进一步降低重复感。',
  },
]

/* ======================================================================
 * 小组件
 * ==================================================================== */

/** 代码块：macOS 三点 + 语言标签 + 复制，JetBrains Mono */
function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const [copied, setCopied] = useState(false)
  const lines = code.replace(/^\n+|\n+$/g, '').split('\n')
  return (
    <div
      data-reveal
      className="overflow-hidden rounded-[14px] border border-line bg-[#0D1119] shadow-card"
    >
      <div className="flex items-center gap-2 border-b border-line px-4 py-2.5">
        <span className="h-2.5 w-2.5 rounded-full bg-[#FF5F57]" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#FEBC2E]" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#28C840]" />
        <span className="ml-2 font-mono text-xs text-fg-tertiary">{lang}</span>
        <button
          type="button"
          aria-label="复制代码"
          className="ml-auto flex h-7 w-7 items-center justify-center rounded-md text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg"
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(code.trim())
            } catch {
              /* 剪贴板不可用时静默降级 */
            }
            setCopied(true)
            toast.success('已复制')
            window.setTimeout(() => setCopied(false), 1500)
          }}
        >
          {copied ? <Check className="h-3.5 w-3.5 text-ok" /> : <Copy className="h-3.5 w-3.5" />}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 font-mono text-[13px] leading-6">
        {lines.map((line, i) => {
          const trimmed = line.trim()
          const isComment = trimmed.startsWith('#')
          const firstToken = trimmed.split(/\s+/)[0]
          const isCmd = ['git', 'pnpm', 'cp', 'curl', 'npm'].includes(firstToken)
          return (
            <div key={i} className="flex">
              <span className="w-8 shrink-0 select-none pr-3 text-right text-fg-tertiary/50">
                {i + 1}
              </span>
              {isComment ? (
                <span className="text-fg-tertiary">{line || ' '}</span>
              ) : isCmd ? (
                <span>
                  <span className="text-signal">{firstToken}</span>
                  <span className="text-fg">{line.slice(firstToken.length) || ' '}</span>
                </span>
              ) : (
                <span className="text-fg">{line || ' '}</span>
              )}
            </div>
          )
        })}
      </pre>
    </div>
  )
}

/** 提示卡 */
function Callout({
  tone,
  icon,
  children,
}: {
  tone: 'info' | 'warn' | 'party'
  icon: ReactNode
  children: ReactNode
}) {
  const styles = {
    info: 'border-l-brand bg-brand-soft text-fg-secondary [&_svg]:text-brand-hover',
    warn: 'border-l-warn bg-[rgba(251,191,36,0.10)] text-fg-secondary [&_svg]:text-warn',
    party: 'border-l-signal bg-[rgba(34,211,238,0.08)] text-fg-secondary [&_svg]:text-signal',
  } as const
  return (
    <div
      data-reveal
      className={cn('flex gap-3 rounded-r-[10px] border-l-[3px] p-4 text-sm leading-6', styles[tone])}
    >
      <span className="mt-0.5 shrink-0">{icon}</span>
      <div>{children}</div>
    </div>
  )
}

/** 完成检查：大号 checkbox，勾选后触发回调 */
function StepCheck({
  checked,
  onChange,
  label,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label: string
}) {
  return (
    <button
      type="button"
      data-reveal
      onClick={() => onChange(!checked)}
      className={cn(
        'mt-2 flex w-full items-center gap-3 rounded-[12px] border p-4 text-left transition-colors',
        checked ? 'border-ok/50 bg-[rgba(52,211,153,0.08)]' : 'border-line bg-ink-input/60 hover:border-line-strong',
      )}
    >
      <span
        className={cn(
          'flex h-6 w-6 shrink-0 items-center justify-center rounded-[7px] border-2 transition-all duration-200',
          checked ? 'border-ok bg-ok' : 'border-line-strong',
        )}
      >
        {checked && <Check className="h-4 w-4 text-ink-base" strokeWidth={3} />}
      </span>
      <span className="flex-1">
        <span className="block text-[11px] font-medium uppercase tracking-wider text-fg-tertiary">
          完成检查
        </span>
        <span className={cn('block text-sm font-medium', checked ? 'text-ok' : 'text-fg')}>
          {label}
        </span>
      </span>
    </button>
  )
}

/** 步骤区块外壳 */
function StepSection({
  id,
  num,
  icon,
  title,
  minutes,
  done,
  children,
}: {
  id: string
  num: number
  icon: ReactNode
  title: string
  minutes: number
  done: boolean
  children: ReactNode
}) {
  return (
    <section id={id} data-step className="scroll-mt-24 py-14">
      <div className="flex gap-6 md:gap-10">
        <div
          data-step-num
          aria-hidden
          className="hidden shrink-0 select-none font-display text-[96px] font-bold leading-none transition-colors duration-500 md:block"
          style={{ color: done ? 'var(--success)' : 'rgba(108,92,231,0.10)' }}
        >
          {num}
        </div>
        <div className="min-w-0 flex-1 space-y-5">
          <div data-reveal className="flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-1.5 rounded-md bg-brand-soft px-2 py-1 font-mono text-xs font-medium text-brand-hover">
              {icon}
              STEP {num}
            </span>
            <h2 className="text-[26px] font-bold leading-8 text-fg">{title}</h2>
            <span className="flex items-center gap-1 text-xs text-fg-tertiary">
              <Clock className="h-3.5 w-3.5" />
              约 {minutes} 分钟
            </span>
          </div>
          {children}
        </div>
      </div>
    </section>
  )
}

/* ======================================================================
 * 搭建教程页面（独立布局，无侧边栏）
 * ==================================================================== */

export default function Tutorial() {
  const location = useLocation()
  const rootRef = useRef<HTMLDivElement>(null)
  const lenisRef = useRef<Lenis | null>(null)
  const lineFillRef = useRef<HTMLDivElement>(null)
  const topBarRef = useRef<HTMLDivElement>(null)
  const confettiRef = useRef<HTMLDivElement>(null)
  const [activeIdx, setActiveIdx] = useState(0)
  const [done, setDone] = useState<boolean[]>([false, false, false, false, false])

  const reduced = useMemo(
    () =>
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    [],
  )

  /* ---------------- Lenis 平滑滚动 ---------------- */
  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.1 })
    lenisRef.current = lenis
    lenis.on('scroll', ScrollTrigger.update)
    const tick = (time: number) => lenis.raf(time * 1000)
    gsap.ticker.add(tick)
    gsap.ticker.lagSmoothing(0)
    return () => {
      gsap.ticker.remove(tick)
      lenis.destroy()
      lenisRef.current = null
    }
  }, [])

  /* ---------------- 滚动动画 ---------------- */
  useGSAP(
    () => {
      if (reduced) {
        // 降级：仅淡入
        gsap.utils.toArray<HTMLElement>('[data-reveal]').forEach((el) => {
          gsap.from(el, {
            opacity: 0,
            duration: 0.4,
            scrollTrigger: { trigger: el, start: 'top 90%' },
          })
        })
        return
      }

      // Hero 入场
      gsap.from('.tut-hero-badge', { y: 12, opacity: 0, duration: 0.6, ease: 'power3.out' })
      gsap.from('.tut-hero-char', {
        y: 30,
        opacity: 0,
        rotateX: -60,
        stagger: 0.06,
        duration: 0.8,
        ease: 'power3.out',
        delay: 0.15,
      })
      gsap.from('.tut-hero-sub', { y: 16, opacity: 0, duration: 0.7, delay: 0.5, ease: 'power3.out' })
      gsap.from('.tut-arch', { opacity: 0, y: 24, duration: 0.8, delay: 0.6, ease: 'power3.out' })
      gsap.to('.tut-arch-scan', {
        xPercent: 320,
        duration: 3,
        repeat: -1,
        ease: 'none',
      })
      gsap.to('.tut-scroll-hint', { y: 8, duration: 0.8, repeat: -1, yoyo: true, ease: 'power1.inOut' })

      // 步骤区块揭示
      gsap.utils.toArray<HTMLElement>('[data-step]').forEach((sec) => {
        const num = sec.querySelector('[data-step-num]')
        if (num) {
          gsap.from(num, {
            x: -40,
            opacity: 0,
            duration: 0.6,
            ease: 'power3.out',
            scrollTrigger: { trigger: sec, start: 'top 75%' },
          })
        }
        const items = sec.querySelectorAll('[data-reveal]')
        if (items.length) {
          gsap.from(items, {
            y: 32,
            opacity: 0,
            duration: 0.7,
            stagger: 0.12,
            ease: 'power3.out',
            scrollTrigger: { trigger: sec, start: 'top 75%' },
          })
        }
      })

      // FAQ / CTA 揭示
      gsap.utils.toArray<HTMLElement>('[data-block]').forEach((el) => {
        gsap.from(el, {
          y: 32,
          opacity: 0,
          duration: 0.7,
          ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 80%' },
        })
      })

      // 锚点激活追踪
      ANCHORS.forEach((a, i) => {
        ScrollTrigger.create({
          trigger: `#${a.id}`,
          start: 'top 45%',
          end: 'bottom 45%',
          onToggle: (self) => {
            if (self.isActive) setActiveIdx(i)
          },
        })
      })

      // 进度线
      ScrollTrigger.create({
        trigger: rootRef.current,
        start: 'top top',
        end: 'bottom bottom',
        onUpdate: (self) => {
          if (lineFillRef.current) {
            lineFillRef.current.style.transform = `scaleY(${self.progress})`
          }
          if (topBarRef.current) {
            topBarRef.current.style.transform = `scaleX(${self.progress})`
          }
        },
      })

      // CTA 渐变边框流光
      gsap.to('.tut-cta-ring', { rotate: 360, duration: 2, repeat: -1, ease: 'none' })
    },
    { scope: rootRef, dependencies: [reduced] },
  )

  // 支持 /tutorial#obs 等锚点直达
  useEffect(() => {
    if (!location.hash) return
    const t = window.setTimeout(() => {
      lenisRef.current?.scrollTo(location.hash, { offset: -84, duration: 0.8 })
    }, 400)
    return () => window.clearTimeout(t)
  }, [location.hash])

  const scrollToAnchor = (id: string) => {
    lenisRef.current?.scrollTo(`#${id}`, { offset: -84, duration: 0.8 })
  }

  /** 克制版 confetti：24 粒子 */
  const fireConfetti = () => {
    const box = confettiRef.current
    if (!box || reduced) return
    const colors = ['#6C5CE7', '#00C9A7', '#06B6D4', '#10B981', '#F59E0B', '#F472B6']
    for (let i = 0; i < 24; i++) {
      const p = document.createElement('span')
      p.style.cssText = `position:absolute;left:50%;top:50%;width:6px;height:10px;border-radius:2px;background:${colors[i % colors.length]};pointer-events:none;`
      box.appendChild(p)
      const angle = (Math.PI * 2 * i) / 24 + Math.random() * 0.4
      const dist = 60 + Math.random() * 90
      gsap.fromTo(
        p,
        { x: 0, y: 0, opacity: 1, rotate: 0 },
        {
          x: Math.cos(angle) * dist,
          y: Math.sin(angle) * dist - 40,
          rotate: Math.random() * 360,
          opacity: 0,
          duration: 1 + Math.random() * 0.5,
          ease: 'power2.out',
          onComplete: () => p.remove(),
        },
      )
    }
  }

  const setStepDone = (i: number, v: boolean) => {
    setDone((d) => {
      const next = [...d]
      next[i] = v
      return next
    })
    if (v && i === 4) fireConfetti()
  }

  /* ---------------- 渲染 ---------------- */
  const titleChars = 'AI 无人直播间'.split('')

  return (
    <div ref={rootRef} className="min-h-[100dvh] bg-ink-base text-fg">
      <Toaster position="top-right" />

      {/* ===== 顶部极简导航 ===== */}
      <header className="fixed inset-x-0 top-0 z-50 flex h-[60px] items-center justify-between border-b border-line bg-[rgba(16,21,30,0.8)] px-5 backdrop-blur-[12px]">
        <Link to="/" className="flex items-center gap-2.5">
          <img src="/logo.svg" alt="SoloCast" className="h-7 w-7" />
          <span className="text-sm font-bold text-fg">
            SoloCast <span className="ml-1 font-normal text-fg-tertiary">搭建教程</span>
          </span>
        </Link>
        <Link
          to="/live"
          className="flex h-9 items-center gap-1.5 rounded-[10px] px-3 text-[13px] font-medium text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          返回中控台
        </Link>
      </header>

      {/* 移动端阅读进度条（<1280px） */}
      <div className="fixed inset-x-0 top-[60px] z-50 h-[3px] bg-transparent xl:hidden">
        <div
          ref={topBarRef}
          className="h-full w-full origin-left"
          style={{ background: 'var(--accent-gradient)', transform: 'scaleX(0)' }}
        />
      </div>

      <div className="mx-auto max-w-[1120px] px-6 xl:grid xl:grid-cols-[220px_1fr] xl:gap-10">
        {/* ===== 左侧锚点进度导航 ===== */}
        <aside className="hidden xl:block">
          <div className="sticky top-28 py-10">
            <div className="relative flex flex-col gap-6 pl-5">
              {/* 进度线 */}
              <div className="absolute bottom-2 left-[5px] top-2 w-[2px] overflow-hidden rounded-full bg-line">
                <div
                  ref={lineFillRef}
                  className="h-full w-full origin-top"
                  style={{ background: 'var(--accent-gradient)', transform: 'scaleY(0)' }}
                />
              </div>
              {ANCHORS.map((a, i) => {
                const stepDone = i > 0 && done[i - 1]
                const isActive = activeIdx === i
                return (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => scrollToAnchor(a.id)}
                    className="group relative flex items-center gap-3 text-left"
                  >
                    <span
                      className={cn(
                        'absolute -left-5 h-3 w-3 rounded-full border-2 transition-all duration-300',
                        stepDone
                          ? 'border-ok bg-ok'
                          : isActive
                            ? 'scale-125 border-brand bg-brand'
                            : 'border-line-strong bg-ink-base group-hover:border-brand',
                      )}
                    />
                    <span
                      className={cn(
                        'text-[13px] transition-colors duration-300',
                        stepDone
                          ? 'text-ok'
                          : isActive
                            ? 'font-medium text-brand-hover'
                            : 'text-fg-tertiary group-hover:text-fg-secondary',
                      )}
                    >
                      {a.label}
                    </span>
                  </button>
                )
              })}
            </div>
          </div>
        </aside>

        {/* ===== 长文内容 ===== */}
        <main className="min-w-0 max-w-[760px] pt-[60px]">
          {/* ---- Hero ---- */}
          <section
            id="overview"
            className="flex min-h-[calc(100dvh-60px)] scroll-mt-20 flex-col items-center justify-center py-16 text-center"
          >
            <span className="tut-hero-badge rounded-full bg-brand-soft px-3 py-1 font-mono text-xs font-medium tracking-wider text-brand-hover">
              SETUP GUIDE · 全程约 30 分钟
            </span>
            <h1 className="mt-6 text-[40px] font-black leading-[1.2] tracking-tight text-fg">
              从零搭建你的
              <br />
              <span className="inline-block" style={{ perspective: 600 }}>
                {titleChars.map((c, i) => (
                  <span key={i} className="tut-hero-char text-gradient inline-block">
                    {c}
                  </span>
                ))}
              </span>
            </h1>
            <p className="tut-hero-sub mt-4 max-w-[520px] text-base leading-7 text-fg-secondary">
              不需要团队，不需要露脸。一台电脑 + 一个 Kimi API Key，跟着这 5 步走。
            </p>

            {/* 架构流程图 */}
            <div className="tut-arch relative mt-10 w-full overflow-hidden rounded-[14px] border border-line bg-ink-card">
              <img
                src="/tutorial-arch.svg"
                alt="SoloCast 系统架构：产品图片与介绍 → 中控台 → Kimi API → 话术 → TTS 语音 → OBS 推流 → 直播平台"
                className="w-full"
              />
              <div
                className="tut-arch-scan pointer-events-none absolute inset-y-0 left-0 w-1/4 -translate-x-full"
                style={{
                  background:
                    'linear-gradient(90deg, transparent, rgba(108,92,231,0.18), transparent)',
                }}
                aria-hidden
              />
            </div>

            <div className="tut-scroll-hint mt-12 flex flex-col items-center gap-1 text-fg-tertiary">
              <span className="text-xs">向下滚动开始</span>
              <ChevronDown className="h-4 w-4" />
            </div>
          </section>

          {/* ---- STEP 1 · 获取 Kimi API Key ---- */}
          <StepSection
            id="step-1"
            num={1}
            icon={<KeyRound className="h-3 w-3" />}
            title="获取 Kimi API Key"
            minutes={5}
            done={done[0]}
          >
            <p data-reveal className="text-[15px] leading-[1.9] text-fg-secondary">
              Kimi 是你的 AI 主播的「大脑」，负责把产品介绍变成生动的直播话术。打开{' '}
              <a
                href="https://platform.moonshot.cn"
                target="_blank"
                rel="noreferrer"
                className="text-signal underline underline-offset-4 transition-colors hover:text-brand-hover"
              >
                platform.moonshot.cn
              </a>
              ，用手机号注册一个账号；进入控制台后点击左侧「API Key 管理」→「新建 API
              Key」，给它起个名字（比如「solocast」），然后立刻复制保存——它只显示一次。
            </p>
            <Callout tone="info" icon={<Info className="h-4 w-4" />}>
              新用户赠送 15 元额度，足够测试直播数十场。Key 形如{' '}
              <code className="font-mono text-[13px] text-fg">sk-xxxxxx</code>
              ，请像保管银行卡密码一样保管它。
            </Callout>
            <StepCheck
              checked={done[0]}
              onChange={(v) => setStepDone(0, v)}
              label="我已拿到 API Key"
            />
          </StepSection>

          {/* ---- STEP 2 · 部署中控台 ---- */}
          <StepSection
            id="step-2"
            num={2}
            icon={<Server className="h-3 w-3" />}
            title="部署本控制台"
            minutes={10}
            done={done[1]}
          >
            <p data-reveal className="text-[15px] leading-[1.9] text-fg-secondary">
              SoloCast 中控台是一个跑在你自己电脑（或服务器）上的网页应用，数据完全归你所有。先确认电脑里已装好以下三样东西：
            </p>
            <div data-reveal className="flex flex-wrap gap-2">
              {['Node.js ≥ 20', 'Git', 'pnpm'].map((chip) => (
                <span
                  key={chip}
                  className="rounded-full border border-line bg-ink-input px-3 py-1 font-mono text-xs text-fg-secondary"
                >
                  {chip}
                </span>
              ))}
            </div>
            <div className="space-y-4">
              <CodeBlock
                lang="bash"
                code={`
# 1. 拉取项目
git clone https://github.com/yourname/solocast.git && cd solocast

# 2. 安装依赖
pnpm install

# 3. 配置环境变量
cp .env.example .env
`}
              />
              <CodeBlock
                lang=".env"
                code={`
# .env —— 粘贴你的 Kimi Key
KIMI_API_KEY=sk-你的Key
KIMI_BASE_URL=https://api.moonshot.cn/v1
KIMI_MODEL=moonshot-v1-8k
`}
              />
              <CodeBlock
                lang="bash"
                code={`
# 4. 初始化数据库并启动
pnpm db:push
pnpm dev   # → http://localhost:3000
`}
              />
            </div>
            <p data-reveal className="text-[15px] leading-[1.9] text-fg-secondary">
              终端出现 <code className="rounded bg-ink-input px-1.5 py-0.5 font-mono text-[13px] text-ok">Ready in 1.2s</code>{' '}
              后，用浏览器打开 <code className="rounded bg-ink-input px-1.5 py-0.5 font-mono text-[13px] text-fg">http://localhost:3000</code>，看到登录页就说明部署成功了。
            </p>
            <StepCheck
              checked={done[1]}
              onChange={(v) => setStepDone(1, v)}
              label="中控台已在本地跑起来"
            />
          </StepSection>

          {/* ---- STEP 3 · 配置 TTS ---- */}
          <StepSection
            id="step-3"
            num={3}
            icon={<Volume2 className="h-3 w-3" />}
            title="接入 TTS 语音"
            minutes={5}
            done={done[2]}
          >
            <p data-reveal className="text-[15px] leading-[1.9] text-fg-secondary">
              TTS（文字转语音）负责把 Kimi 写好的话术「念」出来。进入中控台左侧的
              <span className="mx-1 inline-flex items-center gap-1 rounded bg-ink-input px-1.5 py-0.5 text-[13px] text-fg">
                <Settings className="h-3 w-3" />
                设置中心 → TTS 配置
              </span>
              ，选择一个音色，语速保持 1.0，然后点击「试听」。听到声音满意即可，推荐新手直接用第一个。
            </p>
            <div data-reveal className="overflow-hidden rounded-[14px] border border-line">
              <table className="w-full text-left text-[13px]">
                <thead>
                  <tr className="bg-ink-elevated text-xs font-medium tracking-wider text-fg-tertiary">
                    <th className="px-4 py-2.5">音色</th>
                    <th className="px-4 py-2.5">风格</th>
                    <th className="px-4 py-2.5">适用场景</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {[
                    ['晨曦 · 亲切女声（推荐）', '温暖、有活力', '全品类带货'],
                    ['云野 · 沉稳男声', '专业、可信', '数码 3C、家电'],
                    ['晓晓 · 甜美女声', '轻快、亲近', '美妆、食品'],
                  ].map(([voice, style, scene]) => (
                    <tr key={voice} className="text-fg-secondary transition-colors hover:bg-ink-hover">
                      <td className="px-4 py-2.5 text-fg">{voice}</td>
                      <td className="px-4 py-2.5">{style}</td>
                      <td className="px-4 py-2.5">{scene}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <StepCheck
              checked={done[2]}
              onChange={(v) => setStepDone(2, v)}
              label="试听通过，声音满意"
            />
          </StepSection>

          {/* ---- STEP 4 · OBS 推流 ---- */}
          <StepSection
            id="step-4"
            num={4}
            icon={<MonitorPlay className="h-3 w-3" />}
            title="安装 OBS 并配置推流"
            minutes={8}
            done={done[3]}
          >
            <span id="obs" className="block scroll-mt-24" aria-hidden />
            <div data-reveal className="overflow-hidden rounded-[14px] border border-line">
              <img
                src="/tutorial-obs.webp"
                alt="OBS 推流配置示意：服务器地址与串流密钥连接到直播画面"
                className="w-full"
              />
            </div>
            <ol data-reveal className="space-y-3 text-[15px] leading-[1.9] text-fg-secondary">
              {[
                <>到 OBS 官网下载 <strong className="text-fg">OBS Studio</strong>（免费）并安装。</>,
                <>在「来源」面板点 <strong className="text-fg">+</strong> 添加<strong className="text-fg">窗口采集</strong>，选择浏览器中的「直播预览」窗口。</>,
                <>打开中控台「直播控制台」，复制右侧的<strong className="text-fg">服务器地址</strong>与<strong className="text-fg">串流密钥</strong>。</>,
                <>OBS「设置 → 推流」：服务选「自定义」，把地址与密钥粘贴进去。</>,
                <>点击 OBS「开始推流」，中控台推流状态点变绿即成功。</>,
              ].map((item, i) => (
                <li key={i} className="flex gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-soft font-mono text-xs font-medium text-brand-hover">
                    {i + 1}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ol>
            <Callout tone="warn" icon={<TriangleAlert className="h-4 w-4" />}>
              串流密钥等同于直播间钥匙，切勿在直播画面中展示，也不要发给任何人。一旦泄露，请立刻到直播平台后台重置。
            </Callout>
            <StepCheck
              checked={done[3]}
              onChange={(v) => setStepDone(3, v)}
              label="OBS 显示已连接推流"
            />
          </StepSection>

          {/* ---- STEP 5 · 开播与合规 ---- */}
          <StepSection
            id="step-5"
            num={5}
            icon={<Radio className="h-3 w-3" />}
            title="第一场无人直播"
            minutes={2}
            done={done[4]}
          >
            <ol data-reveal className="space-y-3 text-[15px] leading-[1.9] text-fg-secondary">
              {[
                <>到「产品管理」上传产品图片和介绍，越详细话术越好。</>,
                <>到「话术工作台」选中产品，一键生成六段直播话术并启用。</>,
                <>回到「直播控制台」，完成右侧的开播检查清单。</>,
                <>点击红色「开始直播」按钮，你的 AI 主播正式上岗。</>,
              ].map((item, i) => (
                <li key={i} className="flex gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-soft font-mono text-xs font-medium text-brand-hover">
                    {i + 1}
                  </span>
                  <span>{item}</span>
                </li>
              ))}
            </ol>
            <Callout tone="party" icon={<PartyPopper className="h-4 w-4" />}>
              至此，你的一人直播公司正式营业。去泡杯茶，让 AI 替你工作。小提醒：部分平台要求无人直播做显著标识，开播前请阅读平台合规规则。
            </Callout>
            <div className="relative" ref={confettiRef}>
              <StepCheck
                checked={done[4]}
                onChange={(v) => setStepDone(4, v)}
                label="我的 AI 主播开播了！"
              />
            </div>
          </StepSection>

          {/* ---- FAQ ---- */}
          <section data-block className="py-14">
            <h2 className="mb-6 text-[26px] font-bold leading-8 text-fg">常见问题</h2>
            <Accordion type="single" collapsible className="space-y-2">
              {FAQS.map((f, i) => (
                <AccordionItem
                  key={i}
                  value={`faq-${i}`}
                  className="rounded-[14px] border border-line bg-ink-card px-5"
                >
                  <AccordionTrigger className="py-4 text-left text-[15px] font-medium text-fg hover:no-underline">
                    {f.q}
                  </AccordionTrigger>
                  <AccordionContent className="pb-4 text-sm leading-6 text-fg-secondary">
                    {f.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </section>

          {/* ---- 页尾 CTA ---- */}
          <section data-block className="flex justify-center pb-24 pt-6">
            <div className="relative w-full max-w-[480px] overflow-hidden rounded-[20px] p-px">
              <div
                className="tut-cta-ring absolute left-1/2 top-1/2 aspect-square w-[200%] -translate-x-1/2 -translate-y-1/2"
                style={{
                  background:
                    'conic-gradient(from 0deg, #6C5CE7, #00C9A7, rgba(108,92,231,0.15), #6C5CE7)',
                }}
                aria-hidden
              />
              <div className="relative rounded-[19px] bg-ink-elevated p-10 text-center">
                <h2 className="text-[26px] font-bold text-fg">准备好了？</h2>
                <p className="mt-2 text-sm text-fg-secondary">
                  你的 AI 主播已经蓄势待发。
                </p>
                <Link
                  to="/live"
                  className="group mt-6 inline-flex h-11 items-center gap-2 rounded-[10px] px-6 text-sm font-bold text-white shadow-glow-accent transition-opacity hover:opacity-90"
                  style={{ background: 'var(--accent-gradient)' }}
                >
                  前往中控台开播
                  <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                </Link>
                <div className="mt-3">
                  <Link
                    to="/"
                    className="text-[13px] text-fg-tertiary transition-colors hover:text-fg-secondary"
                  >
                    返回数据看板
                  </Link>
                </div>
              </div>
            </div>
          </section>

          <footer className="border-t border-line py-6 text-center text-xs text-fg-tertiary">
            SoloCast · 一人公司 AI 直播中控台 — 搭建教程
          </footer>
        </main>
      </div>
    </div>
  )
}
