import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import type { LucideIcon } from 'lucide-react'
import {
  Briefcase,
  Check,
  CheckCircle2,
  ChevronDown,
  Copy,
  Download,
  Flag,
  Flame,
  Gem,
  HandMetal,
  Heart,
  Loader2,
  MessagesSquare,
  MousePointerClick,
  PackageOpen,
  Pencil,
  RefreshCw,
  Search,
  Settings2,
  SlidersHorizontal,
  Sparkles,
  Square,
  Trash2,
  Zap,
} from 'lucide-react'
import { toast } from 'sonner'
import type { inferRouterOutputs } from '@trpc/server'
import type { AppRouter } from '../../api/router'
import type { ScriptSection } from '@db/schema'
import { cn } from '@/lib/utils'
import { trpc } from '@/providers/trpc'
import { Toaster } from '@/components/ui/sonner'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Textarea } from '@/components/ui/textarea'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

/* ======================================================================
 * 类型
 * ==================================================================== */

type RouterOutputs = inferRouterOutputs<AppRouter>
type ProductRow = RouterOutputs['products']['list'][number]
type ScriptRow = RouterOutputs['scripts']['list'][number]
type SectionType = ScriptSection['type']

/* ======================================================================
 * 常量
 * ==================================================================== */

/** 六段话术元信息（顺序固定，与后端 ScriptSection.type 一一对应） */
const SECTION_META: { type: SectionType; label: string; desc: string; icon: LucideIcon }[] = [
  { type: 'welcome', label: '开场欢迎', desc: '暖场、点关注、预告福利', icon: HandMetal },
  { type: 'intro', label: '产品引入', desc: '痛点切入，引出产品', icon: PackageOpen },
  { type: 'selling', label: '卖点讲解', desc: '核心卖点逐一拆解', icon: Gem },
  { type: 'interaction', label: '互动留人', desc: '提问互动、回复话术模板', icon: MessagesSquare },
  { type: 'faq', label: '促销逼单', desc: '价格锚点、限时限量', icon: Zap },
  { type: 'closing', label: '结束预告', desc: '感谢、下场直播预告', icon: Flag },
]

const MODEL_OPTIONS = ['kimi-k2.6', 'kimi-k3'] as const

const STYLE_OPTIONS: { value: string; label: string; desc: string; icon: LucideIcon }[] = [
  { value: 'professional', label: '专业讲解风', desc: '数据参数，理性种草', icon: Briefcase },
  { value: 'bestie', label: '亲切闺蜜风', desc: '口语化，像朋友聊天', icon: Heart },
  { value: 'promo', label: '直播促销风', desc: '强逼单，倒计时氛围', icon: Flame },
]

/** 中文口播语速：约 240 字/分钟 */
const CHARS_PER_MINUTE = 240
const TOKEN_TOTAL = 500_000

const EASE_OUT_EXPO = [0.16, 1, 0.3, 1] as [number, number, number, number]
const SPRING = { type: 'spring', stiffness: 260, damping: 24 } as const

/* ======================================================================
 * 工具函数
 * ==================================================================== */

function fmtNumber(n: number) {
  return n.toLocaleString('zh-CN')
}

function fmtSpeech(chars: number) {
  const totalSec = Math.round((chars / CHARS_PER_MINUTE) * 60)
  const m = Math.floor(totalSec / 60)
  const s = totalSec % 60
  if (m === 0) return `${s}秒`
  return s === 0 ? `${m}分钟` : `${m}分${String(s).padStart(2, '0')}秒`
}

function fmtDateTime(d: Date | string) {
  const date = d instanceof Date ? d : new Date(d)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`
}

/** 按固定六段顺序整理 sections（容错：缺段返回空串） */
function orderedSections(sections: ScriptSection[]): { meta: (typeof SECTION_META)[number]; content: string }[] {
  return SECTION_META.map((meta) => ({
    meta,
    content: sections.find((s) => s.type === meta.type)?.content ?? '',
  }))
}

function totalChars(sections: ScriptSection[]) {
  return sections.reduce((n, s) => n + s.content.length, 0)
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text)
  } catch {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    document.execCommand('copy')
    document.body.removeChild(ta)
  }
}

/* ======================================================================
 * 页面作用域样式（光标闪烁 / 骨架 shimmer / 生成按钮渐变流动）
 * index.css 不可改，故在本页内注入带前缀的样式，含 prefers-reduced-motion 降级
 * ==================================================================== */

function ScopedStyles() {
  return (
    <style>{`
      .sc-caret { display:inline-block; width:9px; height:1.1em; margin-left:2px; vertical-align:-0.15em; background:var(--accent); border-radius:1px; animation:sc-caret-blink 530ms steps(1,end) infinite; }
      @keyframes sc-caret-blink { 0%,100%{opacity:1} 50%{opacity:0} }
      .sc-shimmer { background:linear-gradient(90deg, rgba(30,36,48,0.07) 25%, rgba(30,36,48,0.16) 50%, rgba(30,36,48,0.07) 75%); background-size:200% 100%; animation:sc-shimmer 1.6s linear infinite; }
      @keyframes sc-shimmer { from{background-position:200% 0} to{background-position:-200% 0} }
      .sc-gen-flow { background-image:linear-gradient(135deg,#6C5CE7 0%,#00C9A7 50%,#6C5CE7 100%); background-size:200% 200%; animation:sc-gen-flow 2s linear infinite; }
      @keyframes sc-gen-flow { 0%{background-position:0% 50%} 100%{background-position:200% 50%} }
      .sc-line-clamp { display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }
      @media (prefers-reduced-motion: reduce) {
        .sc-caret, .sc-shimmer, .sc-gen-flow { animation:none !important; }
      }
    `}</style>
  )
}

/* ======================================================================
 * 打字机引擎：把完整文本按 30–50ms/字节奏逐字 reveal
 * （文本较长时每 tick 多吐几个字，保证整场 reveal 约 16s 内完成）
 * ==================================================================== */

type RevealState = { sectionIdx: number; charCount: number; done: boolean }

function useTypewriter() {
  const [reveal, setReveal] = useState<RevealState | null>(null)
  const timerRef = useRef<number | null>(null)
  const textsRef = useRef<string[]>([])
  const onDoneRef = useRef<(() => void) | null>(null)

  const clear = useCallback(() => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current)
      timerRef.current = null
    }
  }, [])

  const finishNow = useCallback(() => {
    clear()
    setReveal((prev) => {
      if (!prev || prev.done) return prev
      return { sectionIdx: textsRef.current.length, charCount: 0, done: true }
    })
    const cb = onDoneRef.current
    onDoneRef.current = null
    cb?.()
  }, [clear])

  const run = useCallback(
    (texts: string[], onDone: () => void, instant: boolean) => {
      clear()
      textsRef.current = texts
      if (instant) {
        setReveal({ sectionIdx: texts.length, charCount: 0, done: true })
        onDone()
        return
      }
      onDoneRef.current = onDone
      const total = texts.reduce((n, t) => n + t.length, 0)
      // 40ms 基准节奏；超过 400 字时按 tick 多字吐出，把整场控制在 ~16s
      const charsPerTick = Math.max(1, Math.ceil(total / 400))
      let s = 0
      let c = 0
      setReveal({ sectionIdx: 0, charCount: 0, done: false })
      timerRef.current = window.setInterval(() => {
        c += charsPerTick
        while (s < texts.length - 1 && c >= texts[s].length) {
          c -= texts[s].length
          s += 1
        }
        if (s === texts.length - 1 && c >= texts[s].length) {
          finishNow()
          return
        }
        setReveal({ sectionIdx: s, charCount: c, done: false })
      }, 40)
    },
    [clear, finishNow],
  )

  const reset = useCallback(() => {
    clear()
    onDoneRef.current = null
    setReveal(null)
  }, [clear])

  useEffect(() => clear, [clear])

  return { reveal, run, finishNow, reset }
}

function revealProgress(texts: string[], reveal: RevealState | null) {
  const total = texts.reduce((n, t) => n + t.length, 0)
  if (total === 0) return 1
  if (!reveal) return 0
  if (reveal.done) return 1
  let doneChars = 0
  for (let i = 0; i < reveal.sectionIdx && i < texts.length; i++) doneChars += texts[i].length
  doneChars += Math.min(reveal.charCount, texts[reveal.sectionIdx]?.length ?? 0)
  return doneChars / total
}

/* ======================================================================
 * 小组件
 * ==================================================================== */

/** 生成按钮上的进度环 */
function ProgressRing({ progress }: { progress: number }) {
  const r = 8
  const c = 2 * Math.PI * r
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" className="-rotate-90">
      <circle cx="10" cy="10" r={r} fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="2.5" />
      <circle
        cx="10"
        cy="10"
        r={r}
        fill="none"
        stroke="#fff"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - Math.min(1, Math.max(0, progress)))}
        className="transition-[stroke-dashoffset] duration-300"
      />
    </svg>
  )
}

/** 克制的彩带：20 粒子、1.2s */
function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 20 }, (_, i) => ({
        id: i,
        x: 6 + Math.random() * 88,
        delay: Math.random() * 0.35,
        size: 4 + Math.random() * 4,
        color: ['#6C5CE7', '#00C9A7', '#06B6D4', '#10B981', '#F59E0B'][i % 5],
        drift: (Math.random() - 0.5) * 60,
        rotate: (Math.random() - 0.5) * 240,
      })),
    [],
  )
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-20 h-44 overflow-hidden" aria-hidden>
      {pieces.map((p) => (
        <motion.span
          key={p.id}
          className="absolute top-0 rounded-[1px]"
          style={{ left: `${p.x}%`, width: p.size, height: p.size * 0.6, background: p.color }}
          initial={{ y: -12, opacity: 1, rotate: 0 }}
          animate={{ y: 150, opacity: 0, x: p.drift, rotate: p.rotate }}
          transition={{ duration: 1.2, delay: p.delay, ease: 'easeIn' }}
        />
      ))}
    </div>
  )
}

/** Kimi Token 迷你用量条 */
function TokenMeterMini({ used }: { used: number }) {
  const pct = Math.min(100, Math.round((used / TOKEN_TOTAL) * 100))
  const color =
    pct > 90 ? 'var(--danger)' : pct > 70 ? 'var(--warning)' : undefined
  return (
    <div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-[rgba(30,36,48,0.12)]">
        <div
          className="h-full rounded-full transition-[width] duration-500"
          style={{ width: `${pct}%`, background: color ?? 'var(--accent-gradient)' }}
        />
      </div>
      <p className="mt-1.5 font-mono text-[11px] text-fg-tertiary">
        本月已用 {fmtNumber(used)} / {fmtNumber(TOKEN_TOTAL)} tokens
      </p>
    </div>
  )
}

/** 复制按钮：Copy → 绿色 Check，1.5s 还原 + Toast */
function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false)
  const timer = useRef<number | null>(null)
  useEffect(
    () => () => {
      if (timer.current !== null) window.clearTimeout(timer.current)
    },
    [],
  )
  return (
    <button
      type="button"
      title={label ?? '复制本段'}
      onClick={async (e) => {
        e.stopPropagation()
        await copyText(text)
        setCopied(true)
        toast.success('已复制')
        if (timer.current !== null) window.clearTimeout(timer.current)
        timer.current = window.setTimeout(() => setCopied(false), 1500)
      }}
      className="flex h-7 w-7 items-center justify-center rounded-md text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-ok" /> : <Copy className="h-3.5 w-3.5" />}
    </button>
  )
}

/** 状态点 */
function StatusDot({ active }: { active: boolean }) {
  return (
    <span
      className={cn('inline-block h-1.5 w-1.5 rounded-full', active ? 'bg-ok' : 'bg-fg-tertiary')}
    />
  )
}

/* ======================================================================
 * 左栏：产品列表
 * ==================================================================== */

type ProductListProps = {
  products: ProductRow[]
  scripts: ScriptRow[]
  selectedId: number | null
  onSelect: (id: number) => void
  reduce: boolean
}

function ProductListPanel({ products, scripts, selectedId, onSelect, reduce }: ProductListProps) {
  const [keyword, setKeyword] = useState('')

  /** productId -> { count, activeVersion } */
  const statsByProduct = useMemo(() => {
    const map = new Map<number, { count: number; activeVersion: number | null }>()
    for (const s of scripts) {
      const entry = map.get(s.productId) ?? { count: 0, activeVersion: null }
      entry.count += 1
      if (s.status === 'active') {
        entry.activeVersion = Math.max(entry.activeVersion ?? 0, s.version)
      }
      map.set(s.productId, entry)
    }
    return map
  }, [scripts])

  const filtered = useMemo(() => {
    const kw = keyword.trim().toLowerCase()
    if (!kw) return products
    return products.filter((p) => p.name.toLowerCase().includes(kw))
  }, [products, keyword])

  return (
    <aside className="flex w-full shrink-0 flex-col border-b border-line bg-ink-elevated md:w-[260px] md:border-b-0 md:border-r">
      <div className="shrink-0 space-y-3 p-4 pb-3">
        <h3 className="text-[15px] font-semibold leading-6 text-fg">选择产品</h3>
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-fg-tertiary" />
          <Input
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="搜索产品…"
            className="h-[34px] rounded-[10px] border-line bg-ink-input pl-8 text-[13px] placeholder:text-fg-tertiary focus-visible:border-brand"
          />
        </div>
      </div>

      <div className="min-h-0 flex-1 space-y-1 overflow-y-auto px-3 pb-3 max-md:max-h-56">
        {filtered.length === 0 && (
          <p className="px-2 py-6 text-center text-[13px] text-fg-tertiary">
            {keyword ? '没有匹配的产品' : '暂无产品'}
          </p>
        )}
        {filtered.map((p, i) => {
          const stat = statsByProduct.get(p.id)
          const active = p.id === selectedId
          return (
            <motion.button
              key={p.id}
              type="button"
              layout
              onClick={() => onSelect(p.id)}
              initial={reduce ? false : { opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={
                reduce ? { duration: 0 } : { duration: 0.3, delay: i * 0.05, ease: EASE_OUT_EXPO }
              }
              className={cn(
                'relative flex h-[72px] w-full items-center gap-3 rounded-[10px] p-2.5 text-left transition-colors duration-150',
                active ? 'bg-brand-soft' : 'hover:bg-ink-hover',
              )}
            >
              {active && (
                <motion.span
                  layoutId="sc-product-indicator"
                  className="absolute left-0 top-1/2 h-6 w-[3px] -translate-y-1/2 rounded-full bg-brand"
                  transition={SPRING}
                />
              )}
              {p.imageUrl ? (
                <img
                  src={p.imageUrl}
                  alt={p.name}
                  className="h-12 w-12 shrink-0 rounded-lg border border-line object-cover"
                />
              ) : (
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-line bg-ink-card text-fg-tertiary">
                  <PackageOpen className="h-5 w-5" />
                </div>
              )}
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium text-fg">{p.name}</span>
                <span className="mt-0.5 flex items-center gap-1.5 text-xs text-fg-tertiary">
                  <StatusDot active={p.status === 'active'} />
                  {stat && stat.count > 0 ? (
                    <span className="truncate">
                      {stat.count} 篇话术
                      {stat.activeVersion ? ` · v${stat.activeVersion} 启用中` : ' · 未启用'}
                    </span>
                  ) : (
                    <span>还没有话术</span>
                  )}
                </span>
              </span>
              {(!stat || stat.count === 0) && (
                <Sparkles className="h-4 w-4 shrink-0 text-brand" aria-label="还没生成过话术" />
              )}
            </motion.button>
          )
        })}
      </div>

      <div className="flex shrink-0 items-center justify-between border-t border-line px-4 py-3 text-xs text-fg-tertiary">
        <span>{products.length} 款产品</span>
        <Link to="/products" className="font-medium text-brand-hover transition-colors hover:text-brand">
          管理 →
        </Link>
      </div>
    </aside>
  )
}

/* ======================================================================
 * 中栏：六段话术卡
 * ==================================================================== */

type CardMode = 'normal' | 'queued' | 'pending' | 'typing'

type SectionCardProps = {
  index: number
  meta: (typeof SECTION_META)[number]
  content: string
  mode: CardMode
  showDoneCheck: boolean
  editable: boolean
  readOnlyReason: string | null
  generating: boolean
  reduce: boolean
  onSave: (type: SectionType, content: string) => Promise<void>
  onRegenerate: (index: number) => void
}

function SectionCard({
  index,
  meta,
  content,
  mode,
  showDoneCheck,
  editable,
  readOnlyReason,
  generating,
  reduce,
  onSave,
  onRegenerate,
}: SectionCardProps) {
  const [collapsed, setCollapsed] = useState(false)
  const [expanded, setExpanded] = useState(false)
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState('')
  const [saving, setSaving] = useState(false)
  const Icon = meta.icon
  const chars = content.length

  const startEdit = () => {
    setDraft(content)
    setEditing(true)
    setExpanded(true)
  }

  const handleSave = async () => {
    const text = draft.trim()
    if (!text) {
      toast.error('话术内容不能为空')
      return
    }
    setSaving(true)
    try {
      await onSave(meta.type, text)
      setEditing(false)
      toast.success('已保存')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : '保存失败，请重试')
    } finally {
      setSaving(false)
    }
  }

  const busy = mode !== 'normal'

  return (
    <motion.section
      initial={reduce ? false : { opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={reduce ? { duration: 0 } : { duration: 0.4, delay: index * 0.07, ease: EASE_OUT_EXPO }}
      className="card-shadow rounded-[14px] border border-line bg-ink-card"
    >
      {/* 头部 */}
      <div className="flex items-center gap-3 px-5 pt-4">
        <span
          className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full font-mono text-xs font-medium text-white"
          style={{ background: 'var(--accent-gradient)' }}
        >
          {index + 1}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Icon className="h-4 w-4 text-fg-tertiary" />
            <h3 className="text-[15px] font-semibold leading-6 text-fg">{meta.label}</h3>
            {showDoneCheck && <Check className="h-4 w-4 text-ok" />}
          </div>
          <p className="truncate text-xs text-fg-tertiary">{meta.desc}</p>
        </div>

        {mode === 'typing' ? (
          <span className="shrink-0 font-mono text-xs text-signal">
            生成中… 已输出 {fmtNumber(chars)} 字
          </span>
        ) : mode === 'pending' ? (
          <span className="shrink-0 text-xs text-signal">生成中…</span>
        ) : (
          <span className="hidden shrink-0 text-xs text-fg-tertiary sm:block">
            约 {fmtNumber(chars)} 字 · 播报 {fmtSpeech(chars)}
          </span>
        )}

        <div className="flex shrink-0 items-center gap-1">
          {mode === 'typing' || mode === 'pending' ? (
            <span className="flex h-7 w-7 items-center justify-center text-signal" title="生成中">
              <Square className="h-3.5 w-3.5 animate-pulse" />
            </span>
          ) : (
            <>
              <CopyButton text={content} />
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <button
                    type="button"
                    title="重新生成此段"
                    disabled={!editable || generating}
                    className="flex h-7 w-7 items-center justify-center rounded-md text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                  </button>
                </AlertDialogTrigger>
                <AlertDialogContent className="overlay-shadow rounded-[20px] border-line bg-ink-elevated">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-fg">重新生成「{meta.label}」？</AlertDialogTitle>
                    <AlertDialogDescription className="text-fg-secondary">
                      将覆盖当前段落内容，消耗约 400 tokens。
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="rounded-[10px] border-line-strong bg-ink-hover text-fg hover:bg-ink-card hover:text-fg">
                      取消
                    </AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => onRegenerate(index)}
                      className="rounded-[10px] text-white"
                      style={{ background: 'var(--accent-gradient)' }}
                    >
                      重新生成
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              <button
                type="button"
                title={readOnlyReason ?? '编辑本段'}
                disabled={!editable || generating}
                onClick={startEdit}
                className="flex h-7 w-7 items-center justify-center rounded-md text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Pencil className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                title={collapsed ? '展开' : '折叠'}
                onClick={() => setCollapsed((v) => !v)}
                className="flex h-7 w-7 items-center justify-center rounded-md text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg"
              >
                <ChevronDown
                  className={cn('h-4 w-4 transition-transform duration-300', collapsed && '-rotate-90')}
                />
              </button>
            </>
          )}
        </div>
      </div>

      {/* 正文 */}
      <motion.div
        initial={false}
        animate={{ height: collapsed ? 0 : 'auto', opacity: collapsed ? 0 : 1 }}
        transition={{ duration: reduce ? 0 : 0.3, ease: 'easeInOut' }}
        className="overflow-hidden"
      >
        <div className="px-5 pb-4 pt-3">
          {mode === 'queued' ? (
            <div className="space-y-2 py-1">
              <div className="sc-shimmer h-3.5 w-full rounded" />
              <div className="sc-shimmer h-3.5 w-11/12 rounded" />
              <div className="sc-shimmer h-3.5 w-3/5 rounded" />
            </div>
          ) : editing ? (
            <div>
              <Textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                autoFocus
                className="min-h-[140px] rounded-[10px] border-line bg-ink-input font-mono text-sm leading-[1.8] text-fg focus-visible:border-brand"
              />
              <div className="mt-3 flex items-center justify-between">
                <span className="font-mono text-xs text-fg-tertiary">字数 {fmtNumber(draft.trim().length)}</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditing(false)}
                    disabled={saving}
                    className="h-8 rounded-[10px] px-3 text-[13px] text-fg-secondary transition-colors hover:bg-ink-hover"
                  >
                    取消
                  </button>
                  <button
                    type="button"
                    onClick={handleSave}
                    disabled={saving}
                    className="flex h-8 items-center gap-1.5 rounded-[10px] px-4 text-[13px] font-medium text-white transition-all hover:shadow-glow-accent disabled:opacity-60"
                    style={{ background: 'var(--accent-gradient)' }}
                  >
                    {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                    保存
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="relative">
              <p
                className={cn(
                  'whitespace-pre-wrap text-sm leading-[1.8] text-fg-secondary',
                  !expanded && !busy && 'sc-line-clamp',
                  mode === 'pending' && 'opacity-30',
                )}
              >
                {content}
                {mode === 'typing' && <span className="sc-caret" aria-hidden />}
              </p>
              {!expanded && !busy && chars > 120 && (
                <div className="pointer-events-none absolute inset-x-0 bottom-0 flex h-10 items-end justify-center bg-gradient-to-t from-ink-card to-transparent">
                  <button
                    type="button"
                    onClick={() => setExpanded(true)}
                    className="pointer-events-auto mb-0 text-xs font-medium text-brand-hover transition-colors hover:text-brand"
                  >
                    展开全部
                  </button>
                </div>
              )}
              {expanded && !busy && chars > 120 && (
                <div className="mt-1 text-center">
                  <button
                    type="button"
                    onClick={() => setExpanded(false)}
                    className="text-xs font-medium text-fg-tertiary transition-colors hover:text-fg"
                  >
                    收起
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </motion.div>
    </motion.section>
  )
}

/* ======================================================================
 * 右栏：Kimi 生成面板
 * ==================================================================== */

export type GenState = {
  kind: 'full' | 'section'
  phase: 'requesting' | 'revealing'
  /** kind === 'section' 时目标段下标 */
  sectionIndex?: number
  /** 生成返回的完整文本（full 为六段，section 为单段） */
  sections: ScriptSection[]
  startedAt: number
  fakeIdx: number
  tokensUsed: number
}

type KimiPanelProps = {
  model: string
  onModelChange: (m: string) => void
  temperature: number
  onTemperatureChange: (t: number, commit: boolean) => void
  style: string
  onStyleChange: (s: string) => void
  minutes: number
  onMinutesChange: (m: number) => void
  extra: string
  onExtraChange: (v: string) => void
  monthUsed: number
  gen: GenState | null
  progress: number
  label: string
  liveTokens: number | null
  result: { tokensUsed: number; elapsedSec: number } | null
  error: string | null
  canGenerate: boolean
  /** framer-motion layoutId 需按挂载位置区分（桌面栏 / 抽屉可能同时挂载） */
  segLayoutId: string
  onGenerate: () => void
  onStop: () => void
}

function KimiPanel({
  model,
  onModelChange,
  temperature,
  onTemperatureChange,
  style,
  onStyleChange,
  minutes,
  onMinutesChange,
  extra,
  onExtraChange,
  monthUsed,
  gen,
  progress,
  label,
  liveTokens,
  result,
  error,
  canGenerate,
  segLayoutId,
  onGenerate,
  onStop,
}: KimiPanelProps) {
  const estTokens = Math.round(minutes * 80)
  const keyRelatedError = Boolean(error && /API Key|设置/.test(error))

  return (
    <div className="flex h-full flex-col overflow-y-auto bg-ink-elevated">
      <div className="border-b border-line px-5 py-4">
        <h3 className="text-[15px] font-semibold leading-6 text-fg">Kimi 生成引擎</h3>
        <p className="mt-0.5 text-xs text-fg-tertiary">
          由 <span className="font-mono">{model}</span> 驱动
        </p>
      </div>

      <div className="flex-1 space-y-[18px] p-5">
        {/* 1. 模型 */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium text-fg-secondary">模型</label>
          <div className="flex rounded-[10px] border border-line bg-ink-input p-1">
            {MODEL_OPTIONS.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => onModelChange(m)}
                className="relative h-8 flex-1 rounded-md"
              >
                {model === m && (
                  <motion.span
                    layoutId={segLayoutId}
                    className="absolute inset-0 rounded-md border border-brand/50 bg-brand-soft"
                    transition={SPRING}
                  />
                )}
                <span
                  className={cn(
                    'relative z-10 font-mono text-xs transition-colors',
                    model === m ? 'text-brand-hover' : 'text-fg-tertiary hover:text-fg-secondary',
                  )}
                >
                  {m}
                </span>
              </button>
            ))}
          </div>
          <p className="mt-1.5 text-xs leading-[18px] text-fg-tertiary">
            单场话术推荐 kimi-k2.6，多产品连播推荐 kimi-k3
          </p>
        </div>

        {/* 2. 创意温度 */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium text-fg-secondary">创意温度</label>
          <div className="relative pt-7">
            <span
              className={cn(
                'absolute top-0 -translate-x-1/2 whitespace-nowrap rounded-md px-1.5 py-0.5 font-mono text-[11px] transition-colors',
                temperature > 0.8 ? 'bg-brand-soft text-brand-hover' : 'bg-ink-hover text-fg-secondary',
              )}
              style={{ left: `${Math.min(88, Math.max(12, temperature * 100))}%` }}
            >
              {temperature.toFixed(2)}
              {temperature > 0.8 && ' · 更随机'}
            </span>
            <Slider
              min={0}
              max={1}
              step={0.05}
              value={[temperature]}
              onValueChange={(v) => onTemperatureChange(v[0] ?? 0, false)}
              onValueCommit={(v) => onTemperatureChange(v[0] ?? 0, true)}
            />
            <div className="mt-1.5 flex justify-between text-[11px] text-fg-tertiary">
              <span>严谨</span>
              <span>活泼</span>
            </div>
          </div>
        </div>

        {/* 3. 话术风格 */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium text-fg-secondary">话术风格</label>
          <div className="space-y-2">
            {STYLE_OPTIONS.map((opt) => {
              const active = style === opt.value
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => onStyleChange(opt.value)}
                  className={cn(
                    'flex w-full items-start gap-3 rounded-[10px] border p-3 text-left transition-all duration-150 hover:-translate-y-0.5 motion-reduce:hover:translate-y-0',
                    active
                      ? 'border-brand bg-brand-soft'
                      : 'border-line bg-ink-card hover:border-line-strong',
                  )}
                >
                  <opt.icon className={cn('mt-0.5 h-4 w-4 shrink-0', active ? 'text-brand-hover' : 'text-fg-tertiary')} />
                  <span>
                    <span className={cn('block text-[13px] font-medium', active ? 'text-fg' : 'text-fg-secondary')}>
                      {opt.label}
                    </span>
                    <span className="mt-0.5 block text-xs text-fg-tertiary">{opt.desc}</span>
                  </span>
                </button>
              )
            })}
          </div>
        </div>

        {/* 4. 单场时长 */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium text-fg-secondary">
            单场时长 <span className="ml-1 font-mono text-xs text-fg-tertiary">{minutes} 分钟</span>
          </label>
          <Slider
            min={15}
            max={120}
            step={5}
            value={[minutes]}
            onValueChange={(v) => onMinutesChange(v[0] ?? 30)}
          />
          <div className="mt-1.5 flex justify-between text-[11px] text-fg-tertiary">
            <span>15 分钟</span>
            <span>120 分钟</span>
          </div>
        </div>

        {/* 5. 附加要求 */}
        <div>
          <label className="mb-1.5 block text-[13px] font-medium text-fg-secondary">附加要求</label>
          <Textarea
            value={extra}
            onChange={(e) => onExtraChange(e.target.value)}
            rows={3}
            maxLength={120}
            placeholder="例：强调顺丰包邮；不要提竞品；多和学生党互动…"
            className="resize-none rounded-[10px] border-line bg-ink-input text-[13px] leading-relaxed placeholder:text-fg-tertiary focus-visible:border-brand"
          />
        </div>

        {/* 6. Token 预估卡 */}
        <div className="rounded-[14px] border border-line bg-ink-card p-4">
          <p className="font-mono text-[13px] leading-5 text-fg-secondary">
            预计消耗 ≈ <span className="text-fg">{fmtNumber(estTokens)}</span> tokens
          </p>
          <div className="mt-3">
            <TokenMeterMini used={monthUsed} />
          </div>
          {gen && (
            <p className="mt-3 border-t border-line pt-3 font-mono text-[13px] text-signal">
              {liveTokens === null ? (
                <span className="animate-pulse">Token 实时消耗 · 计算中…</span>
              ) : (
                <>Token 实时消耗 · {fmtNumber(liveTokens)}</>
              )}
            </p>
          )}
        </div>

        {/* 7. 主按钮 */}
        <div className="space-y-2">
          <button
            type="button"
            disabled={!canGenerate || Boolean(gen)}
            onClick={onGenerate}
            className={cn(
              'flex h-11 w-full items-center justify-center gap-2 rounded-[10px] text-sm font-medium text-white transition-all duration-150',
              gen ? 'sc-gen-flow cursor-wait' : 'hover:shadow-glow-accent active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50',
            )}
            style={gen ? undefined : { background: 'var(--accent-gradient)' }}
          >
            {gen ? (
              <>
                <ProgressRing progress={progress} />
                {label}
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                一键生成全部话术
              </>
            )}
          </button>
          {gen && (
            <button
              type="button"
              onClick={onStop}
              className="mx-auto flex items-center gap-1.5 text-xs text-fg-tertiary transition-colors hover:text-fg"
            >
              <Square className="h-3 w-3" />
              停止生成动效（Esc）
            </button>
          )}
        </div>

        {/* 错误提示 */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25, ease: EASE_OUT_EXPO }}
              className="rounded-[10px] border border-[rgba(248,113,113,0.35)] bg-[rgba(248,113,113,0.08)] p-3"
            >
              <p className="text-[13px] leading-5 text-bad">{error}</p>
              {keyRelatedError && (
                <Link
                  to="/settings"
                  className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-brand-hover transition-colors hover:text-brand"
                >
                  <Settings2 className="h-3.5 w-3.5" />
                  前往设置中心配置 →
                </Link>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* 8. 结果条 */}
        <AnimatePresence>
          {result && !gen && !error && (
            <motion.div
              initial={{ opacity: 0, y: 8, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={SPRING}
              className="flex items-start gap-2 rounded-[10px] border border-[rgba(52,211,153,0.35)] bg-[rgba(52,211,153,0.08)] p-3"
            >
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-ok" />
              <p className="text-[13px] leading-5 text-fg-secondary">
                <span className="font-medium text-ok">生成完成</span>
                <br />
                实际消耗 <span className="font-mono">{fmtNumber(result.tokensUsed)}</span> tokens ·
                用时 <span className="font-mono">{result.elapsedSec}s</span>
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

/* ======================================================================
 * 主页面
 * ==================================================================== */

export default function Scripts() {
  const reduce = useReducedMotion() ?? false
  const [searchParams] = useSearchParams()
  const utils = trpc.useUtils()
  const typewriter = useTypewriter()

  /* ---------------- 数据 ---------------- */
  const productsQuery = trpc.products.list.useQuery()
  const allScriptsQuery = trpc.scripts.list.useQuery()
  const settingsQuery = trpc.settings.get.useQuery()

  const products = useMemo(() => productsQuery.data ?? [], [productsQuery.data])
  const allScripts = useMemo(() => allScriptsQuery.data ?? [], [allScriptsQuery.data])

  const [selectedProductId, setSelectedProductId] = useState<number | null>(null)
  const [selectedScriptId, setSelectedScriptId] = useState<number | null>(null)
  const [gen, setGen] = useState<GenState | null>(null)
  const [result, setResult] = useState<{ tokensUsed: number; elapsedSec: number } | null>(null)
  const [genError, setGenError] = useState<string | null>(null)
  const [banner, setBanner] = useState(false)
  const [confettiKey, setConfettiKey] = useState(0)
  const skipRevealRef = useRef(false)
  const bannerTimer = useRef<number | null>(null)

  /* URL ?product=<id> 自动选中 */
  useEffect(() => {
    if (selectedProductId || products.length === 0) return
    const fromUrl = Number(searchParams.get('product'))
    const hit = products.find((p) => p.id === fromUrl)
    if (hit) setSelectedProductId(hit.id)
  }, [products, searchParams, selectedProductId])

  const product = products.find((p) => p.id === selectedProductId) ?? null

  const scriptsQuery = trpc.scripts.list.useQuery(
    selectedProductId ? { productId: selectedProductId } : undefined,
    { enabled: selectedProductId !== null },
  )
  const versions = useMemo(
    () => [...(scriptsQuery.data ?? [])].sort((a, b) => b.version - a.version),
    [scriptsQuery.data],
  )

  /* 产品切换时重置版本选择与生成状态 */
  useEffect(() => {
    setSelectedScriptId(null)
    setGen(null)
    setResult(null)
    setGenError(null)
    setBanner(false)
    typewriter.reset()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedProductId])

  /* 默认选中启用版本，否则最新版本 */
  useEffect(() => {
    if (versions.length === 0) {
      if (selectedScriptId !== null) setSelectedScriptId(null)
      return
    }
    if (selectedScriptId && versions.some((v) => v.id === selectedScriptId)) return
    const active = versions.find((v) => v.status === 'active')
    setSelectedScriptId((active ?? versions[0]).id)
  }, [versions, selectedScriptId])

  const script = versions.find((v) => v.id === selectedScriptId) ?? null
  const latestVersion = versions[0]?.version ?? 0
  const isLatest = script !== null && script.version === latestVersion

  /* ---------------- Kimi 面板参数（读取 settings 默认值） ---------------- */
  const [model, setModel] = useState<string>('kimi-k2.6')
  const [temperature, setTemperature] = useState(0.7)
  const [style, setStyle] = useState('bestie')
  const [minutes, setMinutes] = useState(30)
  const [extra, setExtra] = useState('')
  const settingsInitRef = useRef(false)

  const settingsUpdate = trpc.settings.update.useMutation({
    onError: (err) => toast.error(err.message),
  })

  useEffect(() => {
    const s = settingsQuery.data
    if (!s || settingsInitRef.current) return
    settingsInitRef.current = true
    if ((MODEL_OPTIONS as readonly string[]).includes(s.kimiModel)) setModel(s.kimiModel)
    const t = Number(s.temperature)
    if (Number.isFinite(t) && t >= 0 && t <= 1) setTemperature(t)
  }, [settingsQuery.data])

  const handleModelChange = (m: string) => {
    setModel(m)
    settingsUpdate.mutate({ kimiModel: m })
  }
  const handleTemperatureChange = (t: number, commit: boolean) => {
    setTemperature(t)
    if (commit) settingsUpdate.mutate({ temperature: t })
  }

  const styleString = useMemo(() => {
    const styleLabel = STYLE_OPTIONS.find((o) => o.value === style)?.label ?? style
    const parts = [`${styleLabel}`, `单场时长约 ${minutes} 分钟，总字数与之匹配`]
    if (extra.trim()) parts.push(`附加要求：${extra.trim()}`)
    return parts.join('；').slice(0, 200)
  }, [style, minutes, extra])

  const monthUsed = useMemo(() => {
    const now = new Date()
    return allScripts.reduce((n, s) => {
      const d = new Date(s.createdAt)
      return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth()
        ? n + s.tokensUsed
        : n
    }, 0)
  }, [allScripts])

  /* ---------------- 变更 ---------------- */
  const generateMut = trpc.scripts.generate.useMutation()
  const updateMut = trpc.scripts.update.useMutation()
  const removeMut = trpc.scripts.remove.useMutation()

  const finishGeneration = useCallback(
    (tokensUsed: number, startedAt: number, celebrate: boolean) => {
      setGen(null)
      typewriter.reset()
      setResult({ tokensUsed, elapsedSec: Math.max(1, Math.round((Date.now() - startedAt) / 1000)) })
      if (celebrate) {
        setBanner(true)
        setConfettiKey((k) => k + 1)
        if (bannerTimer.current !== null) window.clearTimeout(bannerTimer.current)
        bannerTimer.current = window.setTimeout(() => setBanner(false), 3500)
      }
    },
    [typewriter],
  )

  const failGeneration = useCallback(
    (err: unknown) => {
      setGen(null)
      typewriter.reset()
      const msg = err instanceof Error ? err.message : '生成失败，请稍后重试'
      setGenError(msg)
      toast.error(msg)
    },
    [typewriter],
  )

  /** 一键生成全部话术 */
  const handleGenerate = useCallback(async () => {
    if (!selectedProductId || gen) return
    setGenError(null)
    setResult(null)
    setBanner(false)
    skipRevealRef.current = false
    const startedAt = Date.now()
    setGen({ kind: 'full', phase: 'requesting', fakeIdx: 0, startedAt, tokensUsed: 0, sections: [] })
    try {
      const created = await generateMut.mutateAsync({ productId: selectedProductId, style: styleString })
      if (!created) throw new Error('生成失败：话术写入异常，请重试')
      await utils.scripts.list.invalidate()
      setSelectedScriptId(created.id)
      const texts = SECTION_META.map(
        (m) => created.sections.find((s) => s.type === m.type)?.content ?? '',
      )
      const instant = skipRevealRef.current || reduce
      setGen({
        kind: 'full',
        phase: 'revealing',
        fakeIdx: 5,
        startedAt,
        tokensUsed: created.tokensUsed,
        sections: created.sections,
      })
      typewriter.run(texts, () => finishGeneration(created.tokensUsed, startedAt, true), instant)
    } catch (err) {
      failGeneration(err)
    }
  }, [selectedProductId, gen, generateMut, styleString, utils, reduce, typewriter, finishGeneration, failGeneration])

  /** 重新生成单段：生成新版本 → 取目标段合并回当前版本 → 删除临时版本 */
  const handleRegenSection = useCallback(
    async (index: number) => {
      if (!script || !selectedProductId || gen) return
      setGenError(null)
      setResult(null)
      skipRevealRef.current = false
      const startedAt = Date.now()
      setGen({ kind: 'section', phase: 'requesting', sectionIndex: index, fakeIdx: index, startedAt, tokensUsed: 0, sections: [] })
      try {
        const created = await generateMut.mutateAsync({ productId: selectedProductId, style: styleString })
        if (!created) throw new Error('生成失败：话术写入异常，请重试')
        const targetType = SECTION_META[index].type
        const newContent = created.sections.find((s) => s.type === targetType)?.content
        if (!newContent) throw new Error('Kimi 返回的话术结构不完整，请重试')
        const merged = SECTION_META.map((m) => ({
          type: m.type,
          content:
            m.type === targetType
              ? newContent
              : script.sections.find((s) => s.type === m.type)?.content ?? '',
        }))
        if (merged.some((s) => !s.content)) throw new Error('当前话术结构不完整，无法覆盖此段')
        await updateMut.mutateAsync({ id: script.id, data: { sections: merged } })
        try {
          await removeMut.mutateAsync({ id: created.id })
        } catch {
          /* 临时版本清理失败不影响主流程 */
        }
        await utils.scripts.list.invalidate()
        const instant = skipRevealRef.current || reduce
        setGen({
          kind: 'section',
          phase: 'revealing',
          sectionIndex: index,
          fakeIdx: index,
          startedAt,
          tokensUsed: created.tokensUsed,
          sections: [{ type: targetType, content: newContent }],
        })
        typewriter.run([newContent], () => finishGeneration(created.tokensUsed, startedAt, false), instant)
      } catch (err) {
        failGeneration(err)
      }
    },
    [script, selectedProductId, gen, generateMut, updateMut, removeMut, styleString, utils, reduce, typewriter, finishGeneration, failGeneration],
  )

  /** 停止生成动效（Esc / 按钮） */
  const handleStop = useCallback(() => {
    if (!gen) return
    if (gen.phase === 'revealing') {
      typewriter.finishNow()
      toast.info('已跳过生成动效')
    } else {
      skipRevealRef.current = true
      toast.info('已跳过生成动效，完成后将直接展示结果')
    }
  }, [gen, typewriter])

  /* Esc 停止生成 */
  useEffect(() => {
    if (!gen) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleStop()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [gen, handleStop])

  /* 请求阶段的假进度（按段推进） */
  useEffect(() => {
    if (gen?.phase !== 'requesting' || gen.kind !== 'full') return
    const id = window.setInterval(() => {
      setGen((g) =>
        g && g.phase === 'requesting' && g.kind === 'full' && g.fakeIdx < 5
          ? { ...g, fakeIdx: g.fakeIdx + 1 }
          : g,
      )
    }, 1800)
    return () => window.clearInterval(id)
  }, [gen?.phase, gen?.kind])

  /** 编辑保存 */
  const handleSaveSection = useCallback(
    async (type: SectionType, content: string) => {
      if (!script) throw new Error('未选择话术版本')
      const merged = SECTION_META.map((m) => ({
        type: m.type,
        content: m.type === type ? content : script.sections.find((s) => s.type === m.type)?.content ?? '',
      }))
      if (merged.some((s) => !s.content)) throw new Error('当前话术结构不完整，无法保存')
      await updateMut.mutateAsync({ id: script.id, data: { sections: merged } })
      await utils.scripts.list.invalidate()
    },
    [script, updateMut, utils],
  )

  /** 启用 / 停用版本 */
  const handleToggleActive = async (checked: boolean) => {
    if (!script) return
    try {
      await updateMut.mutateAsync({ id: script.id, data: { status: checked ? 'active' : 'draft' } })
      await utils.scripts.list.invalidate()
      toast.success(checked ? `已启用，直播将使用 v${script.version}` : `已停用 v${script.version}`)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : '操作失败，请重试')
    }
  }

  /** 删除当前版本 */
  const handleDelete = async () => {
    if (!script) return
    try {
      await removeMut.mutateAsync({ id: script.id })
      toast.success(`已删除 v${script.version}`)
      await utils.scripts.list.invalidate()
    } catch (err) {
      toast.error(err instanceof Error ? err.message : '删除失败，请重试')
    }
  }

  /** 导出 .txt */
  const handleExport = () => {
    if (!script || !product) return
    const numCn = ['一', '二', '三', '四', '五', '六']
    const lines = [
      `${product.name} · 直播话术 v${script.version}`,
      `生成模型：${script.model ?? 'kimi'} · 导出时间：${fmtDateTime(new Date())}`,
      '',
    ]
    orderedSections(script.sections).forEach(({ meta, content }, i) => {
      lines.push(`━━━━━━ 第${numCn[i]}段 · ${meta.label} ━━━━━━`, '', content, '')
    })
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${product.name}-直播话术-v${script.version}.txt`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('已导出文本')
  }

  /* ---------------- 生成进度派生状态 ---------------- */
  const genTexts = useMemo(() => {
    if (!gen) return []
    if (gen.kind === 'full') {
      return SECTION_META.map((m) => gen.sections.find((s) => s.type === m.type)?.content ?? '')
    }
    return [gen.sections[0]?.content ?? '']
  }, [gen])

  const revealProg = gen?.phase === 'revealing' ? revealProgress(genTexts, typewriter.reveal) : 0
  const genProgress = !gen
    ? 0
    : gen.phase === 'requesting'
      ? ((gen.fakeIdx + 1) / 6) * 0.5
      : 0.5 + 0.5 * revealProg
  const liveTokens = gen
    ? gen.phase === 'revealing'
      ? Math.round(gen.tokensUsed * Math.max(0.02, revealProg))
      : null
    : null
  const genLabel = gen
    ? gen.kind === 'section'
      ? gen.phase === 'requesting'
        ? '正在重新生成该段…'
        : '正在写入新内容…'
      : gen.phase === 'requesting'
        ? `正在生成第 ${gen.fakeIdx + 1}/6 段…`
        : `正在生成第 ${Math.min((typewriter.reveal?.sectionIdx ?? 0) + 1, 6)}/6 段…`
    : ''

  const total = script ? totalChars(script.sections) : 0

  /** 每张卡的展示态 */
  const cardView = (i: number): { mode: 'normal' | 'queued' | 'pending' | 'typing'; content: string; showCheck: boolean } => {
    const base = script ? (orderedSections(script.sections)[i]?.content ?? '') : ''
    if (!gen) return { mode: 'normal', content: base, showCheck: false }
    if (gen.kind === 'full') {
      if (gen.phase === 'requesting') {
        return {
          mode: i === gen.fakeIdx && base ? 'pending' : 'queued',
          content: base,
          showCheck: i < gen.fakeIdx,
        }
      }
      const r = typewriter.reveal
      const full = genTexts[i] ?? ''
      if (!r || r.done || i < r.sectionIdx) return { mode: 'normal', content: full, showCheck: true }
      if (i === r.sectionIdx) return { mode: 'typing', content: full.slice(0, r.charCount), showCheck: false }
      return { mode: 'queued', content: '', showCheck: false }
    }
    if (gen.sectionIndex !== i) return { mode: 'normal', content: base, showCheck: false }
    if (gen.phase === 'requesting') return { mode: 'pending', content: base, showCheck: false }
    const r = typewriter.reveal
    const full = gen.sections[0]?.content ?? ''
    if (!r || r.done) return { mode: 'normal', content: full, showCheck: true }
    return { mode: 'typing', content: full.slice(0, r.charCount), showCheck: false }
  }

  const renderKimiPanel = (segLayoutId: string) => (
    <KimiPanel
      model={model}
      onModelChange={handleModelChange}
      temperature={temperature}
      onTemperatureChange={handleTemperatureChange}
      style={style}
      onStyleChange={setStyle}
      minutes={minutes}
      onMinutesChange={setMinutes}
      extra={extra}
      onExtraChange={setExtra}
      monthUsed={monthUsed}
      gen={gen}
      progress={genProgress}
      label={genLabel}
      liveTokens={liveTokens}
      result={result}
      error={genError}
      canGenerate={Boolean(selectedProductId) && !gen}
      segLayoutId={segLayoutId}
      onGenerate={handleGenerate}
      onStop={handleStop}
    />
  )

  /* ---------------- 渲染 ---------------- */
  return (
    <div className="flex h-auto flex-col md:h-[calc(100dvh-60px)] md:flex-row md:overflow-hidden">
      <ScopedStyles />
      <Toaster position="top-right" theme="light" />

      {/* 左栏：产品列表 */}
      <ProductListPanel
        products={products}
        scripts={allScripts}
        selectedId={selectedProductId}
        onSelect={setSelectedProductId}
        reduce={reduce}
      />

      {/* 中栏：话术内容区 */}
      <div className="relative min-w-0 flex-1 overflow-y-auto">
        {confettiKey > 0 && !reduce && <Confetti key={confettiKey} />}

        {/* 成功横幅 */}
        <AnimatePresence>
          {banner && (
            <motion.div
              initial={{ opacity: 0, y: -16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: EASE_OUT_EXPO }}
              className="sticky top-0 z-10 border-b border-[rgba(52,211,153,0.3)] bg-[rgba(20,30,26,0.92)] px-6 py-2.5 backdrop-blur"
            >
              <p className="flex items-center gap-2 text-[13px] text-ok">
                <CheckCircle2 className="h-4 w-4" />
                6 段话术全部生成完毕，可点击任意段落微调
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {!product ? (
          /* 空态：未选产品 */
          <div className="flex h-full min-h-[420px] flex-col items-center justify-center gap-3 p-8 text-center">
            <MousePointerClick className="h-12 w-12 text-fg-tertiary" />
            <p className="text-[15px] font-medium text-fg-secondary">从左侧选择一款产品开始</p>
            <p className="text-[13px] text-fg-tertiary">选中产品后即可查看、生成与编辑直播话术</p>
          </div>
        ) : versions.length === 0 && !gen ? (
          /* 空态：产品无话术 */
          <div className="flex h-full min-h-[420px] flex-col items-center justify-center gap-4 p-8 text-center">
            <motion.div
              initial={reduce ? false : { scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.35, ease: EASE_OUT_EXPO }}
              className="flex flex-col items-center gap-4"
            >
              <Sparkles className="h-12 w-12 text-brand" />
              <div>
                <h3 className="text-[15px] font-semibold leading-6 text-fg">还没有话术</h3>
                <p className="mt-2 max-w-[380px] text-[13px] leading-5 text-fg-tertiary">
                  点击右下角「一键生成全部话术」，Kimi 将在 30 秒内为你写好整场直播脚本
                </p>
              </div>
              <button
                type="button"
                onClick={handleGenerate}
                className="flex h-11 items-center gap-2 rounded-[10px] px-6 text-sm font-medium text-white transition-all hover:shadow-glow-accent active:scale-[0.98]"
                style={{ background: 'var(--accent-gradient)' }}
              >
                <Sparkles className="h-4 w-4" />
                立即生成
              </button>
            </motion.div>
          </div>
        ) : (
          <div className="mx-auto max-w-[860px] p-6 lg:p-8">
            {/* 头部工具条 */}
            <motion.div
              key={script?.id ?? 'gen'}
              initial={reduce ? false : { opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: EASE_OUT_EXPO }}
              className="flex flex-wrap items-start justify-between gap-4"
            >
              <div className="min-w-0">
                <h2 className="text-[17px] font-semibold leading-[26px] text-fg">{product.name}</h2>
                <p className="mt-1 text-[13px] text-fg-tertiary">
                  共 6 段 · 约 {fmtNumber(total)} 字 · 预估播报 {fmtSpeech(total)}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                {/* 版本选择器 */}
                {versions.length > 0 && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        type="button"
                        className="flex h-[38px] items-center gap-2 rounded-[10px] border border-line bg-ink-card px-3 text-[13px] text-fg-secondary transition-colors hover:border-line-strong hover:text-fg"
                      >
                        {script ? `v${script.version}${script.status === 'active' ? '（当前启用）' : ''}` : '选择版本'}
                        <ChevronDown className="h-3.5 w-3.5 text-fg-tertiary" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="end"
                      className="overlay-shadow w-[240px] rounded-[14px] border-line bg-ink-elevated p-1.5"
                    >
                      {versions.map((v) => (
                        <DropdownMenuItem
                          key={v.id}
                          onSelect={() => setSelectedScriptId(v.id)}
                          className={cn(
                            'flex cursor-pointer flex-col items-start gap-0.5 rounded-lg px-3 py-2 focus:bg-ink-hover',
                            v.id === selectedScriptId && 'bg-brand-soft',
                          )}
                        >
                          <span className="flex w-full items-center justify-between text-[13px] font-medium text-fg">
                            v{v.version}
                            {v.status === 'active' && (
                              <span className="rounded-md bg-[rgba(52,211,153,0.12)] px-1.5 py-0.5 text-[11px] font-medium text-ok">
                                启用中
                              </span>
                            )}
                          </span>
                          <span className="font-mono text-[11px] text-fg-tertiary">
                            {v.model ?? 'kimi'} · {fmtDateTime(v.createdAt)}
                          </span>
                        </DropdownMenuItem>
                      ))}
                      <DropdownMenuSeparator className="bg-line" />
                      <DropdownMenuItem disabled className="px-3 py-2 text-xs text-fg-tertiary">
                        共 {versions.length} 个版本 · 旧版本只读
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}

                {/* 导出 */}
                <button
                  type="button"
                  onClick={handleExport}
                  disabled={!script}
                  className="flex h-[38px] items-center gap-1.5 rounded-[10px] border border-line-strong bg-ink-hover px-3.5 text-[13px] font-medium text-fg-secondary transition-colors hover:text-fg disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <Download className="h-4 w-4" />
                  导出文本
                </button>

                {/* 删除 */}
                {script && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <button
                        type="button"
                        title="删除此版本"
                        className="flex h-[38px] w-[38px] items-center justify-center rounded-[10px] border border-line-strong bg-ink-hover text-fg-tertiary transition-colors hover:border-[rgba(248,113,113,0.4)] hover:text-bad"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="overlay-shadow rounded-[20px] border-line bg-ink-elevated">
                      <AlertDialogHeader>
                        <AlertDialogTitle className="text-fg">删除话术 v{script.version}？</AlertDialogTitle>
                        <AlertDialogDescription className="text-fg-secondary">
                          删除后不可恢复。{script.status === 'active' && '该版本当前处于启用状态，删除后直播将无法使用它。'}
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="rounded-[10px] border-line-strong bg-ink-hover text-fg hover:bg-ink-card hover:text-fg">
                          取消
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={handleDelete}
                          className="rounded-[10px] bg-[rgba(248,113,113,0.12)] text-bad hover:bg-[rgba(248,113,113,0.2)]"
                        >
                          确认删除
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}

                {/* 启用开关 */}
                {script && (
                  <label className="flex h-[38px] items-center gap-2 rounded-[10px] border border-line px-3 text-[13px] text-fg-secondary">
                    <Switch
                      checked={script.status === 'active'}
                      onCheckedChange={handleToggleActive}
                      disabled={updateMut.isPending}
                      aria-label="启用此版本"
                    />
                    启用此版本
                  </label>
                )}

                {/* <1280px 唤出参数抽屉 */}
                <Sheet>
                  <SheetTrigger asChild>
                    <button
                      type="button"
                      title="Kimi 生成参数"
                      className="flex h-[38px] w-[38px] items-center justify-center rounded-[10px] border border-line-strong bg-ink-hover text-fg-secondary transition-colors hover:text-fg xl:hidden"
                    >
                      <SlidersHorizontal className="h-4 w-4" />
                    </button>
                  </SheetTrigger>
                  <SheetContent className="w-[320px] border-line p-0 sm:max-w-[320px]">
                    <SheetHeader className="sr-only">
                      <SheetTitle>Kimi 生成引擎</SheetTitle>
                    </SheetHeader>
                    {renderKimiPanel('sc-model-seg-sheet')}
                  </SheetContent>
                </Sheet>
              </div>
            </motion.div>

            {!isLatest && script && (
              <p className="mt-3 rounded-[10px] border border-line bg-ink-card px-3 py-2 text-xs text-fg-tertiary">
                正在查看历史版本 v{script.version}，仅最新版本（v{latestVersion}）可编辑
              </p>
            )}

            {/* 六段话术卡 */}
            <div className="mt-6 space-y-4 pb-8">
              {SECTION_META.map((meta, i) => {
                const view = cardView(i)
                return (
                  <SectionCard
                    key={meta.type}
                    index={i}
                    meta={meta}
                    content={view.content}
                    mode={view.mode}
                    showDoneCheck={view.showCheck}
                    editable={isLatest}
                    readOnlyReason={isLatest ? null : '仅最新版本可编辑'}
                    generating={Boolean(gen)}
                    reduce={reduce}
                    onSave={handleSaveSection}
                    onRegenerate={handleRegenSection}
                  />
                )
              })}
            </div>
          </div>
        )}
      </div>

      {/* 右栏：Kimi 生成面板（≥1280px 常驻） */}
      <aside className="hidden w-[320px] shrink-0 border-l border-line xl:block">
        {renderKimiPanel('sc-model-seg-aside')}
      </aside>
    </div>
  )
}
