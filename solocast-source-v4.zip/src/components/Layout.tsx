import { useState } from 'react'
import { Outlet } from 'react-router'
import Navbar, { SIDEBAR_WIDTH, SIDEBAR_WIDTH_COLLAPSED } from './Navbar'
import Footer from './Footer'

/**
 * 控制台骨架：固定 Sidebar + sticky Topbar + 内容区。
 * 使用 <Outlet/> 嵌套路由模式 —— App.tsx 必须以 <Route element={<Layout/>}> 包裹子路由。
 * 侧边栏折叠状态在此持有，同步传给 Navbar 与内容区偏移，二者始终一致。
 */
export default function Layout() {
  const [collapsed, setCollapsed] = useState(false)
  const sidebarWidth = collapsed ? SIDEBAR_WIDTH_COLLAPSED : SIDEBAR_WIDTH

  return (
    <div className="min-h-[100dvh] bg-ink-base text-fg">
      <Navbar collapsed={collapsed} onToggleCollapse={() => setCollapsed((v) => !v)} />
      <div
        className="flex min-h-[calc(100dvh-60px)] flex-col transition-[padding-left] duration-250"
        style={{ paddingLeft: sidebarWidth }}
      >
        {/* Topbar sticky 在正常文档流中，内容区无需任何顶栏偏移 */}
        <main className="flex-1">
          <Outlet />
        </main>
        <Footer />
      </div>
    </div>
  )
}
