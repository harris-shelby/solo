import { Link } from 'react-router'

export default function Footer() {
  return (
    <footer className="border-t border-line px-6 py-5">
      <div className="mx-auto flex max-w-[1560px] flex-wrap items-center justify-between gap-3 text-xs text-fg-tertiary">
        <div className="flex items-center gap-2">
          <img src="/logo.svg" alt="SoloCast" className="h-4 w-4" />
          <span>
            SoloCast · 一人公司 AI 直播中控台 © {new Date().getFullYear()}
          </span>
        </div>
        <nav className="flex items-center gap-4">
          <Link to="/tutorial" className="transition-colors hover:text-fg-secondary">
            搭建教程
          </Link>
          <Link to="/settings" className="transition-colors hover:text-fg-secondary">
            设置中心
          </Link>
          <span className="font-mono">Powered by Kimi API</span>
        </nav>
      </div>
    </footer>
  )
}
