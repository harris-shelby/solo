import { useState } from 'react'
import { CheckCircle2, Loader2, RotateCcw, Server, XCircle } from 'lucide-react'
import { toast } from 'sonner'
import { clearApiBase, getApiBase, setApiBase, testApiBase } from '@/lib/apiBase'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

/**
 * 全局「服务器设置」浮动入口：用户自建后端时，在页面上直接填写/修改后端地址，
 * 无需重新打包前端。地址存 localStorage，保存后刷新页面生效。
 */
export default function ServerSettings() {
  const [open, setOpen] = useState(false)
  const [value, setValue] = useState('')
  const [testing, setTesting] = useState(false)
  const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null)

  const current = getApiBase()

  const openDialog = () => {
    setValue(current)
    setResult(null)
    setOpen(true)
  }

  const handleTest = async () => {
    setTesting(true)
    setResult(null)
    const r = await testApiBase(value)
    setResult(r)
    setTesting(false)
  }

  const handleSave = () => {
    const v = value.trim()
    if (!v) {
      toast.warning('请填写后端地址，或点「恢复默认」使用同源模式')
      return
    }
    setApiBase(v)
    toast.success('后端地址已保存，正在刷新…')
    setTimeout(() => window.location.reload(), 600)
  }

  const handleReset = () => {
    clearApiBase()
    toast.success('已恢复默认（同源模式），正在刷新…')
    setTimeout(() => window.location.reload(), 600)
  }

  return (
    <>
      {/* 右下角浮动按钮 */}
      <button
        type="button"
        onClick={openDialog}
        title="服务器设置（自建后端点这里）"
        className="fixed bottom-5 right-5 z-[80] flex h-11 w-11 items-center justify-center rounded-full border border-line bg-ink-card text-fg-secondary shadow-overlay transition-all hover:scale-105 hover:text-brand"
      >
        <Server className="h-5 w-5" />
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[460px]">
          <DialogHeader>
            <DialogTitle>服务器设置</DialogTitle>
            <DialogDescription>
              前端连哪个后端，在这里填写。适用于自建后端或更换后端地址的场景，保存后立即生效。
            </DialogDescription>
          </DialogHeader>

          <div className="mt-1 space-y-4">
            <div>
              <label className="mb-1.5 block text-[13px] font-medium text-fg">
                后端地址
              </label>
              <input
                value={value}
                onChange={(e) => {
                  setValue(e.target.value)
                  setResult(null)
                }}
                placeholder="https://你的后端域名（留空 = 同源模式）"
                className="h-[38px] w-full rounded-[10px] border border-line bg-ink-input px-3 font-mono-data text-[13px] text-fg outline-none transition-all placeholder:text-fg-tertiary focus:border-brand focus:shadow-[0_0_0_3px_rgba(108,92,231,0.15)]"
              />
              <p className="mt-1.5 text-xs leading-5 text-fg-tertiary">
                当前生效：<span className="font-mono-data">{current || '同源（本平台部署）'}</span>
                <br />
                自建后端时，请确保后端环境变量 ALLOWED_ORIGIN 已包含本页面域名。
              </p>
            </div>

            {result && (
              <div
                className={
                  result.ok
                    ? 'flex items-start gap-2 rounded-[10px] border border-ok/30 bg-ok/10 px-3 py-2.5 text-[13px] text-ok'
                    : 'flex items-start gap-2 rounded-[10px] border border-bad/30 bg-bad/10 px-3 py-2.5 text-[13px] text-bad'
                }
              >
                {result.ok ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                ) : (
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
                )}
                <span className="leading-5">{result.message}</span>
              </div>
            )}

            <div className="flex items-center justify-between gap-2 pt-1">
              <button
                type="button"
                onClick={handleReset}
                className="flex h-[34px] items-center gap-1.5 rounded-[8px] px-3 text-[13px] text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                恢复默认
              </button>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleTest}
                  disabled={testing}
                  className="flex h-[36px] items-center gap-1.5 rounded-[10px] border border-line-strong bg-ink-hover px-4 text-sm font-medium text-fg transition-colors hover:border-fg-tertiary/40 disabled:opacity-50"
                >
                  {testing && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                  测试连接
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  className="h-[36px] rounded-[10px] px-5 text-sm font-medium text-white shadow-glow-accent transition-all hover:brightness-110"
                  style={{ background: 'var(--accent-gradient)' }}
                >
                  保存并生效
                </button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
