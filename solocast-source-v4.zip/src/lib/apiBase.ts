/* 后端地址配置：存浏览器 localStorage，页面可随时修改，无需重新打包 */

const KEY = 'solocast_api_url'

/** 读取用户配置的后端地址（无协议/末尾斜杠自动兜底），空字符串 = 同源 */
export function getApiBase(): string {
  try {
    let v = (localStorage.getItem(KEY) || '').trim().replace(/\/+$/, '')
    if (v && !/^https?:\/\//i.test(v)) v = `https://${v}`
    return v
  } catch {
    return ''
  }
}

export function setApiBase(url: string) {
  localStorage.setItem(KEY, url.trim().replace(/\/+$/, ''))
}

export function clearApiBase() {
  localStorage.removeItem(KEY)
}

/** 拼接 API 路径：有配置走远端，无配置走同源 */
export function apiUrl(path: string): string {
  const base = getApiBase()
  return base ? `${base}${path}` : path
}

/** 测试后端连通性：能拿到任意 HTTP 响应即视为服务可达 */
export async function testApiBase(base: string): Promise<{ ok: boolean; message: string }> {
  let url = base.trim().replace(/\/+$/, '')
  if (!url) return { ok: false, message: '请先填写后端地址' }
  if (!/^https?:\/\//i.test(url)) url = `https://${url}`
  try {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 10_000)
    const res = await fetch(`${url}/api/trpc/ping`, { signal: controller.signal })
    clearTimeout(timer)
    if (res.ok) return { ok: true, message: '连接成功，后端服务正常' }
    if (res.status < 500) return { ok: true, message: `服务可达（HTTP ${res.status}），可以使用` }
    return { ok: false, message: `后端返回错误（HTTP ${res.status}），请检查后端是否正常运行` }
  } catch {
    return { ok: false, message: '无法连接到该地址，请检查：① 网址是否正确 ② 后端是否已启动 ③ 后端 ALLOWED_ORIGIN 是否已放行本页面域名' }
  }
}
