import { Suspense, lazy } from 'react'
import { Routes, Route } from 'react-router'
import Layout from './components/Layout'
import ServerSettings from './components/ServerSettings'

/* 路由级代码分割：每个页面独立成包，首屏只加载当前页所需代码 */
const Home = lazy(() => import('./pages/Home'))
const Login = lazy(() => import('./pages/Login'))
const Products = lazy(() => import('./pages/Products'))
const Scripts = lazy(() => import('./pages/Scripts'))
const Live = lazy(() => import('./pages/Live'))
const Tutorial = lazy(() => import('./pages/Tutorial'))
const Settings = lazy(() => import('./pages/Settings'))

/** 页面加载中的轻量占位：避免白屏 */
function PageFallback() {
  return (
    <div className="flex min-h-[40vh] items-center justify-center">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-line border-t-brand" />
    </div>
  )
}

export default function App() {
  return (
    <>
      {/* 全局服务器设置入口：自建后端时在页面直接填后端地址 */}
      <ServerSettings />
      <Suspense fallback={<PageFallback />}>
        <Routes>
          {/* 独立布局页：无侧边栏 */}
          <Route path="/login" element={<Login />} />
          <Route path="/tutorial" element={<Tutorial />} />

          {/* 控制台骨架：Layout 渲染 <Outlet/>，必须使用嵌套路由（pattern B） */}
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/products" element={<Products />} />
            <Route path="/scripts" element={<Scripts />} />
            <Route path="/live" element={<Live />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Routes>
      </Suspense>
    </>
  )
}
