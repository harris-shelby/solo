import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  datetime,
  bigint,
  int,
  decimal,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/* ------------------------- SoloCast 业务表 ------------------------- */

/** 直播话术六段类型 */
export type ScriptSection = {
  type: "welcome" | "intro" | "selling" | "interaction" | "faq" | "closing";
  content: string;
};

export const products = mysqlTable("products", {
  id: serial("id").primaryKey(),
  /** FK -> users.id */
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 128 }).notNull(),
  /** 产品介绍 */
  description: text("description"),
  /** 卖点 */
  sellingPoints: text("sellingPoints"),
  price: decimal("price", { precision: 10, scale: 2 }),
  /** 产品图路径，如 /product-demo-1.webp 或上传后的路径 */
  imageUrl: varchar("imageUrl", { length: 512 }),
  /** active / draft */
  status: varchar("status", { length: 16 }).notNull().default("draft"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

export const scripts = mysqlTable("scripts", {
  id: serial("id").primaryKey(),
  /** FK -> users.id */
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  /** FK -> products.id */
  productId: bigint("productId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 128 }).notNull(),
  /** 六段话术数组，见 ScriptSection */
  sections: json("sections").$type<ScriptSection[]>().notNull(),
  /** 生成所用模型 */
  model: varchar("model", { length: 64 }),
  tokensUsed: int("tokensUsed").notNull().default(0),
  /** draft / active */
  status: varchar("status", { length: 16 }).notNull().default("draft"),
  version: int("version").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Script = typeof scripts.$inferSelect;
export type InsertScript = typeof scripts.$inferInsert;

export const liveSessions = mysqlTable("liveSessions", {
  id: serial("id").primaryKey(),
  /** FK -> users.id */
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  /** FK -> scripts.id */
  scriptId: bigint("scriptId", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 128 }).notNull(),
  platform: varchar("platform", { length: 32 }).notNull().default("抖音"),
  rtmpUrl: varchar("rtmpUrl", { length: 512 }),
  streamKey: varchar("streamKey", { length: 256 }),
  plannedMinutes: int("plannedMinutes"),
  /** pending / live / ended */
  status: varchar("status", { length: 16 }).notNull().default("pending"),
  startedAt: datetime("startedAt"),
  endedAt: datetime("endedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LiveSession = typeof liveSessions.$inferSelect;
export type InsertLiveSession = typeof liveSessions.$inferInsert;

export const settings = mysqlTable("settings", {
  id: serial("id").primaryKey(),
  /** FK -> users.id（每用户一条） */
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .unique(),
  kimiBaseUrl: varchar("kimiBaseUrl", { length: 256 })
    .notNull()
    .default("https://api.moonshot.cn/v1"),
  kimiApiKey: varchar("kimiApiKey", { length: 256 }),
  kimiModel: varchar("kimiModel", { length: 64 })
    .notNull()
    .default("kimi-k2.6"),
  temperature: decimal("temperature", { precision: 3, scale: 2 })
    .notNull()
    .default("0.80"),
  ttsVoice: varchar("ttsVoice", { length: 64 })
    .notNull()
    .default("zh-CN-XiaoxiaoNeural"),
  ttsRate: decimal("ttsRate", { precision: 3, scale: 2 })
    .notNull()
    .default("1.00"),
  /** 主播名 */
  hostName: varchar("hostName", { length: 64 }),
  /** 欢迎语模板 */
  welcomeTemplate: text("welcomeTemplate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = typeof settings.$inferInsert;
