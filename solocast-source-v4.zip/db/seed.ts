import { and, eq } from "drizzle-orm";
import {
  liveSessions,
  products,
  scripts,
  users,
  type ScriptSection,
} from "./schema";
import { getDb } from "../api/queries/connection";

const DEMO_UNION_ID = "demo-solocast-user";

const DEMO_PRODUCTS = [
  {
    name: "声阔降噪蓝牙耳机 Pro",
    description:
      "旗舰级真无线降噪耳机，45dB 深度主动降噪，LDAC 高解析音质认证，单次续航 10 小时、整机 40 小时，支持无线充电与双设备同时连接，通勤、办公、运动全场景适用。",
    sellingPoints:
      "45dB 深度降噪，地铁里也能安静听歌；LDAC 金标音质，细节拉满；40 小时超长续航，一周一充；佩戴轻盈单耳仅 4.9g，久戴不痛",
    price: "399.00",
    imageUrl: "/product-demo-1.webp",
  },
  {
    name: "美厨 5L 可视空气炸锅",
    description:
      "5 升大容量可视空气炸锅，360° 热风循环免翻面，高清可视窗随时观察食物状态，8 大智能菜单一键操作，无油低脂炸烤，炸篮不粘易清洗，全家人的健康厨房神器。",
    sellingPoints:
      "可视化窗口，生熟一眼看得见；5L 大容量整鸡可烤；无油空气炸，减脂不减味；8 大智能菜单，厨房小白也能做大餐",
    price: "269.00",
    imageUrl: "/product-demo-2.webp",
  },
  {
    name: "肌研玻色因抗老精华液 30ml",
    description:
      "30% 高浓度玻色因复配胜肽的抗老精华液，质地清爽不黏腻，主打紧致淡纹、提升肌肤弹性，28 天可见改善，敏感肌友好，通过皮肤学测试。",
    sellingPoints:
      "30% 高浓度玻色因，抗老成分天花板；28 天紧致淡纹有实测数据；清爽质地油皮也爱用；敏感肌可用，温和不刺激",
    price: "189.00",
    imageUrl: "/product-demo-3.webp",
  },
  {
    name: "云南保山精品咖啡豆 500g",
    description:
      "来自云南保山高海拔庄园的精品阿拉比卡咖啡豆，中深烘焙，坚果巧克力风味带淡淡果酸，SCA 杯测 84 分，下单后 48 小时内新鲜烘焙发货，手冲意式皆宜。",
    sellingPoints:
      "SCA 杯测 84 分精品级；下单后新鲜烘焙，锁鲜直发；坚果巧克力风味，不酸不苦好入口；500g 大包装，家庭咖啡自由",
    price: "89.00",
    imageUrl: "/product-demo-4.webp",
  },
] as const;

/** 每个产品一版六段话术 */
function makeSections(
  product: (typeof DEMO_PRODUCTS)[number],
  price: string,
): ScriptSection[] {
  return [
    {
      type: "welcome",
      content: `欢迎来到直播间！我是你们的专属主播，今天给大家带来的是「${product.name}」。刚进来的家人们先点个关注，今天直播间有专属优惠价，错过可就亏大了！`,
    },
    {
      type: "intro",
      content: `先给家人们介绍一下今天的主角——${product.name}。${product.description} 平时日常价不便宜，今天直播间只要 ¥${price}，这个价格真的是谈了很久才拿下来的。`,
    },
    {
      type: "selling",
      content: `为什么推荐它？听我说完这几点你就明白了：${product.sellingPoints}。这些可都是实打实的硬实力，市面上同价位很难找到对手，懂行的家人已经悄悄下单了。`,
    },
    {
      type: "interaction",
      content: `家人们把「想要」打在公屏上！我看看有多少人喜欢。有疑问的宝宝直接在评论区问我，知无不言。现在点赞到一万，我就给大家再申请一波福利，动动手指点起来！`,
    },
    {
      type: "faq",
      content: `看到很多家人在问：质量靠不靠谱？放心吧，正品保障，支持七天无理由退换，运费险也给大家安排上了。还有问发货时间的，今天下单，48 小时内发出，部分地区次日达。`,
    },
    {
      type: "closing",
      content: `家人们，今天的优惠库存真的不多了，后台已经在提示库存告急。喜欢的宝宝抓紧时间点击购物车下单，¥${price} 的价格今天结束就恢复原价！三、二、一，没抢到的抓紧啦！`,
    },
  ];
}

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // 1. 演示用户（upsert，可重复运行）
  await db
    .insert(users)
    .values({
      unionId: DEMO_UNION_ID,
      name: "演示主播",
      email: "demo@solocast.local",
    })
    .onDuplicateKeyUpdate({ set: { name: "演示主播" } });
  const demoUser = await db.query.users.findFirst({
    where: eq(users.unionId, DEMO_UNION_ID),
  });
  if (!demoUser) throw new Error("Demo user upsert failed");
  console.log(`Demo user id=${demoUser.id}`);

  // 2. 产品（按 userId+name 查重）
  const productIds: number[] = [];
  for (const p of DEMO_PRODUCTS) {
    let product = await db.query.products.findFirst({
      where: and(eq(products.userId, demoUser.id), eq(products.name, p.name)),
    });
    if (!product) {
      const [{ id }] = await db
        .insert(products)
        .values({ ...p, userId: demoUser.id, status: "active" })
        .$returningId();
      product = await db.query.products.findFirst({
        where: eq(products.id, id),
      });
      console.log(`Inserted product: ${p.name}`);
    }
    productIds.push(product!.id);
  }

  // 3. 话术（每个产品至少一版六段话术）
  const scriptIds: number[] = [];
  for (let i = 0; i < DEMO_PRODUCTS.length; i++) {
    const productId = productIds[i];
    let script = await db.query.scripts.findFirst({
      where: and(
        eq(scripts.userId, demoUser.id),
        eq(scripts.productId, productId),
      ),
    });
    if (!script) {
      const p = DEMO_PRODUCTS[i];
      const [{ id }] = await db
        .insert(scripts)
        .values({
          userId: demoUser.id,
          productId,
          title: `${p.name} 直播话术 v1`,
          sections: makeSections(p, p.price),
          model: "kimi-k2.6",
          tokensUsed: 0,
          status: "active",
          version: 1,
        })
        .$returningId();
      script = await db.query.scripts.findFirst({
        where: eq(scripts.id, id),
      });
      console.log(`Inserted script for: ${p.name}`);
    }
    scriptIds.push(script!.id);
  }

  // 4. 直播任务（pending / live / ended 各一场，查重后插入）
  const existingSessions = await db
    .select()
    .from(liveSessions)
    .where(eq(liveSessions.userId, demoUser.id));
  if (existingSessions.length === 0) {
    const now = Date.now();
    await db.insert(liveSessions).values([
      {
        userId: demoUser.id,
        scriptId: scriptIds[0],
        title: "声阔耳机晚间首播",
        platform: "抖音",
        rtmpUrl: "rtmp://push.example.com/live/",
        streamKey: "demo-stream-key-001",
        plannedMinutes: 120,
        status: "pending",
      },
      {
        userId: demoUser.id,
        scriptId: scriptIds[1],
        title: "空气炸锅午间专场",
        platform: "抖音",
        rtmpUrl: "rtmp://push.example.com/live/",
        streamKey: "demo-stream-key-002",
        plannedMinutes: 180,
        status: "live",
        startedAt: new Date(now - 45 * 60_000),
      },
      {
        userId: demoUser.id,
        scriptId: scriptIds[2],
        title: "精华液护肤小课堂",
        platform: "快手",
        rtmpUrl: "rtmp://push.example.com/live/",
        streamKey: "demo-stream-key-003",
        plannedMinutes: 90,
        status: "ended",
        startedAt: new Date(now - 26 * 3600_000),
        endedAt: new Date(now - 26 * 3600_000 + 92 * 60_000),
      },
    ]);
    console.log("Inserted 3 live sessions (pending/live/ended)");
  }

  console.log("Done.");
  process.exit(0); // close MySQL connection pool
}

seed();
