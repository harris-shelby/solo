import { relations } from "drizzle-orm";
import { users, products, scripts, liveSessions, settings } from "./schema";

export const usersRelations = relations(users, ({ many, one }) => ({
  products: many(products),
  scripts: many(scripts),
  liveSessions: many(liveSessions),
  settings: one(settings),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  user: one(users, { fields: [products.userId], references: [users.id] }),
  scripts: many(scripts),
}));

export const scriptsRelations = relations(scripts, ({ one, many }) => ({
  user: one(users, { fields: [scripts.userId], references: [users.id] }),
  product: one(products, {
    fields: [scripts.productId],
    references: [products.id],
  }),
  liveSessions: many(liveSessions),
}));

export const liveSessionsRelations = relations(liveSessions, ({ one }) => ({
  user: one(users, { fields: [liveSessions.userId], references: [users.id] }),
  script: one(scripts, {
    fields: [liveSessions.scriptId],
    references: [scripts.id],
  }),
}));
