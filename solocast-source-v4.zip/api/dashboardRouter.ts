import { desc, eq } from "drizzle-orm";
import { liveSessions, products, scripts } from "@db/schema";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";

/** 数据看板聚合统计 */
export const dashboardRouter = createRouter({
  stats: authedQuery.query(async ({ ctx }) => {
    const userId = ctx.user.id;
    const db = getDb();

    const [productList, scriptList, sessionList] = await Promise.all([
      db.select().from(products).where(eq(products.userId, userId)),
      db
        .select()
        .from(scripts)
        .where(eq(scripts.userId, userId))
        .orderBy(desc(scripts.createdAt)),
      db
        .select()
        .from(liveSessions)
        .where(eq(liveSessions.userId, userId))
        .orderBy(desc(liveSessions.createdAt)),
    ]);

    const totalTokensUsed = scriptList.reduce(
      (sum, s) => sum + (s.tokensUsed ?? 0),
      0,
    );

    const now = Date.now();
    const totalLiveMinutes = sessionList.reduce((sum, s) => {
      if (!s.startedAt) return sum;
      const end = s.endedAt ?? (s.status === "live" ? new Date(now) : null);
      if (!end) return sum;
      return sum + Math.max(0, Math.round((end.getTime() - s.startedAt.getTime()) / 60000));
    }, 0);

    const sessionsByStatus = sessionList.reduce<Record<string, number>>(
      (acc, s) => {
        acc[s.status] = (acc[s.status] ?? 0) + 1;
        return acc;
      },
      { pending: 0, live: 0, ended: 0 },
    );

    const scriptTitles = new Map(scriptList.map((s) => [s.id, s.title]));

    return {
      productCount: productList.length,
      scriptCount: scriptList.length,
      totalTokensUsed,
      sessionCount: sessionList.length,
      totalLiveMinutes,
      sessionsByStatus,
      recentSessions: sessionList.slice(0, 5).map((s) => ({
        ...s,
        scriptTitle: scriptTitles.get(s.scriptId) ?? null,
      })),
      recentScripts: scriptList.slice(0, 5),
    };
  }),
});
