import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";
import { createRouter, authedQuery } from "./middleware";
import { env } from "./lib/env";

/** 常用中文音色白名单（Edge TTS，与设置页可选项一致，外加兜底） */
const ALLOWED_VOICES = new Set([
  "zh-CN-XiaoxiaoNeural",
  "zh-CN-YunjianNeural",
  "zh-CN-XiaoyiNeural",
  "zh-CN-YunxiNeural",
  "zh-CN-XiaoxiaoMultilingualNeural",
  "zh-CN-liaoning-XiaobeiNeural",
  "zh-CN-shaanxi-XiaoniNeural",
]);

/** 引擎一：微软 Edge TTS（免费在线通道） */
async function synthesizeEdge(text: string, voice: string, rate: number): Promise<Buffer> {
  const tts = new MsEdgeTTS();
  try {
    await tts.setMetadata(voice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
    // msedge-tts 的 rate 为相对偏移：0 = 默认语速，0.2 = +20%
    const edgeRate = Math.min(1, Math.max(-0.5, rate - 1));
    const { audioStream } = await tts.toStream(text, { rate: edgeRate });
    const chunks: Buffer[] = [];
    for await (const chunk of audioStream) {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    }
    const audio = Buffer.concat(chunks);
    if (audio.length === 0) {
      throw new Error("empty audio");
    }
    return audio;
  } finally {
    try {
      await tts.close();
    } catch {
      // 忽略关闭异常
    }
  }
}

/** 引擎二：阿里云百炼 CosyVoice（专业付费 TTS，中文直播场景音质更好） */
async function synthesizeCosyVoice(text: string, rate: number): Promise<Buffer> {
  if (!env.ttsApiKey) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: "未配置 TTS_API_KEY（阿里云百炼 API Key），请在 .env 中设置后重启服务",
    });
  }

  const resp = await fetch(
    "https://dashscope.aliyuncs.com/api/v1/services/audio/tts/SpeechSynthesizer",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.ttsApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: env.ttsModel,
        input: {
          text,
          voice: env.ttsVoice,
          format: "mp3",
          sample_rate: 22050,
          rate: Math.min(2, Math.max(0.5, rate)),
        },
      }),
      signal: AbortSignal.timeout(30_000),
    },
  );

  if (!resp.ok) {
    const text2 = await resp.text().catch(() => "");
    if (resp.status === 401 || resp.status === 403) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "阿里云百炼 API Key 无效或未开通语音合成服务，请到百炼控制台检查",
      });
    }
    throw new Error(`CosyVoice HTTP ${resp.status}: ${text2.slice(0, 200)}`);
  }

  const data = (await resp.json()) as {
    output?: { audio?: { url?: string } };
    code?: string;
    message?: string;
  };
  const audioUrl = data.output?.audio?.url;
  if (!audioUrl) {
    throw new Error(
      `CosyVoice 未返回音频地址：${data.code ?? ""} ${data.message ?? "未知错误"}`,
    );
  }

  const audioResp = await fetch(audioUrl, { signal: AbortSignal.timeout(30_000) });
  if (!audioResp.ok) {
    throw new Error(`音频下载失败 (${audioResp.status})`);
  }
  const audio = Buffer.from(await audioResp.arrayBuffer());
  if (audio.length === 0) {
    throw new Error("empty audio");
  }
  return audio;
}

async function synthesize(text: string, voice: string, rate: number): Promise<Buffer> {
  if (env.ttsEngine === "cosyvoice") {
    return synthesizeCosyVoice(text, rate);
  }
  return synthesizeEdge(text, voice, rate);
}

export const ttsRouter = createRouter({
  /**
   * 试听语音：按 TTS_ENGINE 选择引擎合成中文语音，返回 base64 MP3。
   * edge = 微软免费在线通道；cosyvoice = 阿里云百炼专业 TTS（付费，音质更好）。
   */
  preview: authedQuery
    .input(
      z.object({
        text: z.string().min(1, "试听文本不能为空").max(300, "试听文本最多 300 字"),
        voice: z.string().max(64),
        rate: z.number().min(0.5).max(2).default(1),
      }),
    )
    .mutation(async ({ input }) => {
      const voice = ALLOWED_VOICES.has(input.voice) ? input.voice : "zh-CN-XiaoxiaoNeural";
      try {
        const audio = await synthesize(input.text, voice, input.rate);
        return { audioBase64: audio.toString("base64"), mime: "audio/mpeg" };
      } catch (err) {
        if (err instanceof TRPCError) throw err;
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message:
            env.ttsEngine === "cosyvoice"
              ? "CosyVoice 语音合成失败，请检查 API Key 额度与网络后重试"
              : "语音合成服务暂时不可用，请稍后重试（Edge TTS 为免费通道，偶发限流）",
          cause: err,
        });
      }
    }),

  /** 当前 TTS 引擎与可用音色列表（供前端展示） */
  voices: authedQuery.query(() => ({
    engine: env.ttsEngine,
    model: env.ttsEngine === "cosyvoice" ? env.ttsModel : undefined,
    voices:
      env.ttsEngine === "cosyvoice"
        ? [
            { id: env.ttsVoice, name: `CosyVoice · ${env.ttsVoice}`, desc: `阿里云百炼 ${env.ttsModel}，音色可在 .env 的 TTS_VOICE 中更换` },
          ]
        : [
            { id: "zh-CN-XiaoxiaoNeural", name: "晨曦", desc: "女声 · 亲切活泼，直播带货常用" },
            { id: "zh-CN-YunjianNeural", name: "云舟", desc: "男声 · 磁性稳重，数码家电合适" },
            { id: "zh-CN-XiaoyiNeural", name: "小满", desc: "女声 · 温柔知性，美妆个护合适" },
            { id: "zh-CN-YunxiNeural", name: "老白", desc: "男声 · 年轻轻快，食品百货合适" },
          ],
  })),
});
