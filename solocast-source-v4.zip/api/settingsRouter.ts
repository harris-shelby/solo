import { TRPCError } from "@trpc/server";
import { z } from "zod";
import type { Settings } from "@db/schema";
import { createRouter, authedQuery } from "./middleware";
import { testKimiConnection } from "./kimiClient";
import { getOrCreateSettings, updateSettings } from "./queries/settings";

/** 脱敏 API Key：只保留前 4 后 4 位 */
function maskApiKey(key: string | null): string {
  if (!key) return "";
  if (key.length <= 8) return "****";
  return `${key.slice(0, 4)}****${key.slice(-4)}`;
}

function toPublicSettings(settings: Settings) {
  const { kimiApiKey, ...rest } = settings;
  return {
    ...rest,
    kimiApiKey: maskApiKey(kimiApiKey),
    hasKey: Boolean(kimiApiKey),
  };
}

export const settingsRouter = createRouter({
  /** 获取当前用户设置（不存在则按默认值创建），API Key 脱敏返回 */
  get: authedQuery.query(async ({ ctx }) => {
    const settings = await getOrCreateSettings(ctx.user.id);
    return toPublicSettings(settings);
  }),

  update: authedQuery
    .input(
      z.object({
        kimiBaseUrl: z.string().url("Base URL 格式不正确").max(256).optional(),
        kimiApiKey: z.string().max(256).optional(),
        kimiModel: z.string().min(1).max(64).optional(),
        temperature: z.number().min(0).max(2).optional(),
        ttsVoice: z.string().max(64).optional(),
        ttsRate: z.number().min(0.5).max(2).optional(),
        hostName: z.string().max(64).optional(),
        welcomeTemplate: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.user.id;
      await getOrCreateSettings(userId);
      const { kimiApiKey, temperature, ttsRate, ...rest } = input;
      await updateSettings(userId, {
        ...rest,
        ...(temperature !== undefined
          ? { temperature: temperature.toFixed(2) }
          : {}),
        ...(ttsRate !== undefined ? { ttsRate: ttsRate.toFixed(2) } : {}),
        // 仅当传入非脱敏格式（不含 *）的新 Key 时才更新
        ...(kimiApiKey !== undefined && !kimiApiKey.includes("*")
          ? { kimiApiKey }
          : {}),
      });
      const updated = await getOrCreateSettings(userId);
      return toPublicSettings(updated);
    }),

  /** 用保存的配置请求 Kimi GET /models 测试连通性 */
  testConnection: authedQuery.mutation(async ({ ctx }) => {
    const settings = await getOrCreateSettings(ctx.user.id);
    if (!settings.kimiApiKey) {
      throw new TRPCError({
        code: "PRECONDITION_FAILED",
        message: "尚未配置 Kimi API Key，请先填写并保存后再测试",
      });
    }
    return testKimiConnection(settings);
  }),
});
