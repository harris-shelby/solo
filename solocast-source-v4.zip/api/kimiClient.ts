import { TRPCError } from "@trpc/server";
import { z } from "zod";
import type { Product, ScriptSection, Settings } from "@db/schema";

const KIMI_TIMEOUT_MS = 60_000;

/** OpenAI 兼容 chat/completions 响应（只取需要的字段） */
const chatCompletionSchema = z.object({
  choices: z.array(
    z.object({
      message: z.object({ content: z.string() }),
    }),
  ),
  usage: z
    .object({
      total_tokens: z.number().optional(),
    })
    .optional(),
});

const sectionTypes = [
  "welcome",
  "intro",
  "selling",
  "interaction",
  "faq",
  "closing",
] as const;

const sectionsSchema = z
  .array(z.object({ type: z.enum(sectionTypes), content: z.string() }))
  .length(6);

const sectionLabels: Record<(typeof sectionTypes)[number], string> = {
  welcome: "欢迎话术",
  intro: "产品介绍",
  selling: "卖点讲解",
  interaction: "互动话术",
  faq: "常见问题答疑",
  closing: "促单收尾",
};

function normalizeBaseUrl(baseUrl: string) {
  return baseUrl.replace(/\/+$/, "");
}

/**
 * 从模型输出中提取纯 JSON 文本：优先取 ```json 代码块，否则取第一个 { 到最后一个 }。
 */
function extractJson(content: string): unknown {
  const fenced = content.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenced ? fenced[1] : content;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) {
    throw new Error("no-json");
  }
  return JSON.parse(candidate.slice(start, end + 1));
}

/** 把模型返回的 JSON 解析为六段话术，兼容 {sections:[...]} 与直接数组两种结构 */
export function parseSections(content: string): ScriptSection[] {
  let parsed: unknown;
  try {
    parsed = extractJson(content);
  } catch {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Kimi 返回的内容不是有效 JSON，请重试生成",
    });
  }
  const raw =
    parsed && typeof parsed === "object" && "sections" in parsed
      ? (parsed as { sections: unknown }).sections
      : parsed;
  const result = sectionsSchema.safeParse(raw);
  if (!result.success) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Kimi 返回的话术结构不完整（应为六段话术），请重试生成",
    });
  }
  return result.data;
}

async function requestKimi(
  settings: Settings,
  path: string,
  init: RequestInit,
  timeoutMs = KIMI_TIMEOUT_MS,
): Promise<unknown> {
  if (!settings.kimiApiKey) {
    throw new TRPCError({
      code: "PRECONDITION_FAILED",
      message: "尚未配置 Kimi API Key，请先到「设置中心」填写后再试",
    });
  }
  let res: Response;
  try {
    res = await fetch(`${normalizeBaseUrl(settings.kimiBaseUrl)}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${settings.kimiApiKey}`,
        ...init.headers,
      },
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (err) {
    const isTimeout = err instanceof Error && err.name === "TimeoutError";
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: isTimeout
        ? `调用 Kimi API 超时（${Math.round(timeoutMs / 1000)} 秒），请稍后重试`
        : "无法连接 Kimi API，请检查设置中的 Base URL 是否正确",
    });
  }
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    if (res.status === 401 || res.status === 403) {
      throw new TRPCError({
        code: "UNAUTHORIZED",
        message: "Kimi API Key 无效或已过期，请到「设置中心」更新",
      });
    }
    if (res.status === 429) {
      throw new TRPCError({
        code: "TOO_MANY_REQUESTS",
        message: "Kimi API 触发限流，请稍后重试",
      });
    }
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: `Kimi API 请求失败（HTTP ${res.status}）${body ? `：${body.slice(0, 200)}` : ""}`,
    });
  }
  return res.json();
}

export type KimiGenerateResult = {
  sections: ScriptSection[];
  tokensUsed: number;
  model: string;
};

/** 调用 Kimi 生成六段直播话术 */
export async function generateLiveScript(
  settings: Settings,
  product: Product,
  style?: string,
): Promise<KimiGenerateResult> {
  const model = settings.kimiModel || "kimi-k2.6";
  const systemPrompt = [
    "你是一位资深直播带货主播兼话术策划，擅长写节奏紧凑、口语化、有感染力的中文直播话术。",
    "请根据用户给出的产品信息，生成一套完整的无人直播话术，固定包含以下六段（顺序不可变）：",
    sectionTypes.map((t) => `- ${t}（${sectionLabels[t]}）`).join("\n"),
    "输出要求：只输出纯 JSON，不要输出任何额外文字、解释或 Markdown 代码块。",
    'JSON 格式：{"sections":[{"type":"welcome","content":"..."},{"type":"intro","content":"..."},{"type":"selling","content":"..."},{"type":"interaction","content":"..."},{"type":"faq","content":"..."},{"type":"closing","content":"..."}]}',
    "每段 content 为 100~300 字的口播文案，可直接朗读。",
  ].join("\n");

  const userPrompt = [
    `产品名称：${product.name}`,
    product.description ? `产品介绍：${product.description}` : "",
    product.sellingPoints ? `核心卖点：${product.sellingPoints}` : "",
    product.price ? `价格：¥${product.price}` : "",
    style ? `话术风格要求：${style}` : "",
    "请生成六段话术 JSON。",
  ]
    .filter(Boolean)
    .join("\n");

  const data = await requestKimi(settings, "/chat/completions", {
    method: "POST",
    body: JSON.stringify({
      model,
      temperature: Number(settings.temperature ?? 0.8),
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    }),
  });

  const completion = chatCompletionSchema.safeParse(data);
  if (!completion.success || completion.data.choices.length === 0) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Kimi 返回了无法识别的响应，请重试",
    });
  }
  const content = completion.data.choices[0].message.content;
  return {
    sections: parseSections(content),
    tokensUsed: completion.data.usage?.total_tokens ?? 0,
    model,
  };
}

const modelListSchema = z.object({
  data: z.array(z.object({ id: z.string() })).optional(),
});

/** 用保存的配置请求 GET /models 测试连通性，返回可用模型数量 */
export async function testKimiConnection(
  settings: Settings,
): Promise<{ success: boolean; modelCount: number; message: string }> {
  const data = await requestKimi(
    settings,
    "/models",
    { method: "GET" },
    30_000,
  );
  const parsed = modelListSchema.safeParse(data);
  const modelCount = parsed.success ? (parsed.data.data?.length ?? 0) : 0;
  return {
    success: true,
    modelCount,
    message: `连接成功，当前账号可用模型 ${modelCount} 个`,
  };
}
