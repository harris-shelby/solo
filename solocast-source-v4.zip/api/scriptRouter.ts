import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { generateLiveScript } from "./kimiClient";
import { findProductById } from "./queries/products";
import { getOrCreateSettings } from "./queries/settings";
import {
  countScriptsByProduct,
  createScript,
  findScriptById,
  findScriptsByUser,
  removeScript,
  updateScript,
} from "./queries/scripts";

const sectionSchema = z.object({
  type: z.enum(["welcome", "intro", "selling", "interaction", "faq", "closing"]),
  content: z.string().min(1, "话术内容不能为空"),
});

export const scriptRouter = createRouter({
  list: authedQuery
    .input(z.object({ productId: z.number().int().positive().optional() }).optional())
    .query(({ ctx, input }) => findScriptsByUser(ctx.user.id, input?.productId)),

  get: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      const script = await findScriptById(input.id, ctx.user.id);
      if (!script) {
        throw new TRPCError({ code: "NOT_FOUND", message: "话术不存在" });
      }
      return script;
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number().int().positive(),
        data: z.object({
          title: z.string().min(1).max(128).optional(),
          sections: z.array(sectionSchema).length(6, "话术必须为六段").optional(),
          status: z.enum(["draft", "active"]).optional(),
        }),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const existing = await findScriptById(input.id, ctx.user.id);
      if (!existing) {
        throw new TRPCError({ code: "NOT_FOUND", message: "话术不存在" });
      }
      return updateScript(input.id, ctx.user.id, input.data);
    }),

  remove: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const existing = await findScriptById(input.id, ctx.user.id);
      if (!existing) {
        throw new TRPCError({ code: "NOT_FOUND", message: "话术不存在" });
      }
      await removeScript(input.id, ctx.user.id);
      return { success: true };
    }),

  /** 调用 Kimi API 为产品生成六段直播话术并落库为新版本 */
  generate: authedQuery
    .input(
      z.object({
        productId: z.number().int().positive(),
        style: z.string().max(200).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const userId = ctx.user.id;
      const product = await findProductById(input.productId, userId);
      if (!product) {
        throw new TRPCError({ code: "NOT_FOUND", message: "产品不存在" });
      }
      const settings = await getOrCreateSettings(userId);
      const result = await generateLiveScript(settings, product, input.style);
      const version = (await countScriptsByProduct(product.id, userId)) + 1;
      return createScript({
        userId,
        productId: product.id,
        title: `${product.name} 直播话术 v${version}`,
        sections: result.sections,
        model: result.model,
        tokensUsed: result.tokensUsed,
        status: "draft",
        version,
      });
    }),
});
