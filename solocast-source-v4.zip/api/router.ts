import { authRouter } from "./auth-router";
import { dashboardRouter } from "./dashboardRouter";
import { liveRouter } from "./liveRouter";
import { createRouter, publicQuery } from "./middleware";
import { productRouter } from "./productRouter";
import { scriptRouter } from "./scriptRouter";
import { settingsRouter } from "./settingsRouter";
import { ttsRouter } from "./ttsRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  products: productRouter,
  scripts: scriptRouter,
  live: liveRouter,
  settings: settingsRouter,
  dashboard: dashboardRouter,
  tts: ttsRouter,
});

export type AppRouter = typeof appRouter;
