import { createHash, timingSafeEqual } from "crypto";
import type { Context } from "hono";
import { setCookie } from "hono/cookie";
import { env } from "../lib/env";
import { getSessionCookieOptions } from "../lib/cookies";
import { Session } from "@contracts/constants";
import { signSessionToken } from "./session";
import { upsertUser } from "../queries/users";

/**
 * 本地密码登录（自建后端场景）。
 * Kimi OAuth 的回调地址在平台侧仅注册了平台域名，
 * 自建域名无法通过 token 交换校验，因此提供管理员密码登录作为替代。
 * 在 .env 中配置 ADMIN_PASSWORD 即可启用。
 */

// 简单内存限流：每个 IP 5 分钟内最多 10 次尝试
const attempts = new Map<string, { count: number; resetAt: number }>();
const WINDOW_MS = 5 * 60 * 1000;
const MAX_ATTEMPTS = 10;

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const rec = attempts.get(ip);
  if (!rec || rec.resetAt < now) {
    attempts.set(ip, { count: 1, resetAt: now + WINDOW_MS });
    return false;
  }
  rec.count += 1;
  return rec.count > MAX_ATTEMPTS;
}

function passwordMatch(input: string, expected: string): boolean {
  const a = createHash("sha256").update(input).digest();
  const b = createHash("sha256").update(expected).digest();
  return timingSafeEqual(a, b);
}

export function createLocalLoginHandler() {
  return async (c: Context) => {
    if (!env.adminPassword) {
      return c.json(
        { error: "服务器未配置 ADMIN_PASSWORD，请在 .env 中设置管理员密码" },
        503,
      );
    }

    const ip =
      c.req.header("cf-connecting-ip") ??
      c.req.header("x-forwarded-for")?.split(",")[0]?.trim() ??
      "unknown";
    if (isRateLimited(ip)) {
      return c.json({ error: "尝试过于频繁，请 5 分钟后再试" }, 429);
    }

    let password = "";
    try {
      const body = await c.req.json<{ password?: string }>();
      password = body.password ?? "";
    } catch {
      return c.json({ error: "请求格式错误" }, 400);
    }

    if (!passwordMatch(password, env.adminPassword)) {
      return c.json({ error: "密码错误" }, 401);
    }

    // 以站点拥有者身份登录（OWNER_UNION_ID），自动获得 admin 角色
    const unionId = env.ownerUnionId || "local-admin";
    await upsertUser({
      unionId,
      name: "管理员",
      lastSignInAt: new Date(),
    });

    const token = await signSessionToken({ unionId, clientId: env.appId });
    setCookie(c, Session.cookieName, token, {
      ...getSessionCookieOptions(c.req.raw.headers),
      maxAge: Session.maxAgeMs / 1000,
    });

    return c.json({ ok: true });
  };
}
