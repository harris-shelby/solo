import "dotenv/config";

function required(name: string): string {
  const value = process.env[name];
  if (!value && process.env.NODE_ENV === "production") {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value ?? "";
}

export const env = {
  appId: required("APP_ID"),
  appSecret: required("APP_SECRET"),
  isProduction: process.env.NODE_ENV === "production",
  databaseUrl: required("DATABASE_URL"),
  kimiAuthUrl: required("KIMI_AUTH_URL"),
  kimiOpenUrl: required("KIMI_OPEN_URL"),
  ownerUnionId: process.env.OWNER_UNION_ID ?? "",
  adminPassword: process.env.ADMIN_PASSWORD ?? "",
  // TTS 引擎：edge（免费在线，默认）/ cosyvoice（阿里云百炼专业 TTS）
  ttsEngine: process.env.TTS_ENGINE ?? "edge",
  ttsApiKey: process.env.TTS_API_KEY ?? "",
  ttsModel: process.env.TTS_MODEL ?? "cosyvoice-v3.5-flash",
  ttsVoice: process.env.TTS_VOICE ?? "longanyang",
};
