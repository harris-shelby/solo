import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  createProduct,
  findProductById,
  findProductsByUser,
  removeProduct,
  updateProduct,
} from "./queries/products";

const productInput = z.object({
  name: z.string().min(1, "产品名称不能为空").max(128),
  description: z.string().optional(),
  sellingPoints: z.string().optional(),
  price: z.number().nonnegative().optional(),
  imageUrl: z.string().max(512).optional(),
  status: z.enum(["active", "draft"]).optional(),
});

export const productRouter = createRouter({
  list: authedQuery.query(({ ctx }) => findProductsByUser(ctx.user.id)),

  create: authedQuery.input(productInput).mutation(async ({ ctx, input }) => {
    const { price, ...rest } = input;
    return createProduct({
      ...rest,
      userId: ctx.user.id,
      ...(price !== undefined ? { price: price.toFixed(2) } : {}),
    });
  }),

  update: authedQuery
    .input(z.object({ id: z.number().int().positive(), data: productInput.partial() }))
    .mutation(async ({ ctx, input }) => {
      const existing = await findProductById(input.id, ctx.user.id);
      if (!existing) {
        throw new TRPCError({ code: "NOT_FOUND", message: "产品不存在" });
      }
      const { price, ...rest } = input.data;
      return updateProduct(input.id, ctx.user.id, {
        ...rest,
        ...(price !== undefined ? { price: price.toFixed(2) } : {}),
      });
    }),

  remove: authedQuery
    .input(z.object({ id: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const existing = await findProductById(input.id, ctx.user.id);
      if (!existing) {
        throw new TRPCError({ code: "NOT_FOUND", message: "产品不存在" });
      }
      await removeProduct(input.id, ctx.user.id);
      return { success: true };
    }),
});
