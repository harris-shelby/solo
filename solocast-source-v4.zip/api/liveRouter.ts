import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  createSession,
  findLiveSessionByUser,
  findSessionById,
  findSessionsByUser,
  removeSession,
  updateSession,
} from "./queries/liveSessions";
import { findScriptById } from "./queries/scripts";

const idInput = z.object({ id: z.number().int().positive() });

async function requireSession(id: number, userId: number) {
  const session = await findSessionById(id, userId);
  if (!session) {
    throw new TRPCError({ code: "NOT_FOUND", message: "直播任务不存在" });
  }
  return session;
}

export const liveRouter = createRouter({
  list: authedQuery.query(({ ctx }) => findSessionsByUser(ctx.user.id)),

  create: authedQuery
    .input(
      z.object({
        scriptId: z.number().int().positive(),
        title: z.string().min(1, "直播标题不能为空").max(128),
        platform: z.string().max(32).optional(),
        rtmpUrl: z.string().max(512).optional(),
        streamKey: z.string().max(256).optional(),
        plannedMinutes: z.number().int().positive().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const script = await findScriptById(input.scriptId, ctx.user.id);
      if (!script) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "所选话术不存在，请先为产品生成话术",
        });
      }
      return createSession({ ...input, userId: ctx.user.id });
    }),

  /** 开播：置为 live 并记录开始时间；同用户同一时间只允许一场直播中 */
  start: authedQuery.input(idInput).mutation(async ({ ctx, input }) => {
    const session = await requireSession(input.id, ctx.user.id);
    if (session.status === "live") {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "该任务已在直播中",
      });
    }
    if (session.status === "ended") {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "已结束的直播不能重新开播，请新建直播任务",
      });
    }
    const running = await findLiveSessionByUser(ctx.user.id);
    if (running) {
      throw new TRPCError({
        code: "CONFLICT",
        message: `已有直播任务「${running.title}」正在进行中，请先结束后再开播`,
      });
    }
    return updateSession(input.id, ctx.user.id, {
      status: "live",
      startedAt: new Date(),
    });
  }),

  /** 结束直播：置为 ended 并记录结束时间 */
  stop: authedQuery.input(idInput).mutation(async ({ ctx, input }) => {
    const session = await requireSession(input.id, ctx.user.id);
    if (session.status !== "live") {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "只有直播中的任务才能结束",
      });
    }
    return updateSession(input.id, ctx.user.id, {
      status: "ended",
      endedAt: new Date(),
    });
  }),

  remove: authedQuery.input(idInput).mutation(async ({ ctx, input }) => {
    await requireSession(input.id, ctx.user.id);
    await removeSession(input.id, ctx.user.id);
    return { success: true };
  }),
});
