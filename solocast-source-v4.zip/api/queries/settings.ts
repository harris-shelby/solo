import { eq } from "drizzle-orm";
import { settings, type InsertSettings, type Settings } from "@db/schema";
import { getDb } from "./connection";

export function findSettingsByUser(userId: number) {
  return getDb().query.settings.findFirst({
    where: eq(settings.userId, userId),
  });
}

/** 读取当前用户设置；不存在则按默认值创建 */
export async function getOrCreateSettings(userId: number): Promise<Settings> {
  const existing = await findSettingsByUser(userId);
  if (existing) return existing;
  await getDb().insert(settings).values({ userId });
  const created = await findSettingsByUser(userId);
  if (!created) throw new Error("创建设置失败");
  return created;
}

export async function updateSettings(
  userId: number,
  data: Partial<InsertSettings>,
) {
  await getDb().update(settings).set(data).where(eq(settings.userId, userId));
  return findSettingsByUser(userId);
}
