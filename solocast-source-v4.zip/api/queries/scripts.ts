import { and, count, desc, eq } from "drizzle-orm";
import { scripts, type InsertScript } from "@db/schema";
import { getDb } from "./connection";

export function findScriptsByUser(userId: number, productId?: number) {
  const where = productId
    ? and(eq(scripts.userId, userId), eq(scripts.productId, productId))
    : eq(scripts.userId, userId);
  return getDb()
    .select()
    .from(scripts)
    .where(where)
    .orderBy(desc(scripts.createdAt));
}

export function findScriptById(id: number, userId: number) {
  return getDb().query.scripts.findFirst({
    where: and(eq(scripts.id, id), eq(scripts.userId, userId)),
  });
}

export async function countScriptsByProduct(productId: number, userId: number) {
  const [row] = await getDb()
    .select({ value: count() })
    .from(scripts)
    .where(and(eq(scripts.productId, productId), eq(scripts.userId, userId)));
  return row?.value ?? 0;
}

export async function createScript(data: InsertScript) {
  const [{ id }] = await getDb().insert(scripts).values(data).$returningId();
  return getDb().query.scripts.findFirst({ where: eq(scripts.id, id) });
}

export async function updateScript(
  id: number,
  userId: number,
  data: Partial<InsertScript>,
) {
  await getDb()
    .update(scripts)
    .set(data)
    .where(and(eq(scripts.id, id), eq(scripts.userId, userId)));
  return findScriptById(id, userId);
}

export async function removeScript(id: number, userId: number) {
  await getDb()
    .delete(scripts)
    .where(and(eq(scripts.id, id), eq(scripts.userId, userId)));
}
