import { and, desc, eq } from "drizzle-orm";
import { liveSessions, type InsertLiveSession } from "@db/schema";
import { getDb } from "./connection";

export function findSessionsByUser(userId: number) {
  return getDb()
    .select()
    .from(liveSessions)
    .where(eq(liveSessions.userId, userId))
    .orderBy(desc(liveSessions.createdAt));
}

export function findSessionById(id: number, userId: number) {
  return getDb().query.liveSessions.findFirst({
    where: and(eq(liveSessions.id, id), eq(liveSessions.userId, userId)),
  });
}

export function findLiveSessionByUser(userId: number) {
  return getDb().query.liveSessions.findFirst({
    where: and(
      eq(liveSessions.userId, userId),
      eq(liveSessions.status, "live"),
    ),
  });
}

export async function createSession(data: InsertLiveSession) {
  const [{ id }] = await getDb()
    .insert(liveSessions)
    .values(data)
    .$returningId();
  return getDb().query.liveSessions.findFirst({
    where: eq(liveSessions.id, id),
  });
}

export async function updateSession(
  id: number,
  userId: number,
  data: Partial<InsertLiveSession>,
) {
  await getDb()
    .update(liveSessions)
    .set(data)
    .where(and(eq(liveSessions.id, id), eq(liveSessions.userId, userId)));
  return findSessionById(id, userId);
}

export async function removeSession(id: number, userId: number) {
  await getDb()
    .delete(liveSessions)
    .where(and(eq(liveSessions.id, id), eq(liveSessions.userId, userId)));
}
