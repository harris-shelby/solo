import { and, desc, eq } from "drizzle-orm";
import { products, type InsertProduct } from "@db/schema";
import { getDb } from "./connection";

export function findProductsByUser(userId: number) {
  return getDb()
    .select()
    .from(products)
    .where(eq(products.userId, userId))
    .orderBy(desc(products.createdAt));
}

export function findProductById(id: number, userId: number) {
  return getDb().query.products.findFirst({
    where: and(eq(products.id, id), eq(products.userId, userId)),
  });
}

export async function createProduct(data: InsertProduct) {
  const [{ id }] = await getDb().insert(products).values(data).$returningId();
  return getDb().query.products.findFirst({ where: eq(products.id, id) });
}

export async function updateProduct(
  id: number,
  userId: number,
  data: Partial<InsertProduct>,
) {
  await getDb()
    .update(products)
    .set(data)
    .where(and(eq(products.id, id), eq(products.userId, userId)));
  return findProductById(id, userId);
}

export async function removeProduct(id: number, userId: number) {
  await getDb()
    .delete(products)
    .where(and(eq(products.id, id), eq(products.userId, userId)));
}
