import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router'
import { motion } from 'framer-motion'
import {
  LayoutDashboard,
  Package,
  ScrollText,
  Radio,
  BookOpen,
  Settings,
  ChevronsLeft,
  ChevronsRight,
  Search,
  Bell,
  LogOut,
  Menu,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'
import { LOGIN_PATH } from '@/const'

export const SIDEBAR_WIDTH = 232
export const SIDEBAR_WIDTH_COLLAPSED = 68

/* ---------------- mock：全局直播状态（后续接入真实 API） ---------------- */
const MOCK_LIVE = { isLive: true, startedAtOffsetSec: 5025 } // 01:23:45
const MOCK_TOKEN = { used: 128450, total: 500000 }

const NAV_ITEMS = [
  { to: '/', label: '数据看板', icon: LayoutDashboard },
  { to: '/products', label: '产品管理', icon: Package },
  { to: '/scripts', label: '话术工作台', icon: ScrollText },
  { to: '/live', label: '直播控制台', icon: Radio, liveDot: true },
  { to: '/tutorial', label: '搭建教程', icon: BookOpen },
  { to: '/settings', label: '设置中心', icon: Settings },
]

const PAGE_TITLES: Record<string, { title: string; crumb: string }> = {
  '/': { title: '数据看板', crumb: 'SoloCast / 数据看板' },
  '/products': { title: '产品管理', crumb: 'SoloCast / 产品管理' },
  '/scripts': { title: '话术工作台', crumb: 'SoloCast / 话术工作台' },
  '/live': { title: '直播控制台', crumb: 'SoloCast / 直播控制台' },
  '/settings': { title: '设置中心', crumb: 'SoloCast / 设置中心' },
}

function formatElapsed(totalSec: number) {
  const h = Math.floor(totalSec / 3600)
  const m = Math.floor((totalSec % 3600) / 60)
  const s = totalSec % 60
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${pad(h)}:${pad(m)}:${pad(s)}`
}

/** 顶栏直播计时：每秒自增（mock） */
function useLiveTimer() {
  const [sec, setSec] = useState(MOCK_LIVE.startedAtOffsetSec)
  useEffect(() => {
    if (!MOCK_LIVE.isLive) return
    const id = setInterval(() => setSec((v) => v + 1), 1000)
    return () => clearInterval(id)
  }, [])
  return formatElapsed(sec)
}

function SidebarMiniTokenMeter() {
  const pct = Math.round((MOCK_TOKEN.used / MOCK_TOKEN.total) * 100)
  return (
    <div className="px-1">
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-[rgba(30,36,48,0.12)]">
        <div
          className="h-full rounded-full"
          style={{
            width: `${pct}%`,
            background: 'var(--accent-gradient)',
          }}
        />
      </div>
      <p className="mt-1.5 font-mono text-[11px] text-fg-tertiary">{pct}% tokens</p>
    </div>
  )
}

function Sidebar({
  collapsed,
  onToggleCollapse,
}: {
  collapsed: boolean
  onToggleCollapse: () => void
}) {
  const width = collapsed ? SIDEBAR_WIDTH_COLLAPSED : SIDEBAR_WIDTH
  return (
    <aside
      className="fixed inset-y-0 left-0 z-40 hidden flex-col border-r border-line bg-ink-elevated transition-[width] duration-250 lg:flex"
      style={{ width }}
    >
      {/* Logo 区（高 60px，与顶栏对齐） */}
      <Link
        to="/"
        className="flex h-[60px] shrink-0 items-center gap-3 border-b border-line px-4"
      >
        <img src="/logo.svg" alt="SoloCast" className="h-8 w-8 shrink-0" />
        {!collapsed && (
          <span className="min-w-0 leading-tight">
            <span className="block truncate text-[15px] font-bold text-fg">SoloCast</span>
            <span className="block truncate text-[11px] text-fg-tertiary">
              一人公司 AI 直播中控台
            </span>
          </span>
        )}
      </Link>

      {/* 导航项 */}
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            title={collapsed ? item.label : undefined}
            className={({ isActive }) =>
              cn(
                'relative flex h-11 items-center gap-3 rounded-[10px] px-3 text-sm transition-colors duration-150',
                isActive
                  ? 'bg-brand-soft text-brand-hover'
                  : 'text-fg-secondary hover:bg-ink-hover hover:text-fg',
              )
            }
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <motion.span
                    layoutId="nav-indicator"
                    className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-full bg-brand"
                    transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                  />
                )}
                <span className="relative shrink-0">
                  <item.icon className="h-5 w-5" />
                  {item.liveDot && MOCK_LIVE.isLive && (
                    <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-live animate-live-breathe" />
                  )}
                </span>
                {!collapsed && <span className="truncate">{item.label}</span>}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* 底部：Token 迷你条 + 折叠按钮 */}
      <div className="space-y-3 border-t border-line p-3">
        {!collapsed && <SidebarMiniTokenMeter />}
        <button
          type="button"
          onClick={onToggleCollapse}
          className="flex h-9 w-full items-center justify-center rounded-[10px] text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg"
          aria-label={collapsed ? '展开侧边栏' : '折叠侧边栏'}
        >
          {collapsed ? (
            <ChevronsRight className="h-4 w-4" />
          ) : (
            <ChevronsLeft className="h-4 w-4" />
          )}
        </button>
      </div>
    </aside>
  )
}

/** 顶栏账号区：由 useAuth() 驱动（AUTH-SLOT 已接线） */
function AccountSlot() {
  const { user, isAuthenticated, isLoading, logout } = useAuth()

  if (isLoading) {
    // 中性占位，避免登录态闪烁
    return (
      <div className="flex items-center gap-2.5" aria-hidden>
        <div className="h-8 w-8 animate-pulse rounded-full bg-ink-hover" />
        <div className="h-3.5 w-12 animate-pulse rounded bg-ink-hover" />
      </div>
    )
  }

  if (!isAuthenticated || !user) {
    return (
      <Link
        to={LOGIN_PATH}
        className="text-[13px] font-medium text-fg-secondary transition-colors hover:text-brand-hover"
      >
        登录
      </Link>
    )
  }

  return (
    <div className="flex items-center gap-2.5">
      <img
        src={user.avatar ?? '/avatar-host.webp'}
        alt={user.name ?? '账号头像'}
        className="h-8 w-8 rounded-full border border-line-strong object-cover"
      />
      <span className="hidden max-w-[120px] truncate text-[13px] font-medium text-fg sm:block">
        {user.name ?? '用户'}
      </span>
      <button
        type="button"
        onClick={() => logout()}
        className="flex items-center gap-1 text-[13px] font-medium text-fg-secondary transition-colors hover:text-brand-hover"
        aria-label="退出登录"
      >
        <LogOut className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">退出</span>
      </button>
    </div>
  )
}

/** 移动端抽屉导航（<lg 显示，汉堡按钮触发） */
function MobileNav({ open, onClose }: { open: boolean; onClose: () => void }) {
  const location = useLocation()
  // 路由变化后自动收起抽屉
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { onClose() }, [location.pathname])

  if (!open) return null
  return (
    <div className="fixed inset-0 z-[60] lg:hidden">
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"
        onClick={onClose}
        aria-hidden
      />
      <aside className="absolute inset-y-0 left-0 flex w-[260px] flex-col border-r border-line bg-ink-elevated shadow-overlay">
        <div className="flex h-[60px] shrink-0 items-center justify-between border-b border-line px-4">
          <Link to="/" className="flex items-center gap-3" onClick={onClose}>
            <img src="/logo.svg" alt="SoloCast" className="h-8 w-8 shrink-0" />
            <span className="text-[15px] font-bold text-fg">SoloCast</span>
          </Link>
          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-[10px] text-fg-secondary hover:bg-ink-hover hover:text-fg"
            aria-label="关闭菜单"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                cn(
                  'relative flex h-11 items-center gap-3 rounded-[10px] px-3 text-sm transition-colors duration-150',
                  isActive
                    ? 'bg-brand-soft text-brand-hover'
                    : 'text-fg-secondary hover:bg-ink-hover hover:text-fg',
                )
              }
            >
              <span className="relative shrink-0">
                <item.icon className="h-5 w-5" />
                {item.liveDot && MOCK_LIVE.isLive && (
                  <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-live animate-live-breathe" />
                )}
              </span>
              <span className="truncate">{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-line p-3">
          <SidebarMiniTokenMeter />
        </div>
      </aside>
    </div>
  )
}

function Topbar({
  sidebarWidth,
  onMenuClick,
}: {
  sidebarWidth: number
  onMenuClick: () => void
}) {
  const location = useLocation()
  const page = PAGE_TITLES[location.pathname] ?? { title: 'SoloCast', crumb: 'SoloCast' }
  const elapsed = useLiveTimer()

  return (
    <header
      className="sticky top-0 z-50 ml-0 flex h-[60px] items-center justify-between gap-3 border-b border-line px-4 backdrop-blur-[12px] transition-[margin] duration-250 sm:px-6 lg:ml-[var(--sbw)]"
      style={{ background: 'rgba(16,21,30,0.8)', ['--sbw' as string]: `${sidebarWidth}px` }}
    >
      {/* 左：汉堡（移动端）+ 页面标题 + 面包屑 */}
      <div className="flex min-w-0 items-center gap-2">
        <button
          type="button"
          onClick={onMenuClick}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg lg:hidden"
          aria-label="打开菜单"
        >
          <Menu className="h-5 w-5" />
        </button>
        <div className="min-w-0">
          <h1 className="truncate text-lg font-bold leading-6 text-fg sm:text-xl">{page.title}</h1>
          <p className="hidden truncate text-xs text-fg-tertiary sm:block">{page.crumb}</p>
        </div>
      </div>

      {/* 右：搜索 / 直播状态 / 通知 / 账号 */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          className="hidden h-[38px] w-[220px] items-center gap-2 rounded-[10px] border border-line bg-ink-input px-3 text-[13px] text-fg-tertiary transition-all duration-200 hover:border-line-strong focus:w-[320px] focus:border-brand md:flex"
        >
          <Search className="h-4 w-4 shrink-0" />
          <span className="flex-1 text-left">搜索产品 / 话术 / 任务</span>
          <kbd className="rounded border border-line px-1 font-mono text-[10px]">⌘K</kbd>
        </button>

        <Link
          to="/live"
          className={cn(
            'flex h-[30px] items-center gap-2 rounded-full px-3 text-xs font-medium transition-colors',
            MOCK_LIVE.isLive
              ? 'bg-[rgba(255,77,109,0.12)] text-live'
              : 'bg-[rgba(30,36,48,0.10)] text-fg-secondary',
          )}
        >
          <span
            className={cn(
              'h-1.5 w-1.5 rounded-full',
              MOCK_LIVE.isLive ? 'bg-live animate-live-breathe' : 'bg-fg-tertiary',
            )}
          />
          {MOCK_LIVE.isLive ? (
            <>
              直播中<span className="hidden sm:inline"> · <span className="font-mono">{elapsed}</span></span>
            </>
          ) : (
            '空闲'
          )}
        </Link>

        <button
          type="button"
          className="relative flex h-9 w-9 items-center justify-center rounded-[10px] text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
          aria-label="通知"
        >
          <Bell className="h-[18px] w-[18px]" />
          <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-live" />
        </button>

        <div className="flex items-center gap-2.5 border-l border-line pl-3">
          {/* AUTH-SLOT: rewired to useAuth() in Phase 5 */}
          <AccountSlot />
        </div>
      </div>
    </header>
  )
}

/**
 * Navbar = Sidebar（固定左侧，≥lg 显示）+ Topbar（sticky 顶栏）+ 移动端抽屉导航。
 * 折叠状态由 Layout 持有并下发，保证内容区偏移一致。
 */
export default function Navbar({
  collapsed,
  onToggleCollapse,
}: {
  collapsed: boolean
  onToggleCollapse: () => void
}) {
  const sidebarWidth = collapsed ? SIDEBAR_WIDTH_COLLAPSED : SIDEBAR_WIDTH
  const [mobileOpen, setMobileOpen] = useState(false)
  return (
    <>
      <Sidebar collapsed={collapsed} onToggleCollapse={onToggleCollapse} />
      <Topbar sidebarWidth={sidebarWidth} onMenuClick={() => setMobileOpen(true)} />
      <MobileNav open={mobileOpen} onClose={() => setMobileOpen(false)} />
    </>
  )
}
