import { useEffect, useMemo, useState } from 'react'
import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { useNavigate, useSearchParams } from 'react-router'
import { AnimatePresence, motion } from 'framer-motion'
import type { Variants } from 'framer-motion'
import {
  Check,
  ImagePlus,
  LayoutGrid,
  List,
  Loader2,
  Package,
  PackagePlus,
  Pencil,
  ScrollText,
  Search,
  Sparkles,
  Trash2,
  TriangleAlert,
  Upload,
  Wand2,
  X,
} from 'lucide-react'
import { useDropzone } from 'react-dropzone'
import { toast } from 'sonner'
import type { inferRouterOutputs } from '@trpc/server'
import { trpc } from '@/providers/trpc'
import { cn } from '@/lib/utils'
import { Toaster } from '@/components/ui/sonner'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import type { AppRouter } from '../../api/router'

type RouterOutputs = inferRouterOutputs<AppRouter>
type Product = RouterOutputs['products']['list'][number]
type Script = RouterOutputs['scripts']['list'][number]

/* ---------------- 常量 ---------------- */

const DEMO_IMAGES = [
  '/product-demo-1.webp',
  '/product-demo-2.webp',
  '/product-demo-3.webp',
  '/product-demo-4.webp',
]

const STATUS_META: Record<string, { label: string; className: string }> = {
  active: {
    label: '已上架',
    className: 'bg-[rgba(52,211,153,0.12)] text-ok',
  },
  draft: {
    label: '草稿',
    className: 'bg-[rgba(30,36,48,0.10)] text-fg-secondary',
  },
}

type StatusFilter = 'all' | 'active' | 'draft'
type SortKey = 'created' | 'updated' | 'priceDesc' | 'priceAsc'
type ViewMode = 'grid' | 'table'

/* ---------------- 小组件 ---------------- */

type MotionButtonProps = Omit<
  ButtonHTMLAttributes<HTMLButtonElement>,
  'onDrag' | 'onDragStart' | 'onDragEnd' | 'onAnimationStart'
>

function StatusPill({ status }: { status: string }) {
  const meta = STATUS_META[status] ?? STATUS_META.draft
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-[6px] px-2 py-0.5 text-xs font-medium',
        meta.className,
      )}
    >
      {meta.label}
    </span>
  )
}

function PrimaryButton({
  children,
  className,
  ...props
}: MotionButtonProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      className={cn(
        'inline-flex h-[38px] items-center gap-2 rounded-[10px] px-[18px] text-sm font-medium text-white transition-shadow hover:shadow-glow-accent',
        className,
      )}
      style={{ background: 'var(--accent-gradient)' }}
      {...props}
    >
      {children}
    </motion.button>
  )
}

function SecondaryButton({
  children,
  className,
  ...props
}: MotionButtonProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      className={cn(
        'inline-flex h-[38px] items-center gap-2 rounded-[10px] border border-line-strong bg-ink-hover px-4 text-sm font-medium text-fg transition-colors hover:border-fg-tertiary/40',
        className,
      )}
      {...props}
    >
      {children}
    </motion.button>
  )
}

function GhostIconButton({
  children,
  className,
  ...props
}: MotionButtonProps) {
  return (
    <button
      type="button"
      className={cn(
        'flex h-8 w-8 items-center justify-center rounded-[10px] text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg',
        className,
      )}
      {...props}
    >
      {children}
    </button>
  )
}

/* ---------------- 工具函数 ---------------- */

function splitPoints(text: string | null): string[] {
  if (!text) return []
  return text
    .split(/[,，、\n]+/)
    .map((s) => s.trim())
    .filter(Boolean)
}

function formatPrice(price: string | null): string {
  const n = price === null ? NaN : Number(price)
  if (Number.isNaN(n)) return '—'
  return `¥ ${n.toFixed(2)}`
}

function formatTime(d: Date | string): string {
  const date = typeof d === 'string' ? new Date(d) : d
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`
}

/* ======================================================================
 * 新增 / 编辑产品抽屉
 * ==================================================================== */

function Field({
  label,
  required,
  hint,
  extra,
  children,
}: {
  label: string
  required?: boolean
  hint?: string
  extra?: ReactNode
  children: ReactNode
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <label className="text-[13px] font-medium text-fg">
          {label}
          {required && <span className="ml-0.5 text-live">*</span>}
        </label>
        {extra}
      </div>
      {children}
      {hint && <p className="mt-1.5 text-xs text-fg-tertiary">{hint}</p>}
    </div>
  )
}

const inputCls =
  'h-[38px] w-full rounded-[10px] border border-line bg-ink-input px-3 text-sm text-fg placeholder:text-fg-tertiary outline-none transition-all focus:border-brand focus:shadow-[0_0_0_3px_rgba(108,92,231,0.15)]'

function ProductDrawer({
  product,
  onClose,
}: {
  product: Product | null
  onClose: () => void
}) {
  const utils = trpc.useUtils()
  const navigate = useNavigate()

  const [name, setName] = useState(product?.name ?? '')
  const [description, setDescription] = useState(product?.description ?? '')
  const [points, setPoints] = useState<string[]>(splitPoints(product?.sellingPoints ?? null))
  const [pointInput, setPointInput] = useState('')
  const [price, setPrice] = useState(product?.price ?? '')
  const [imageUrl, setImageUrl] = useState(product?.imageUrl ?? '')
  const [isActive, setIsActive] = useState(product?.status === 'active')
  const [dragActive, setDragActive] = useState(false)
  const [savedOk, setSavedOk] = useState(false)

  const invalidate = async () => {
    await utils.products.list.invalidate()
  }

  const createMutation = trpc.products.create.useMutation({
    onSuccess: () => {
      invalidate()
      setSavedOk(true)
      toast.success('产品已保存，去生成话术吧 →', {
        action: { label: '去生成', onClick: () => navigate('/scripts') },
      })
      setTimeout(onClose, 450)
    },
    onError: (e) => toast.error(e.message),
  })
  const updateMutation = trpc.products.update.useMutation({
    onSuccess: () => {
      invalidate()
      setSavedOk(true)
      toast.success('产品已保存，去生成话术吧 →', {
        action: { label: '去生成', onClick: () => navigate('/scripts') },
      })
      setTimeout(onClose, 450)
    },
    onError: (e) => toast.error(e.message),
  })
  const saving = createMutation.isPending || updateMutation.isPending

  const { getRootProps, getInputProps, open } = useDropzone({
    accept: { 'image/png': ['.png'], 'image/jpeg': ['.jpg', '.jpeg'], 'image/webp': ['.webp'] },
    maxSize: 5 * 1024 * 1024,
    multiple: false,
    noClick: Boolean(imageUrl),
    onDragEnter: () => setDragActive(true),
    onDragLeave: () => setDragActive(false),
    onDrop: (accepted, rejected) => {
      setDragActive(false)
      if (rejected.length > 0) {
        toast.error('图片格式或大小不符合要求（PNG/JPG ≤ 5MB）')
        return
      }
      const file = accepted[0]
      if (!file) return
      const reader = new FileReader()
      reader.onload = () => {
        const dataUrl = String(reader.result ?? '')
        setImageUrl(dataUrl)
        if (dataUrl.length > 480) {
          toast.warning('演示环境图片地址长度受限，大图可能被服务器拒绝，建议使用预设演示图')
        }
      }
      reader.readAsDataURL(file)
    },
  })

  const addPoint = () => {
    const v = pointInput.trim()
    if (!v) return
    if (points.length >= 6) {
      toast.warning('最多 6 个卖点')
      return
    }
    if (!points.includes(v)) setPoints([...points, v])
    setPointInput('')
  }

  const canSave = name.trim().length > 0 && description.trim().length > 0 && !saving

  const handleSave = () => {
    const payload = {
      name: name.trim(),
      description: description.trim(),
      sellingPoints: points.join('、'),
      price: price.trim() === '' ? undefined : Number(price),
      imageUrl: imageUrl || undefined,
      status: (isActive ? 'active' : 'draft') as 'active' | 'draft',
    }
    if (payload.price !== undefined && (Number.isNaN(payload.price) || payload.price < 0)) {
      toast.error('售价必须是非负数字')
      return
    }
    if (product) {
      updateMutation.mutate({ id: product.id, data: payload })
    } else {
      createMutation.mutate(payload)
    }
  }

  const fieldStagger: Variants = {
    hidden: {},
    show: { transition: { staggerChildren: 0.05 } },
  }
  const fieldItem: Variants = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0, transition: { duration: 0.3, ease: [0.16, 1, 0.3, 1] } },
  }

  return (
    <>
      {/* 遮罩 */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="fixed inset-0 z-[60] bg-[rgba(30,36,48,0.45)] backdrop-blur-[4px]"
        onClick={onClose}
      />
      {/* 抽屉 */}
      <motion.aside
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="fixed inset-y-0 right-0 z-[61] flex w-full max-w-[560px] flex-col border-l border-line bg-ink-elevated overlay-shadow"
      >
        {/* 标题栏 */}
        <div className="flex items-start justify-between border-b border-line px-6 py-5">
          <div>
            <h3 className="text-[15px] font-semibold leading-6 text-fg">
              {product ? '编辑产品' : '新增产品'}
            </h3>
            <p className="mt-0.5 text-[13px] text-fg-tertiary">
              上传图片和介绍，剩下的交给 Kimi
            </p>
          </div>
          <GhostIconButton onClick={onClose} aria-label="关闭">
            <X className="h-4 w-4" />
          </GhostIconButton>
        </div>

        {/* 表单 */}
        <motion.div
          variants={fieldStagger}
          initial="hidden"
          animate="show"
          className="flex-1 space-y-5 overflow-y-auto px-6 py-5"
        >
          {/* 产品图片 */}
          <motion.div variants={fieldItem}>
            <Field label="产品图片">
              <input {...getInputProps()} />
              {imageUrl ? (
                <div className="relative h-[200px] overflow-hidden rounded-[14px] border border-line bg-ink-input">
                  <img src={imageUrl} alt="产品图" className="h-full w-full object-cover" />
                  <div className="absolute right-2.5 top-2.5 flex gap-2">
                    <button
                      type="button"
                      onClick={open}
                      className="flex h-7 items-center rounded-full bg-[rgba(10,13,19,0.75)] px-3 text-xs font-medium text-fg backdrop-blur transition-colors hover:bg-[rgba(10,13,19,0.9)]"
                    >
                      更换
                    </button>
                    <button
                      type="button"
                      onClick={() => setImageUrl('')}
                      className="flex h-7 items-center rounded-full bg-[rgba(10,13,19,0.75)] px-3 text-xs font-medium text-bad backdrop-blur transition-colors hover:bg-[rgba(10,13,19,0.9)]"
                    >
                      删除
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  {...getRootProps({
                    className: cn(
                      'flex h-[200px] cursor-copy flex-col items-center justify-center gap-2 rounded-[14px] border border-dashed transition-colors',
                      dragActive
                        ? 'border-brand bg-brand-soft'
                        : 'border-line-strong bg-ink-input hover:border-brand/60',
                    ),
                  })}
                >
                  <ImagePlus className="h-10 w-10 text-fg-tertiary" />
                  <p className="text-[13px] text-fg-secondary">
                    {dragActive ? '松开上传' : '点击或拖拽上传 · PNG/JPG ≤ 5MB'}
                  </p>
                </div>
              )}
              {/* 预设演示图 */}
              <div className="mt-2.5 flex items-center gap-2">
                <span className="text-xs text-fg-tertiary">预设演示图</span>
                {DEMO_IMAGES.map((src) => (
                  <button
                    key={src}
                    type="button"
                    onClick={() => setImageUrl(src)}
                    className={cn(
                      'h-12 w-12 overflow-hidden rounded-[8px] border-2 transition-all',
                      imageUrl === src
                        ? 'border-brand'
                        : 'border-transparent opacity-70 hover:opacity-100',
                    )}
                  >
                    <img src={src} alt="预设产品图" className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            </Field>
          </motion.div>

          {/* 产品名称 */}
          <motion.div variants={fieldItem}>
            <Field
              label="产品名称"
              required
              extra={<span className="font-mono text-xs text-fg-tertiary">{name.length}/30</span>}
            >
              <input
                value={name}
                maxLength={30}
                onChange={(e) => setName(e.target.value)}
                placeholder="例：静噪 Pro 真无线蓝牙耳机"
                className={inputCls}
              />
            </Field>
          </motion.div>

          {/* 产品介绍 */}
          <motion.div variants={fieldItem}>
            <Field
              label="产品介绍"
              required
              extra={
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (!name.trim()) {
                        toast.warning('请先填写产品名称，再到话术工作台生成')
                        return
                      }
                      toast.info('请先在话术工作台生成', {
                        description: 'Kimi 会在话术工作台基于产品信息生成完整话术',
                        action: { label: '去工作台', onClick: () => navigate(`/scripts?product=${product?.id ?? ''}`) },
                      })
                    }}
                    className="flex items-center gap-1 text-xs font-medium text-brand-hover transition-colors hover:text-brand"
                  >
                    <Wand2 className="h-3.5 w-3.5" />
                    AI 补全
                  </button>
                </div>
              }
            >
              <div className="relative">
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={6}
                  placeholder="材质、功能、适用人群、使用场景…写得越详细，Kimi 话术越生动"
                  className="w-full resize-none rounded-[10px] border border-line bg-ink-input px-3 py-2.5 text-sm leading-[22px] text-fg placeholder:text-fg-tertiary outline-none transition-all focus:border-brand focus:shadow-[0_0_0_3px_rgba(108,92,231,0.15)]"
                />
                <span className="pointer-events-none absolute bottom-2 right-3 font-mono text-xs text-fg-tertiary">
                  {description.length}
                </span>
              </div>
            </Field>
          </motion.div>

          {/* 核心卖点 */}
          <motion.div variants={fieldItem}>
            <Field label="核心卖点" hint="回车生成标签，最多 6 个">
              <div className="flex min-h-[38px] flex-wrap items-center gap-1.5 rounded-[10px] border border-line bg-ink-input px-2 py-1.5 transition-all focus-within:border-brand focus-within:shadow-[0_0_0_3px_rgba(108,92,231,0.15)]">
                <AnimatePresence>
                  {points.map((p) => (
                    <motion.span
                      key={p}
                      initial={{ scale: 0.6, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.6, opacity: 0 }}
                      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                      className="flex items-center gap-1 rounded-[6px] bg-brand-soft px-2 py-0.5 text-xs text-brand-hover"
                    >
                      {p}
                      <button
                        type="button"
                        onClick={() => setPoints(points.filter((x) => x !== p))}
                        className="text-brand-hover/70 transition-colors hover:text-brand-hover"
                        aria-label={`删除卖点 ${p}`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </motion.span>
                  ))}
                </AnimatePresence>
                <input
                  value={pointInput}
                  onChange={(e) => setPointInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault()
                      addPoint()
                    }
                  }}
                  onBlur={addPoint}
                  placeholder={points.length === 0 ? '例：主动降噪' : ''}
                  className="h-6 min-w-[90px] flex-1 bg-transparent text-sm text-fg placeholder:text-fg-tertiary outline-none"
                />
              </div>
            </Field>
          </motion.div>

          {/* 售价 */}
          <motion.div variants={fieldItem}>
            <Field label="售价 ¥">
              <input
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                type="number"
                min={0}
                step="0.01"
                placeholder="199.00"
                className={cn(inputCls, 'font-display')}
              />
            </Field>
          </motion.div>

          {/* 状态 */}
          <motion.div variants={fieldItem}>
            <div className="flex items-center justify-between rounded-[10px] border border-line bg-ink-input px-3 py-2.5">
              <div>
                <p className="text-sm font-medium text-fg">上架销售</p>
                <p className="text-xs text-fg-tertiary">上架后可在话术工作台选择该产品</p>
              </div>
              <Switch checked={isActive} onCheckedChange={setIsActive} />
            </div>
          </motion.div>
        </motion.div>

        {/* 底部操作栏 */}
        <div className="flex items-center justify-end gap-3 border-t border-line px-6 py-4">
          <button
            type="button"
            onClick={onClose}
            className="h-[38px] rounded-[10px] px-4 text-sm font-medium text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
          >
            取消
          </button>
          <PrimaryButton
            onClick={handleSave}
            disabled={!canSave}
            className={cn(!canSave && 'cursor-not-allowed opacity-50')}
          >
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : savedOk ? (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 260, damping: 24 }}
              >
                <Check className="h-4 w-4" />
              </motion.span>
            ) : null}
            保存产品
          </PrimaryButton>
        </div>
      </motion.aside>
    </>
  )
}

/* ======================================================================
 * 删除确认 Modal
 * ==================================================================== */

function DeleteModal({
  product,
  scriptCount,
  deleting,
  onCancel,
  onConfirm,
}: {
  product: Product
  scriptCount: number
  deleting: boolean
  onCancel: () => void
  onConfirm: () => void
}) {
  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="fixed inset-0 z-[70] bg-[rgba(30,36,48,0.45)] backdrop-blur-[4px]"
        onClick={onCancel}
      />
      <motion.div
        initial={{ scale: 0.96, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.96, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 260, damping: 24 }}
        className="fixed left-1/2 top-1/2 z-[71] w-[min(440px,calc(100vw-32px))] -translate-x-1/2 -translate-y-1/2 rounded-[20px] border border-line bg-ink-elevated p-6 overlay-shadow"
      >
        <TriangleAlert className="h-10 w-10 text-bad" />
        <h3 className="mt-4 text-[15px] font-semibold leading-6 text-fg">删除产品？</h3>
        <p className="mt-2 text-sm leading-[22px] text-fg-secondary">
          《{product.name}》
          {scriptCount > 0
            ? `及其关联的 ${scriptCount} 篇话术将被一并删除，此操作不可恢复。`
            : '将被删除，此操作不可恢复。'}
        </p>
        <div className="mt-6 flex justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="h-[38px] rounded-[10px] px-4 text-sm font-medium text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
          >
            取消
          </button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={onConfirm}
            disabled={deleting}
            className="flex h-[38px] items-center gap-2 rounded-[10px] bg-bad px-4 text-sm font-medium text-white transition-opacity disabled:opacity-60"
          >
            {deleting && <Loader2 className="h-4 w-4 animate-spin" />}
            确认删除
          </motion.button>
        </div>
      </motion.div>
    </>
  )
}

/* ======================================================================
 * 空状态
 * ==================================================================== */

function EmptyState({
  filtered,
  onClearFilter,
  onCreate,
}: {
  filtered: boolean
  onClearFilter: () => void
  onCreate: () => void
}) {
  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="flex flex-col items-center py-20"
    >
      <motion.img
        src="/empty-products.webp"
        alt="空货架"
        className="h-40 w-auto"
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
      />
      <h2 className="mt-6 text-[17px] font-semibold leading-[26px] text-fg">
        {filtered ? '没有匹配的产品' : '货架还是空的'}
      </h2>
      <p className="mt-1.5 text-[13px] text-fg-tertiary">
        {filtered ? '换个关键词或清除筛选条件试试' : '上传第一张产品图，Kimi 就能帮你开口卖货'}
      </p>
      {filtered ? (
        <button
          type="button"
          onClick={onClearFilter}
          className="mt-5 h-[38px] rounded-[10px] px-4 text-sm font-medium text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
        >
          清除筛选
        </button>
      ) : (
        <PrimaryButton onClick={onCreate} className="mt-5">
          <PackagePlus className="h-4 w-4" />
          新增产品
        </PrimaryButton>
      )}
    </motion.div>
  )
}

/* ======================================================================
 * 主页面
 * ==================================================================== */

const gridContainer: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06 } },
}
const gridItem: Variants = {
  hidden: { opacity: 0, y: 24, scale: 0.98 },
  show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] } },
  exit: { scale: 0.9, opacity: 0, transition: { duration: 0.25 } },
}

export default function Products() {
  const navigate = useNavigate()
  const [searchParams, setSearchParams] = useSearchParams()

  const productsQuery = trpc.products.list.useQuery()
  const scriptsQuery = trpc.scripts.list.useQuery(undefined)
  const utils = trpc.useUtils()

  /* ---- 本地状态 ---- */
  const [searchInput, setSearchInput] = useState('')
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [sortKey, setSortKey] = useState<SortKey>('created')
  const [view, setView] = useState<ViewMode>('grid')
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)
  const [deleting, setDeleting] = useState<Product | null>(null)

  /* 搜索防抖 300ms */
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim()), 300)
    return () => clearTimeout(t)
  }, [searchInput])

  /* URL ?new=1 自动打开新建抽屉 */
  useEffect(() => {
    if (searchParams.get('new') === '1') {
      setEditing(null)
      setDrawerOpen(true)
      searchParams.delete('new')
      setSearchParams(searchParams, { replace: true })
    }
  }, [searchParams, setSearchParams])

  /* ---- 数据加工 ---- */
  const products = useMemo(() => productsQuery.data ?? [], [productsQuery.data])
  const scripts = useMemo<Script[]>(() => scriptsQuery.data ?? [], [scriptsQuery.data])

  const scriptCountByProduct = useMemo(() => {
    const map = new Map<number, { total: number; active: number }>()
    for (const s of scripts) {
      const cur = map.get(s.productId) ?? { total: 0, active: 0 }
      cur.total += 1
      if (s.status === 'active') cur.active += 1
      map.set(s.productId, cur)
    }
    return map
  }, [scripts])

  const counts = useMemo(
    () => ({
      all: products.length,
      active: products.filter((p) => p.status === 'active').length,
      draft: products.filter((p) => p.status !== 'active').length,
      withScripts: new Set(scripts.map((s) => s.productId)).size,
    }),
    [products, scripts],
  )

  const filtered = useMemo(() => {
    let list = products
    if (statusFilter !== 'all') {
      list = list.filter((p) => (statusFilter === 'active' ? p.status === 'active' : p.status !== 'active'))
    }
    if (search) {
      const q = search.toLowerCase()
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          (p.sellingPoints ?? '').toLowerCase().includes(q) ||
          (p.description ?? '').toLowerCase().includes(q),
      )
    }
    const sorted = [...list]
    const priceOf = (p: Product) => (p.price === null ? -1 : Number(p.price))
    const timeOf = (d: Date | string) => new Date(d).getTime()
    switch (sortKey) {
      case 'created':
        sorted.sort((a, b) => timeOf(b.createdAt) - timeOf(a.createdAt))
        break
      case 'updated':
        sorted.sort((a, b) => timeOf(b.updatedAt) - timeOf(a.updatedAt))
        break
      case 'priceDesc':
        sorted.sort((a, b) => priceOf(b) - priceOf(a))
        break
      case 'priceAsc':
        sorted.sort((a, b) => priceOf(a) - priceOf(b))
        break
    }
    return sorted
  }, [products, statusFilter, search, sortKey])

  /* ---- 变更 ---- */
  const refresh = () => {
    utils.products.list.invalidate()
    utils.scripts.list.invalidate()
  }

  const removeMutation = trpc.products.remove.useMutation({
    onSuccess: () => {
      toast.success('产品已删除')
      setDeleting(null)
      setSelected(new Set())
      refresh()
    },
    onError: (e) => toast.error(e.message),
  })
  const statusMutation = trpc.products.update.useMutation({
    onError: (e) => toast.error(e.message),
  })

  const toggleSelect = (id: number) => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const batchSetStatus = async (status: 'active' | 'draft') => {
    const ids = [...selected]
    const results = await Promise.allSettled(
      ids.map((id) => statusMutation.mutateAsync({ id, data: { status } })),
    )
    const okCount = results.filter((r) => r.status === 'fulfilled').length
    toast.success(`已${status === 'active' ? '上架' : '下架'} ${okCount} 款产品`)
    setSelected(new Set())
    refresh()
  }

  const batchRemove = async () => {
    const ids = [...selected]
    const results = await Promise.allSettled(ids.map((id) => removeMutation.mutateAsync({ id })))
    const okCount = results.filter((r) => r.status === 'fulfilled').length
    toast.success(`已删除 ${okCount} 款产品`)
    setSelected(new Set())
    refresh()
  }

  const openCreate = () => {
    setEditing(null)
    setDrawerOpen(true)
  }
  const openEdit = (p: Product) => {
    setEditing(p)
    setDrawerOpen(true)
  }

  const isFiltering = search !== '' || statusFilter !== 'all'

  /* ---- 渲染 ---- */
  return (
    <div className="mx-auto max-w-[1560px] p-4 sm:p-6 lg:p-8">
      <Toaster theme="light" position="top-right" />

      {/* 页头 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-wrap items-end justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold leading-8 text-fg">产品管理</h1>
          <p className="mt-1 text-[13px] text-fg-tertiary">
            共 {counts.all} 款产品 · 已上架 {counts.active} · 已生成话术 {counts.withScripts}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          >
            <SecondaryButton
              disabled
              title="即将支持 CSV"
              className="cursor-not-allowed opacity-50"
            >
              <Upload className="h-4 w-4" />
              批量导入
            </SecondaryButton>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.18, ease: [0.16, 1, 0.3, 1] }}
          >
            <PrimaryButton onClick={openCreate}>
              <PackagePlus className="h-4 w-4" />
              新增产品
            </PrimaryButton>
          </motion.div>
        </div>
      </motion.div>

      {/* 工具栏 */}
      <div className="sticky top-[60px] z-30 -mx-2 mt-6 border-b border-line bg-[rgba(10,13,19,0.82)] px-2 py-3 backdrop-blur-[12px]">
        <div className="flex flex-wrap items-center gap-3">
          {/* 搜索 */}
          <div className="relative w-full sm:w-auto">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg-tertiary" />
            <input
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="搜索产品名 / 卖点…"
              className="h-[38px] w-full rounded-[10px] border border-line bg-ink-input pl-9 pr-3 text-sm text-fg placeholder:text-fg-tertiary outline-none transition-all focus:border-brand focus:shadow-[0_0_0_3px_rgba(108,92,231,0.15)] sm:w-[260px]"
            />
          </div>

          {/* 筛选 Chips */}
          <div className="flex items-center gap-2">
            {(
              [
                ['all', '全部', counts.all],
                ['active', '已上架', counts.active],
                ['draft', '草稿', counts.draft],
              ] as [StatusFilter, string, number][]
            ).map(([key, label, n]) => (
              <button
                key={key}
                type="button"
                onClick={() => setStatusFilter(key)}
                className={cn(
                  'flex h-8 items-center gap-1.5 rounded-full border px-3 text-[13px] font-medium transition-colors',
                  statusFilter === key
                    ? 'border-brand bg-brand text-white'
                    : 'border-line-strong text-fg-secondary hover:border-fg-tertiary/50 hover:text-fg',
                )}
              >
                {label}
                <motion.span
                  key={n}
                  initial={{ scale: 1.2 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                  className={cn(
                    'font-mono text-xs',
                    statusFilter === key ? 'text-white/85' : 'text-fg-tertiary',
                  )}
                >
                  {n}
                </motion.span>
              </button>
            ))}
          </div>

          {/* 排序 */}
          <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
            <SelectTrigger className="h-[38px] w-[136px] border-line bg-ink-input text-[13px] text-fg-secondary">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="created">最新创建</SelectItem>
              <SelectItem value="updated">最近更新</SelectItem>
              <SelectItem value="priceDesc">价格从高</SelectItem>
              <SelectItem value="priceAsc">价格从低</SelectItem>
            </SelectContent>
          </Select>

          <div className="ml-auto flex items-center gap-3">
            {/* 批量操作区 */}
            <AnimatePresence>
              {selected.size > 0 && (
                <motion.div
                  initial={{ y: -8, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -8, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center gap-2 rounded-[10px] border border-line bg-ink-card px-3 py-1.5"
                >
                  <span className="text-[13px] text-fg-secondary">
                    已选 <span className="font-mono text-fg">{selected.size}</span> 项
                  </span>
                  <button
                    type="button"
                    onClick={() => batchSetStatus('active')}
                    className="text-[13px] font-medium text-ok transition-opacity hover:opacity-80"
                  >
                    批量上架
                  </button>
                  <button
                    type="button"
                    onClick={() => batchSetStatus('draft')}
                    className="text-[13px] font-medium text-warn transition-opacity hover:opacity-80"
                  >
                    批量下架
                  </button>
                  <button
                    type="button"
                    onClick={batchRemove}
                    className="text-[13px] font-medium text-bad transition-opacity hover:opacity-80"
                  >
                    删除
                  </button>
                  <GhostIconButton onClick={() => setSelected(new Set())} className="h-6 w-6" aria-label="收起批量操作">
                    <X className="h-3.5 w-3.5" />
                  </GhostIconButton>
                </motion.div>
              )}
            </AnimatePresence>

            {/* 视图切换 */}
            <div className="flex rounded-[10px] border border-line bg-ink-input p-1">
              {(
                [
                  ['grid', LayoutGrid, '卡片视图'],
                  ['table', List, '表格视图'],
                ] as [ViewMode, typeof LayoutGrid, string][]
              ).map(([key, Icon, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setView(key)}
                  aria-label={label}
                  className="relative flex h-7 w-9 items-center justify-center rounded-[7px]"
                >
                  {view === key && (
                    <motion.span
                      layoutId="view-toggle"
                      className="absolute inset-0 rounded-[7px] bg-ink-hover"
                      transition={{ duration: 0.25 }}
                    />
                  )}
                  <Icon
                    className={cn(
                      'relative h-4 w-4 transition-colors',
                      view === key ? 'text-fg' : 'text-fg-tertiary',
                    )}
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 内容 */}
      <div className="mt-6">
        {productsQuery.isLoading ? (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3 min-[1440px]:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div
                key={i}
                className="h-[340px] animate-pulse rounded-[14px] border border-line bg-ink-card"
              />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            filtered={isFiltering}
            onClearFilter={() => {
              setSearchInput('')
              setSearch('')
              setStatusFilter('all')
            }}
            onCreate={openCreate}
          />
        ) : view === 'grid' ? (
          /* ---- 卡片网格 ---- */
          <motion.div
            variants={gridContainer}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3 min-[1440px]:grid-cols-4"
          >
            <AnimatePresence mode="popLayout">
              {filtered.map((p) => {
                const pts = splitPoints(p.sellingPoints)
                const sc = scriptCountByProduct.get(p.id) ?? { total: 0, active: 0 }
                const isSelected = selected.has(p.id)
                return (
                  <motion.div
                    key={p.id}
                    variants={gridItem}
                    exit="exit"
                    layout
                    layoutId={`product-${p.id}`}
                    whileHover={{ y: -3 }}
                    className="group relative h-[340px] overflow-hidden rounded-[14px] border border-line bg-ink-card card-shadow transition-colors duration-250 hover:border-line-strong"
                  >
                    {/* 图片区 */}
                    <div className="relative h-[180px] overflow-hidden rounded-t-[10px] bg-ink-input">
                      {p.imageUrl ? (
                        <img
                          src={p.imageUrl}
                          alt={p.name}
                          className="h-full w-full object-contain"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center">
                          <Package className="h-10 w-10 text-fg-tertiary/50" />
                        </div>
                      )}
                      {/* 状态 Pill */}
                      <div className="absolute left-3 top-3">
                        <StatusPill status={p.status} />
                      </div>
                      {/* 多选 checkbox */}
                      <button
                        type="button"
                        onClick={() => toggleSelect(p.id)}
                        aria-label="选择产品"
                        className={cn(
                          'absolute right-3 top-3 flex h-5 w-5 items-center justify-center rounded-[6px] border transition-all',
                          isSelected
                            ? 'border-brand bg-brand text-white opacity-100'
                            : 'border-line-strong bg-[rgba(10,13,19,0.6)] text-transparent opacity-0 backdrop-blur group-hover:opacity-100',
                        )}
                      >
                        <Check className="h-3.5 w-3.5" />
                      </button>
                      {/* Hover 操作层 */}
                      <div className="absolute inset-0 flex items-end justify-center bg-[rgba(10,13,19,0.6)] pb-5 opacity-0 backdrop-blur-[1px] transition-opacity duration-200 group-hover:opacity-100">
                        <div className="flex gap-3">
                          {[
                            { icon: Pencil, label: '编辑', onClick: () => openEdit(p) },
                            {
                              icon: Sparkles,
                              label: '生成话术',
                              onClick: () => navigate(`/scripts?product=${p.id}`),
                            },
                            { icon: Trash2, label: '删除', onClick: () => setDeleting(p), danger: true },
                          ].map((btn, i) => (
                            <motion.button
                              key={btn.label}
                              type="button"
                              title={btn.label}
                              onClick={btn.onClick}
                              initial={false}
                              className={cn(
                                'flex h-10 w-10 translate-y-3 items-center justify-center rounded-full border border-line-strong bg-ink-elevated/90 text-fg-secondary opacity-0 backdrop-blur transition-all duration-200 group-hover:translate-y-0 group-hover:opacity-100',
                                btn.danger
                                  ? 'hover:border-bad/50 hover:text-bad'
                                  : 'hover:border-brand/60 hover:text-brand-hover',
                              )}
                              style={{ transitionDelay: `${i * 60}ms` }}
                            >
                              <btn.icon className="h-4 w-4" />
                            </motion.button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* 信息区 */}
                    <div className="flex h-[160px] flex-col p-4">
                      <h3 className="truncate text-[15px] font-semibold leading-6 text-fg">
                        {p.name}
                      </h3>
                      <div className="mt-2 flex h-[22px] flex-wrap items-center gap-1.5 overflow-hidden">
                        {pts.slice(0, 3).map((pt) => (
                          <span
                            key={pt}
                            className="rounded-[6px] bg-brand-soft px-1.5 py-0.5 text-xs text-brand-hover"
                          >
                            {pt}
                          </span>
                        ))}
                        {pts.length > 3 && (
                          <span className="text-xs text-fg-tertiary">+{pts.length - 3}</span>
                        )}
                      </div>
                      <div className="mt-auto flex items-end justify-between">
                        <div>
                          <span className="font-display text-lg font-bold text-fg">
                            {formatPrice(p.price)}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => navigate(`/scripts?product=${p.id}`)}
                          className={cn(
                            'flex items-center gap-1 rounded-[6px] px-1.5 py-0.5 text-xs transition-colors',
                            sc.active > 0
                              ? 'text-ok hover:bg-[rgba(52,211,153,0.12)]'
                              : 'text-fg-tertiary hover:bg-ink-hover hover:text-fg-secondary',
                          )}
                        >
                          <ScrollText className="h-3.5 w-3.5" />
                          {sc.total} 篇话术
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </AnimatePresence>
          </motion.div>
        ) : (
          /* ---- 表格视图 ---- */
          <div className="overflow-hidden rounded-[14px] border border-line bg-ink-card card-shadow">
            <table className="w-full">
              <thead>
                <tr className="border-b border-line text-left text-xs font-medium tracking-[0.05em] text-fg-tertiary">
                  <th className="px-4 py-3">产品</th>
                  <th className="px-4 py-3">价格</th>
                  <th className="px-4 py-3">话术数</th>
                  <th className="px-4 py-3">状态</th>
                  <th className="px-4 py-3">更新时间</th>
                  <th className="px-4 py-3 text-right">操作</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p, i) => {
                  const pts = splitPoints(p.sellingPoints)
                  const sc = scriptCountByProduct.get(p.id) ?? { total: 0, active: 0 }
                  return (
                    <motion.tr
                      key={p.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: i * 0.04 }}
                      className="border-b border-line last:border-0 transition-colors hover:bg-ink-hover"
                    >
                      <td className="px-4 py-2">
                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 shrink-0 overflow-hidden rounded-[8px] bg-ink-input">
                            {p.imageUrl ? (
                              <img src={p.imageUrl} alt={p.name} className="h-full w-full object-contain" />
                            ) : (
                              <div className="flex h-full items-center justify-center">
                                <Package className="h-5 w-5 text-fg-tertiary/50" />
                              </div>
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium text-fg">{p.name}</p>
                            <p className="truncate text-xs text-fg-tertiary">
                              {pts.slice(0, 3).join(' · ') || '—'}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-2 font-display text-sm font-bold text-fg">
                        {formatPrice(p.price)}
                      </td>
                      <td className="px-4 py-2">
                        <span
                          className={cn(
                            'text-[13px]',
                            sc.active > 0 ? 'text-ok' : 'text-fg-secondary',
                          )}
                        >
                          {sc.total} 篇
                        </span>
                      </td>
                      <td className="px-4 py-2">
                        <StatusPill status={p.status} />
                      </td>
                      <td className="px-4 py-2 font-mono text-xs text-fg-tertiary">
                        {formatTime(p.updatedAt)}
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex justify-end gap-1">
                          <GhostIconButton onClick={() => openEdit(p)} title="编辑">
                            <Pencil className="h-4 w-4" />
                          </GhostIconButton>
                          <GhostIconButton
                            onClick={() => navigate(`/scripts?product=${p.id}`)}
                            title="生成话术"
                          >
                            <Sparkles className="h-4 w-4" />
                          </GhostIconButton>
                          <GhostIconButton
                            onClick={() => setDeleting(p)}
                            title="删除"
                            className="hover:text-bad"
                          >
                            <Trash2 className="h-4 w-4" />
                          </GhostIconButton>
                        </div>
                      </td>
                    </motion.tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 抽屉 */}
      <AnimatePresence>
        {drawerOpen && (
          <ProductDrawer
            key={editing?.id ?? 'new'}
            product={editing}
            onClose={() => setDrawerOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* 删除确认 */}
      <AnimatePresence>
        {deleting && (
          <DeleteModal
            product={deleting}
            scriptCount={scriptCountByProduct.get(deleting.id)?.total ?? 0}
            deleting={removeMutation.isPending}
            onCancel={() => setDeleting(null)}
            onConfirm={() => removeMutation.mutate({ id: deleting.id })}
          />
        )}
      </AnimatePresence>
    </div>
  )
}
