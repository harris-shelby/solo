import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import {
  BookOpen,
  Check,
  Copy,
  Eye,
  EyeOff,
  Heart,
  ListChecks,
  Loader2,
  Maximize2,
  MessageCircle,
  Package,
  PartyPopper,
  Play,
  Plus,
  Radio,
  RefreshCw,
  ScrollText,
  Square,
  TrendingUp,
  Users,
  Volume2,
  Zap,
} from 'lucide-react'
import { Area, AreaChart, ResponsiveContainer } from 'recharts'
import { toast } from 'sonner'
import { Toaster } from '@/components/ui/sonner'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import { trpc } from '@/providers/trpc'
import { cn } from '@/lib/utils'

/* ======================================================================
 * 常量与工具
 * ==================================================================== */

type SessionStatus = 'pending' | 'live' | 'ended'

const SECTION_META: Record<string, { label: string; color: string }> = {
  welcome: { label: '开场互动', color: '#6C5CE7' },
  intro: { label: '产品介绍', color: '#06B6D4' },
  selling: { label: '卖点讲解', color: '#10B981' },
  interaction: { label: '互动留人', color: '#F59E0B' },
  faq: { label: '答疑环节', color: '#F472B6' },
  closing: { label: '逼单收尾', color: '#EF4444' },
}

const PLATFORMS = ['抖音', '快手', '视频号', '淘宝']

const DANMAKU_POOL = [
  '已拍！坐等发货',
  '多少钱？',
  '主播声音好好听',
  '这个有优惠券吗',
  '蹲一个链接',
  '看着不错，入了入了',
  '能再演示一下吗',
  'AI 主播也太拼了吧',
  '已关注，下次还来',
  '包邮吗老板',
]

const FALLBACK_SENTENCES: Array<{ type: string; text: string }> = [
  { type: 'welcome', text: '欢迎来到直播间，新进来的朋友点个关注不迷路。' },
  { type: 'intro', text: '今天给大家带来的是本场主打产品，先给大家全方位展示一下。' },
  { type: 'selling', text: '这款产品的核心卖点非常能打，性价比直接拉满。' },
  { type: 'interaction', text: '弹幕扣个 1，让我看看有多少朋友在蹲守。' },
  { type: 'faq', text: '有朋友问售后问题，我们支持七天无理由退换。' },
  { type: 'closing', text: '库存不多了，喜欢的朋友抓紧点击下方链接下单。' },
]

function formatElapsed(totalSec: number) {
  const s = Math.max(0, Math.floor(totalSec))
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`
}

function splitSentences(content: string) {
  return content
    .split(/(?<=[。！？!?])/)
    .map((t) => t.trim())
    .filter(Boolean)
}

function rand(min: number, max: number) {
  return Math.floor(min + Math.random() * (max - min + 1))
}

function estimateSeconds(text: string) {
  return Math.min(8, Math.max(2.5, text.length / 5))
}

/* ======================================================================
 * 小组件
 * ==================================================================== */

/** 状态徽章（StatusPill） */
function StatusPill({ status, className }: { status: SessionStatus | string; className?: string }) {
  if (status === 'live') {
    return (
      <span
        className={cn(
          'inline-flex items-center gap-1.5 rounded-full bg-[rgba(255,77,109,0.12)] px-2 py-0.5 text-xs font-medium text-live',
          className,
        )}
      >
        <span className="h-1.5 w-1.5 rounded-full bg-live animate-live-breathe" />
        直播中
      </span>
    )
  }
  if (status === 'pending') {
    return (
      <span
        className={cn(
          'inline-flex items-center gap-1.5 rounded-full bg-[rgba(251,191,36,0.12)] px-2 py-0.5 text-xs font-medium text-warn',
          className,
        )}
      >
        待开播
      </span>
    )
  }
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full bg-[rgba(30,36,48,0.10)] px-2 py-0.5 text-xs font-medium text-fg-secondary',
        className,
      )}
    >
      已结束
    </span>
  )
}

/** 复制按钮：复制后图标变 Check + Toast */
function CopyButton({ text, toastText = '已复制' }: { text: string; toastText?: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      type="button"
      aria-label="复制"
      className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-fg-tertiary transition-colors hover:bg-ink-hover hover:text-fg"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text)
        } catch {
          /* 剪贴板不可用时静默降级 */
        }
        setCopied(true)
        toast.success(toastText)
        window.setTimeout(() => setCopied(false), 1500)
      }}
    >
      {copied ? <Check className="h-3.5 w-3.5 text-ok" /> : <Copy className="h-3.5 w-3.5" />}
    </button>
  )
}

/** 声波波形（5 根竖条）——永久动画隔离在 memo 微组件中 */
const WaveBars = memo(function WaveBars({ active }: { active: boolean }) {
  return (
    <div className="flex h-4 items-end gap-[2px]" aria-hidden>
      {[0, 1, 2, 3, 4].map((i) => (
        <motion.span
          key={i}
          className="w-[2px] rounded-full bg-signal"
          style={{ height: '100%', transformOrigin: 'bottom' }}
          animate={active ? { scaleY: [0.3, 1, 0.45, 0.85, 0.3] } : { scaleY: 0.3 }}
          transition={
            active
              ? { duration: 1, repeat: Infinity, delay: i * 0.1, ease: 'easeInOut' }
              : { duration: 0.2 }
          }
        />
      ))}
    </div>
  )
})

function Card({
  title,
  icon: Icon,
  extra,
  children,
  className,
  highlight,
}: {
  title: string
  icon: ReactNode
  extra?: ReactNode
  children: ReactNode
  className?: string
  highlight?: boolean
}) {
  return (
    <motion.section
      className={cn('rounded-[14px] border border-line bg-ink-card p-5 shadow-card', className)}
      animate={
        highlight
          ? { boxShadow: ['0 0 0 0 rgba(108,92,231,0)', '0 0 0 4px rgba(108,92,231,0.25)', '0 0 0 0 rgba(108,92,231,0)'] }
          : undefined
      }
      transition={highlight ? { duration: 1.8, repeat: Infinity } : undefined}
    >
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-[15px] font-semibold leading-6 text-fg">
          <span className="text-brand">{Icon}</span>
          {title}
        </h3>
        {extra}
      </div>
      {children}
    </motion.section>
  )
}

function FieldLabel({ children }: { children: ReactNode }) {
  return <label className="mb-1.5 block text-[13px] font-medium text-fg-secondary">{children}</label>
}

const inputCls =
  'h-[38px] w-full rounded-[10px] border border-line bg-ink-input px-3 text-sm text-fg outline-none transition-shadow placeholder:text-fg-tertiary focus:border-brand focus:shadow-[0_0_0_3px_rgba(108,92,231,0.15)]'

/** 开播检查清单勾选行 */
function CheckRow({
  checked,
  onToggle,
  label,
  auto,
}: {
  checked: boolean
  onToggle?: () => void
  label: string
  auto?: boolean
}) {
  return (
    <button
      type="button"
      disabled={auto}
      onClick={onToggle}
      className={cn(
        'flex w-full items-center gap-2.5 rounded-[8px] px-1 py-1 text-left transition-colors',
        auto ? 'cursor-default' : 'hover:bg-ink-hover',
      )}
    >
      <motion.span
        className={cn(
          'flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-[5px] border transition-colors',
          checked ? 'border-ok bg-[rgba(52,211,153,0.15)]' : 'border-line-strong',
        )}
        animate={checked ? { scale: [0.7, 1.15, 1] } : { scale: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 18 }}
      >
        {checked && <Check className="h-3 w-3 text-ok" />}
      </motion.span>
      <span
        className={cn(
          'relative text-[13px] transition-colors',
          checked ? 'text-fg-secondary' : 'text-fg-tertiary',
        )}
      >
        {label}
        <motion.span
          className="absolute left-0 top-1/2 h-px w-full bg-fg-tertiary"
          initial={false}
          animate={{ scaleX: checked ? 1 : 0, opacity: checked ? 0.7 : 0 }}
          style={{ transformOrigin: 'left' }}
          transition={{ duration: 0.25 }}
        />
      </span>
      {auto && checked && <span className="ml-auto text-[11px] text-ok">自动完成</span>}
    </button>
  )
}

/* ======================================================================
 * 直播控制台页面
 * ==================================================================== */

type QueueItem = { type: string; text: string; seconds: number }
type Danmaku = { id: number; text: string; left: number }

export default function Live() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const reduceMotion = useReducedMotion()
  const utils = trpc.useUtils()

  /* ---------------- 数据 ---------------- */
  const sessionsQuery = trpc.live.list.useQuery(undefined, { refetchInterval: 5000 })
  const sessions = useMemo(() => sessionsQuery.data ?? [], [sessionsQuery.data])
  const productsQuery = trpc.products.list.useQuery()
  const products = useMemo(() => productsQuery.data ?? [], [productsQuery.data])
  const scriptsQuery = trpc.scripts.list.useQuery(undefined)

  const settingsQuery = trpc.settings.get.useQuery()
  const ttsPreviewMut = trpc.tts.preview.useMutation()
  const scripts = useMemo(() => scriptsQuery.data ?? [], [scriptsQuery.data])
  const activeScripts = useMemo(() => scripts.filter((s) => s.status === 'active'), [scripts])

  /* ---------------- 任务选择与表单 ---------------- */
  const [selectedId, setSelectedId] = useState<number | 'new' | null>(null)
  const selectedSession =
    typeof selectedId === 'number' ? sessions.find((s) => s.id === selectedId) ?? null : null
  const isLive = selectedSession?.status === 'live'
  const isEnded = selectedSession?.status === 'ended'

  const [title, setTitle] = useState('')
  const [productIds, setProductIds] = useState<number[]>([])
  const [scriptId, setScriptId] = useState<number | null>(null)
  const [platform, setPlatform] = useState('抖音')
  const [plannedMinutes, setPlannedMinutes] = useState(120)
  const [rtmpUrl, setRtmpUrl] = useState('')
  const [streamKey, setStreamKey] = useState('')
  const [loopPlay, setLoopPlay] = useState(true)
  const [insertInteraction, setInsertInteraction] = useState(false)

  const defaultTitle = useMemo(() => {
    const d = new Date()
    return `${d.getMonth() + 1}月${d.getDate()}日 · 直播专场`
  }, [])

  const resetForm = useCallback(() => {
    setTitle(defaultTitle)
    setProductIds(products.slice(0, 3).map((p) => p.id))
    setScriptId(activeScripts[0]?.id ?? null)
    setPlatform('抖音')
    setPlannedMinutes(120)
    setRtmpUrl('')
    setStreamKey('')
    setLoopPlay(true)
    setInsertInteraction(false)
  }, [defaultTitle, products, activeScripts])

  // 默认选中：直播中 > 待开播 > 最新任务 > 新建
  useEffect(() => {
    if (selectedId !== null || !sessionsQuery.data) return
    const live = sessions.find((s) => s.status === 'live')
    const pending = sessions.find((s) => s.status === 'pending')
    setSelectedId(live?.id ?? pending?.id ?? sessions[0]?.id ?? 'new')
  }, [sessionsQuery.data, sessions, selectedId])

  // 切换任务时同步表单（不随轮询覆盖用户编辑）
  const sessionsRef = useRef(sessions)
  sessionsRef.current = sessions
  useEffect(() => {
    if (selectedId === 'new') {
      resetForm()
      return
    }
    if (typeof selectedId !== 'number') return
    const s = sessionsRef.current.find((x) => x.id === selectedId)
    if (!s) return
    setTitle(s.title)
    setPlatform(s.platform || '抖音')
    setRtmpUrl(s.rtmpUrl ?? '')
    setStreamKey(s.streamKey ?? '')
    setPlannedMinutes(s.plannedMinutes ?? 120)
    setScriptId(s.scriptId)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId])

  // ?new=1：进入新建模式并聚焦任务名称
  const titleInputRef = useRef<HTMLInputElement>(null)
  const [titleFlash, setTitleFlash] = useState(false)
  useEffect(() => {
    if (searchParams.get('new') !== '1') return
    setSelectedId('new')
    setTitleFlash(true)
    const t = window.setTimeout(() => titleInputRef.current?.focus(), 350)
    const t2 = window.setTimeout(() => setTitleFlash(false), 1800)
    return () => {
      window.clearTimeout(t)
      window.clearTimeout(t2)
    }
  }, [searchParams])

  /* ---------------- 话术队列 ---------------- */
  const scriptDetailQuery = trpc.scripts.get.useQuery(
    { id: scriptId ?? 0 },
    { enabled: typeof scriptId === 'number' && scriptId > 0 },
  )
  const queue = useMemo<QueueItem[]>(() => {
    const sections = scriptDetailQuery.data?.sections
    if (sections && sections.length > 0) {
      return sections.flatMap((sec) =>
        splitSentences(sec.content).map((text) => ({
          type: sec.type,
          text,
          seconds: estimateSeconds(text),
        })),
      )
    }
    return FALLBACK_SENTENCES.map((s) => ({ ...s, seconds: estimateSeconds(s.text) }))
  }, [scriptDetailQuery.data])

  const selectedScript = scripts.find((s) => s.id === scriptId) ?? null
  const scriptReady = !!selectedScript && selectedScript.status === 'active'

  /* ---------------- 预览模拟状态 ---------------- */
  const [auditioning, setAuditioning] = useState(false)
  const playing = isLive || auditioning
  const [captionPaused, setCaptionPaused] = useState(false)
  const [sentenceIdx, setSentenceIdx] = useState(0)
  const [loopRound, setLoopRound] = useState(1)
  const [carouselIdx, setCarouselIdx] = useState(0)
  const [viewers, setViewers] = useState(1284)
  const [likes, setLikes] = useState(3200)
  const [fans, setFans] = useState(86)
  const [comments, setComments] = useState(214)
  const [tokensUsed, setTokensUsed] = useState(0)
  const [chartData, setChartData] = useState<Array<{ t: number; v: number }>>([])
  const [danmakus, setDanmakus] = useState<Danmaku[]>([])
  const [volume, setVolume] = useState(70)
  const peakViewersRef = useRef(1284)
  const danmakuIdRef = useRef(0)
  const previewRef = useRef<HTMLDivElement>(null)
  const queueListRef = useRef<HTMLDivElement>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const ttsCacheRef = useRef<Map<string, string>>(new Map())
  const ttsFailedRef = useRef(false)
  const volumeRef = useRef(70)

  // 轮播产品图：优先已选产品图，否则演示图
  const carouselImages = useMemo(() => {
    const chosen = products
      .filter((p) => productIds.includes(p.id))
      .map((p) => ({ name: p.name, price: p.price, img: p.imageUrl || '' }))
      .filter((p) => p.img)
    if (chosen.length > 0) return chosen
    return [1, 2, 3, 4].map((n) => ({
      name: ['曜石黑无线耳机', '复古空气炸锅', '烟酰胺精华液', '精品咖啡豆'][n - 1],
      price: ['299.00', '399.00', '259.00', '129.00'][n - 1],
      img: `/product-demo-${n}.webp`,
    }))
  }, [products, productIds])
  const currentProduct = carouselImages[carouselIdx % carouselImages.length]

  // 字幕逐句滚动（试听时由 TTS 音频驱动，此处暂停计时器）
  useEffect(() => {
    if (!playing || captionPaused || auditioning || queue.length === 0) return
    const cur = queue[sentenceIdx % queue.length]
    const t = window.setTimeout(() => {
      setSentenceIdx((i) => {
        const next = (i + 1) % queue.length
        if (next === 0) setLoopRound((r) => r + 1)
        return next
      })
    }, cur.seconds * 1000)
    return () => window.clearTimeout(t)
  }, [playing, captionPaused, auditioning, sentenceIdx, queue])

  // 音量实时同步到试听音频
  useEffect(() => {
    volumeRef.current = volume
    if (audioRef.current) audioRef.current.volume = volume / 100
  }, [volume])

  // 试听：真实 TTS 语音，音频播完自动切下一句；合成失败退回字幕计时
  useEffect(() => {
    if (!auditioning || queue.length === 0) return
    let cancelled = false
    let fallbackTimer = 0
    const cur = queue[sentenceIdx % queue.length]
    const settings = settingsQuery.data
    const voice = settings?.ttsVoice ?? 'zh-CN-XiaoxiaoNeural'
    const rateRaw = settings?.ttsRate
    const rate = rateRaw == null ? 1 : Number(rateRaw)

    const advance = () => {
      if (cancelled) return
      setSentenceIdx((i) => {
        const next = (i + 1) % queue.length
        if (next === 0) setLoopRound((r) => r + 1)
        return next
      })
    }

    const play = async () => {
      try {
        let url = ttsCacheRef.current.get(cur.text)
        if (!url) {
          const res = await ttsPreviewMut.mutateAsync({ text: cur.text, voice, rate })
          const bytes = Uint8Array.from(atob(res.audioBase64), (ch) => ch.charCodeAt(0))
          url = URL.createObjectURL(new Blob([bytes], { type: res.mime }))
          ttsCacheRef.current.set(cur.text, url)
        }
        if (cancelled) return
        const audio = new Audio(url)
        audio.volume = volumeRef.current / 100
        audioRef.current = audio
        audio.onended = advance
        audio.onerror = () => {
          fallbackTimer = window.setTimeout(advance, cur.seconds * 1000)
        }
        await audio.play().catch(() => {
          fallbackTimer = window.setTimeout(advance, cur.seconds * 1000)
        })
      } catch {
        if (!ttsFailedRef.current) {
          ttsFailedRef.current = true
          toast.error('TTS 合成失败，本次试听只显示字幕')
        }
        if (!cancelled) fallbackTimer = window.setTimeout(advance, cur.seconds * 1000)
      }
    }
    void play()

    return () => {
      cancelled = true
      window.clearTimeout(fallbackTimer)
      audioRef.current?.pause()
      audioRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auditioning, sentenceIdx, queue, settingsQuery.data])

  // 队列自动跟随滚动
  useEffect(() => {
    const list = queueListRef.current
    if (!list) return
    const row = list.querySelector<HTMLElement>(`[data-idx="${sentenceIdx}"]`)
    row?.scrollIntoView({ block: 'center', behavior: reduceMotion ? 'auto' : 'smooth' })
  }, [sentenceIdx, reduceMotion])

  // 产品轮播 8s
  useEffect(() => {
    if (!playing) return
    const t = window.setInterval(() => setCarouselIdx((i) => i + 1), 8000)
    return () => window.clearInterval(t)
  }, [playing])

  // 弹幕流
  useEffect(() => {
    if (!playing) return
    let alive = true
    let timer = 0
    const push = () => {
      if (!alive) return
      const item: Danmaku = {
        id: ++danmakuIdRef.current,
        text: DANMAKU_POOL[rand(0, DANMAKU_POOL.length - 1)],
        left: rand(0, 55),
      }
      setDanmakus((d) => [...d.slice(-5), item])
      timer = window.setTimeout(push, rand(2000, 4000))
    }
    push()
    return () => {
      alive = false
      window.clearTimeout(timer)
    }
  }, [playing])

  // 实时数据模拟（仅直播中）
  useEffect(() => {
    if (!isLive) return
    const tick = () => {
      setViewers((v) => {
        const next = Math.max(120, v + rand(-30, 65))
        peakViewersRef.current = Math.max(peakViewersRef.current, next)
        setChartData((d) => [...d.slice(-19), { t: Date.now(), v: next }])
        return next
      })
      setLikes((v) => v + rand(5, 40))
      setFans((v) => v + rand(0, 3))
      setComments((v) => v + rand(0, 5))
      setTokensUsed((v) => v + rand(8, 25))
    }
    tick()
    const t = window.setInterval(tick, rand(3000, 6000))
    return () => window.clearInterval(t)
  }, [isLive])

  // 直播计时
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => {
    if (!isLive) return
    const t = window.setInterval(() => setNow(Date.now()), 1000)
    return () => window.clearInterval(t)
  }, [isLive])
  const startedAtMs = selectedSession?.startedAt ? new Date(selectedSession.startedAt).getTime() : null
  const elapsedSec = isLive && startedAtMs ? Math.floor((now - startedAtMs) / 1000) : 0

  // 直播中离开页面确认
  useEffect(() => {
    if (!isLive) return
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault()
      e.returnValue = '直播仍在进行，确定离开？'
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [isLive])

  /* ---------------- 开播检查清单 ---------------- */
  const [checkObs, setCheckObs] = useState(false)
  const [checkRtmp, setCheckRtmp] = useState(false)
  const [checkTts, setCheckTts] = useState(false)
  const checklist: Array<{ label: string; checked: boolean; toggle?: () => void; auto?: boolean }> = [
    { label: 'OBS 已安装并添加「窗口采集」源', checked: checkObs, toggle: () => setCheckObs((v) => !v) },
    { label: '推流地址与密钥已填入 OBS', checked: checkRtmp, toggle: () => setCheckRtmp((v) => !v) },
    { label: 'TTS 试听正常', checked: checkTts, toggle: () => setCheckTts((v) => !v) },
    { label: '话术已启用', checked: scriptReady, auto: true },
  ]
  const checklistDone = checklist.every((c) => c.checked)

  /* ----------------  mutations ---------------- */
  const [connecting, setConnecting] = useState(false)
  const [confirmStop, setConfirmStop] = useState(false)
  const [recap, setRecap] = useState<null | {
    duration: string
    peak: number
    interactions: number
    tokens: number
  }>(null)

  const handleMutationError = useCallback((err: { data?: { code?: string } | null; message: string }) => {
    if (err.data?.code === 'CONFLICT') {
      toast.error('无法开播：已有直播任务正在进行', { description: err.message })
    } else {
      toast.error(err.message || '操作失败，请稍后重试')
    }
  }, [])

  const createMut = trpc.live.create.useMutation({ onError: handleMutationError })
  const startMut = trpc.live.start.useMutation({ onError: handleMutationError })
  const stopMut = trpc.live.stop.useMutation({ onError: handleMutationError })

  const handleStart = async () => {
    if (connecting || isLive) return
    if (!checklistDone) {
      toast.warning('请先完成开播检查清单')
      return
    }
    if (!scriptId) {
      toast.error('请先选择一套已启用的话术')
      return
    }
    setConnecting(true)
    try {
      let id = typeof selectedId === 'number' ? selectedId : null
      if (!id) {
        const created = await createMut.mutateAsync({
          scriptId,
          title: title.trim() || defaultTitle,
          platform,
          rtmpUrl: rtmpUrl || undefined,
          streamKey: streamKey || undefined,
          plannedMinutes,
        })
        if (!created) throw new Error('创建任务失败')
        id = created.id
        setSelectedId(created.id)
      }
      // 模拟「正在连接推流…」
      await new Promise((r) => setTimeout(r, 1500))
      await startMut.mutateAsync({ id })
      await utils.live.list.invalidate()
      peakViewersRef.current = viewers
      toast.success('直播已开始，AI 主播上工了', { description: `「${title || defaultTitle}」正在${platform}直播` })
    } catch {
      /* 错误已在 onError 中提示 */
    } finally {
      setConnecting(false)
    }
  }

  const handleStop = async () => {
    if (typeof selectedId !== 'number') return
    setConfirmStop(false)
    try {
      await stopMut.mutateAsync({ id: selectedId })
      await utils.live.list.invalidate()
      setAuditioning(false)
      setRecap({
        duration: formatElapsed(elapsedSec),
        peak: peakViewersRef.current,
        interactions: likes + comments,
        tokens: tokensUsed,
      })
    } catch {
      /* onError 已提示 */
    }
  }

  const toggleProduct = (id: number) =>
    setProductIds((ids) =>
      ids.includes(id) ? ids.filter((x) => x !== id) : ids.length >= 8 ? ids : [...ids, id],
    )

  const handleAudition = () => {
    if (auditioning) {
      setAuditioning(false)
      toast.success('已停止试听')
      return
    }
    ttsFailedRef.current = false
    setAuditioning(true)
    setCaptionPaused(false)
    setCheckTts(true)
    toast.success('开始试听，AI 主播开口了')
  }

  const handleFullscreen = () => {
    previewRef.current?.requestFullscreen?.().catch(() => toast.error('当前环境不支持全屏'))
  }

  const handleRefreshPreview = () => {
    setSentenceIdx(0)
    setLoopRound(1)
    setCarouselIdx(0)
    setDanmakus([])
    toast.success('预览已刷新')
  }

  /* ---------------- 渲染 ---------------- */
  const livePrice = currentProduct
    ? (Math.max(1, Math.round(Number(currentProduct.price) * 0.67 * 100)) / 100).toFixed(2)
    : '199.00'

  return (
    <div className="mx-auto max-w-[1560px] p-4 sm:p-6 lg:p-8">
      <Toaster position="top-right" />

      {/* ===== 任务切换条 ===== */}
      <div className="mb-5 flex items-center gap-2 overflow-x-auto pb-1">
        <ListChecks className="h-4 w-4 shrink-0 text-fg-tertiary" />
        {sessionsQuery.isLoading && (
          <span className="h-8 w-40 animate-pulse rounded-full bg-ink-card" />
        )}
        {sessions.map((s) => {
          const active = selectedId === s.id
          return (
            <button
              key={s.id}
              type="button"
              onClick={() => setSelectedId(s.id)}
              className={cn(
                'relative flex h-9 shrink-0 items-center gap-2 rounded-full border px-3.5 text-[13px] transition-colors',
                active
                  ? 'border-brand/40 text-fg'
                  : 'border-line text-fg-secondary hover:border-line-strong hover:text-fg',
              )}
            >
              {active && (
                <motion.span
                  layoutId="task-chip-active"
                  className="absolute inset-0 rounded-full bg-brand-soft"
                  transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                />
              )}
              <StatusPill status={s.status} className="relative z-10 !px-1.5" />
              <span className="relative z-10 max-w-[160px] truncate">{s.title}</span>
            </button>
          )
        })}
        <button
          type="button"
          onClick={() => {
            setSelectedId('new')
            resetForm()
            window.setTimeout(() => titleInputRef.current?.focus(), 200)
          }}
          className="flex h-9 shrink-0 items-center gap-1.5 rounded-full border border-dashed border-line-strong px-3.5 text-[13px] text-fg-secondary transition-colors hover:border-brand hover:text-brand-hover"
        >
          <Plus className="h-3.5 w-3.5" />
          新建任务
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1fr_380px]">
        {/* ================= 左列 ================= */}
        <div className="min-w-0 space-y-5">
          {/* ---- 直播预览画面 ---- */}
          <div className="relative">
            {isLive && !reduceMotion && (
              <div
                className="absolute -inset-1 rounded-[24px] shadow-glow-live animate-status-breathe"
                aria-hidden
              />
            )}
            <div
              ref={previewRef}
              onClick={() => setCaptionPaused((v) => !v)}
              className="relative aspect-video w-full cursor-crosshair select-none overflow-hidden rounded-[20px] border border-line bg-ink-elevated"
            >
              <img
                src="/live-preview-bg.webp"
                alt="直播间预览背景"
                className="absolute inset-0 h-full w-full object-cover"
                draggable={false}
              />

              {/* 顶部叠加条 */}
              <div className="absolute inset-x-0 top-0 z-20 flex items-center justify-between bg-gradient-to-b from-black/70 to-transparent px-4 pb-8 pt-3">
                <div className="flex items-center gap-3">
                  {isLive ? (
                    <span className="flex items-center gap-1.5 rounded-md bg-live px-2 py-1 text-xs font-bold text-white">
                      <span className="h-1.5 w-1.5 rounded-full bg-white animate-live-breathe" />
                      LIVE
                    </span>
                  ) : (
                    <span className="rounded-md bg-[rgba(30,36,48,0.25)] px-2 py-1 text-xs font-bold text-fg-secondary">
                      待机
                    </span>
                  )}
                  <span className="font-mono text-xs text-white/85">
                    {formatElapsed(elapsedSec)}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs text-white/85">
                  <span className="flex items-center gap-1.5">
                    <Eye className="h-3.5 w-3.5 text-signal" />
                    <span className="font-mono text-signal">{viewers.toLocaleString()}</span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Heart className="h-3.5 w-3.5 text-live" />
                    <span className="font-mono">
                      {likes >= 1000 ? `${(likes / 1000).toFixed(1)}k` : likes}
                    </span>
                  </span>
                </div>
              </div>

              {/* 弹幕流 */}
              <div className="pointer-events-none absolute bottom-20 left-0 top-16 z-10 w-[30%] overflow-hidden">
                <AnimatePresence>
                  {danmakus.map((d) => (
                    <motion.span
                      key={d.id}
                      className="absolute bottom-0 max-w-[90%] truncate rounded-full bg-black/45 px-3 py-1 text-xs text-white/90 backdrop-blur-sm"
                      style={{ left: `${d.left}%` }}
                      initial={{ y: 40, opacity: 0 }}
                      animate={{ y: [40, -30, -80, -120], opacity: [0, 1, 0.9, 0] }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 6, ease: 'linear' }}
                      onAnimationComplete={() =>
                        setDanmakus((list) => list.filter((x) => x.id !== d.id))
                      }
                    >
                      {d.text}
                    </motion.span>
                  ))}
                </AnimatePresence>
              </div>

              {/* 产品图轮播区 */}
              <div className="absolute inset-y-0 left-[6%] z-10 flex w-1/2 items-center justify-center">
                <AnimatePresence mode="popLayout">
                  <motion.div
                    key={carouselIdx % carouselImages.length}
                    className="relative"
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 1.05, opacity: 0 }}
                    transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <img
                      src={currentProduct.img}
                      alt={currentProduct.name}
                      className="h-40 w-auto rounded-2xl object-contain md:h-56 lg:h-64"
                      style={{ filter: 'drop-shadow(0 24px 24px rgba(0,0,0,0.45))' }}
                      draggable={false}
                    />
                  </motion.div>
                </AnimatePresence>
                {/* 产品信息小卡 */}
                <div className="absolute bottom-4 left-0 rounded-[10px] border border-white/10 bg-black/40 px-3 py-2 backdrop-blur-md">
                  <p className="max-w-[200px] truncate text-[13px] font-medium text-white">
                    {currentProduct.name}
                  </p>
                  <p className="mt-0.5 flex items-baseline gap-2">
                    <span className="text-xs text-white/50 line-through">
                      ¥{Number(currentProduct.price).toFixed(0)}
                    </span>
                    <span className="font-display text-lg font-bold text-live">¥{livePrice}</span>
                  </p>
                </div>
              </div>

              {/* AI 主播头像（右下角） */}
              <div className="absolute bottom-20 right-5 z-10 flex flex-col items-center gap-1.5">
                <div className="relative">
                  {playing && !reduceMotion && (
                    <motion.span
                      className="absolute -inset-1.5 rounded-full border-2 border-signal/60"
                      animate={{ scale: [1, 1.15, 1], opacity: [0.9, 0.2, 0.9] }}
                      transition={{ duration: 0.8, repeat: Infinity, ease: 'easeInOut' }}
                      aria-hidden
                    />
                  )}
                  <div
                    className="rounded-full p-[2px]"
                    style={{ background: 'linear-gradient(135deg,#6C5CE7,#00C9A7)' }}
                  >
                    <img
                      src="/avatar-host.webp"
                      alt="AI 主播"
                      className="h-20 w-20 rounded-full object-cover lg:h-24 lg:w-24"
                      draggable={false}
                    />
                  </div>
                </div>
                <span className="rounded-full bg-black/50 px-2 py-0.5 text-[10px] text-white/85 backdrop-blur-sm">
                  AI 主播 · 小珂
                </span>
              </div>

              {/* 底部字幕条 */}
              <div className="absolute inset-x-0 bottom-0 z-20 flex h-16 items-center gap-3 bg-black/40 px-5 backdrop-blur-md">
                <Volume2 className={cn('h-4 w-4 shrink-0', playing ? 'text-signal' : 'text-fg-tertiary')} />
                <div className="relative h-full flex-1 overflow-hidden">
                  <AnimatePresence mode="popLayout">
                    <motion.p
                      key={sentenceIdx}
                      className="absolute inset-0 flex items-center justify-center text-center text-base font-medium text-white"
                      initial={{ y: 16, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      exit={{ y: -16, opacity: 0 }}
                      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                    >
                      {queue[sentenceIdx % queue.length]?.text ?? '等待话术…'}
                      {captionPaused && playing && (
                        <span className="ml-2 rounded bg-white/15 px-1.5 py-0.5 text-[10px]">已暂停</span>
                      )}
                    </motion.p>
                  </AnimatePresence>
                </div>
              </div>

              {/* 未开播待机遮罩 */}
              {!playing && (
                <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-black/50">
                  <Radio className="h-14 w-14 text-fg-tertiary" />
                  <p className="text-lg font-semibold text-white/90">
                    待开播 · 配置右侧任务后点击开始直播
                  </p>
                  <p className="text-[13px] text-white/50">预览将展示话术字幕与产品轮播效果</p>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleAudition()
                    }}
                    className="mt-1 flex h-9 items-center gap-2 rounded-[10px] border border-line-strong bg-ink-hover px-4 text-[13px] font-medium text-fg transition-colors hover:border-brand"
                  >
                    <Play className="h-4 w-4" />
                    试听 TTS 预览效果
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* ---- 预览控制条 ---- */}
          <div className="flex flex-wrap items-center justify-between gap-3 sm:gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <Volume2 className="h-4 w-4 text-fg-tertiary" />
              <Slider
                className="w-32"
                value={[volume]}
                min={0}
                max={100}
                step={1}
                onValueChange={([v]) => setVolume(v)}
                aria-label="预览音量"
              />
              <span className="w-8 font-mono text-xs text-fg-tertiary">{volume}%</span>
              <button
                type="button"
                onClick={handleAudition}
                className="flex h-[38px] items-center gap-2 rounded-[10px] border border-line-strong bg-ink-hover px-4 text-[13px] font-medium text-fg transition-colors hover:border-brand"
              >
                {auditioning ? <Square className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                {auditioning ? '停止试听' : '试听 TTS'}
              </button>
            </div>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleFullscreen}
                className="flex h-9 w-9 items-center justify-center rounded-[10px] text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
                aria-label="全屏预览"
              >
                <Maximize2 className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={handleRefreshPreview}
                className="flex h-9 items-center gap-1.5 rounded-[10px] px-3 text-[13px] text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                刷新预览
              </button>
            </div>
          </div>

          {/* ---- 话术播放队列 ---- */}
          <Card
            title="播放队列"
            icon={<ScrollText className="h-4 w-4" />}
            extra={
              <span className="rounded-full bg-brand-soft px-2.5 py-0.5 text-xs font-medium text-brand-hover">
                {loopPlay ? `循环播放 · 第 ${loopRound} 轮` : '单次播放'}
              </span>
            }
          >
            <div ref={queueListRef} className="max-h-[320px] space-y-0.5 overflow-y-auto pr-1">
              {queue.map((item, i) => {
                const meta = SECTION_META[item.type] ?? { label: '话术', color: '#9AA3B5' }
                const current = i === sentenceIdx % queue.length
                return (
                  <div
                    key={`${i}-${item.text.slice(0, 8)}`}
                    data-idx={i}
                    onClick={() => setSentenceIdx(i)}
                    className={cn(
                      'relative flex h-12 cursor-pointer items-center gap-3 rounded-[8px] px-3 transition-colors duration-300',
                      current ? 'bg-brand-soft' : 'hover:bg-ink-hover',
                    )}
                  >
                    {current && (
                      <motion.span
                        layoutId="queue-active-bar"
                        className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-full bg-signal"
                        transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                      />
                    )}
                    <span className="w-6 shrink-0 text-right font-mono text-xs text-fg-tertiary">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span
                      className={cn(
                        'min-w-0 flex-1 truncate text-[13px]',
                        current ? 'text-fg' : 'text-fg-secondary',
                      )}
                    >
                      {item.text}
                    </span>
                    <span
                      className="shrink-0 rounded-md px-1.5 py-0.5 text-xs"
                      style={{ color: meta.color, background: `${meta.color}1f` }}
                    >
                      {meta.label}
                    </span>
                    <span className="w-10 shrink-0 text-right font-mono text-xs text-fg-tertiary">
                      {item.seconds.toFixed(0)}s
                    </span>
                    <div className="w-8 shrink-0">
                      {current && <WaveBars active={playing && !captionPaused} />}
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="mt-3 flex items-center gap-3 border-t border-line pt-3">
              <span className="font-mono text-xs text-fg-tertiary">
                第 {(sentenceIdx % queue.length) + 1} / {queue.length} 句
              </span>
              <div className="h-1 flex-1 overflow-hidden rounded-full bg-[rgba(30,36,48,0.12)]">
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: 'var(--accent-gradient)' }}
                  animate={{ width: `${(((sentenceIdx % queue.length) + 1) / queue.length) * 100}%` }}
                  transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                />
              </div>
            </div>
          </Card>
        </div>

        {/* ================= 右列 ================= */}
        <div className="space-y-4">
          {/* ---- 任务配置卡 ---- */}
          <Card
            title="直播任务"
            icon={<Radio className="h-4 w-4" />}
            highlight={sessions.length === 0 || selectedId === 'new'}
          >
            <div className="space-y-4">
              <div>
                <FieldLabel>任务名称</FieldLabel>
                <motion.div
                  animate={
                    titleFlash
                      ? { boxShadow: ['0 0 0 0 rgba(108,92,231,0)', '0 0 0 4px rgba(108,92,231,0.5)', '0 0 0 0 rgba(108,92,231,0)', '0 0 0 4px rgba(108,92,231,0.5)', '0 0 0 0 rgba(108,92,231,0)'] }
                      : { boxShadow: '0 0 0 0 rgba(108,92,231,0)' }
                  }
                  transition={{ duration: 1.6 }}
                  className="rounded-[10px]"
                >
                  <input
                    ref={titleInputRef}
                    className={inputCls}
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="例如：6月14日 · 耳机专场"
                    disabled={isLive || isEnded}
                  />
                </motion.div>
              </div>

              <div>
                <FieldLabel>选择产品（最多 8 个）</FieldLabel>
                {products.length === 0 ? (
                  <Link
                    to="/products"
                    className="flex items-center gap-2 rounded-[10px] border border-dashed border-line-strong px-3 py-2.5 text-[13px] text-fg-tertiary transition-colors hover:border-brand hover:text-brand-hover"
                  >
                    <Package className="h-4 w-4" />
                    还没有产品，先去产品管理上传
                  </Link>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {products.map((p) => {
                      const on = productIds.includes(p.id)
                      return (
                        <button
                          key={p.id}
                          type="button"
                          disabled={isLive || isEnded}
                          onClick={() => toggleProduct(p.id)}
                          className={cn(
                            'flex items-center gap-1.5 rounded-full border py-1 pl-1 pr-2.5 text-xs transition-colors',
                            on
                              ? 'border-brand/50 bg-brand-soft text-fg'
                              : 'border-line text-fg-secondary hover:border-line-strong',
                          )}
                        >
                          <img
                            src={p.imageUrl || '/product-demo-1.webp'}
                            alt=""
                            className="h-6 w-6 rounded-full object-cover"
                          />
                          <span className="max-w-[96px] truncate">{p.name}</span>
                        </button>
                      )
                    })}
                  </div>
                )}
              </div>

              <div>
                <FieldLabel>选择话术（仅列出已启用）</FieldLabel>
                <div className="relative">
                  <select
                    className={cn(inputCls, 'appearance-none pr-8')}
                    value={scriptId ?? ''}
                    disabled={isLive || isEnded}
                    onChange={(e) => setScriptId(e.target.value ? Number(e.target.value) : null)}
                  >
                    <option value="">请选择话术版本</option>
                    {activeScripts.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.title}（v{s.version}）
                      </option>
                    ))}
                  </select>
                  <ScrollText className="pointer-events-none absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-fg-tertiary" />
                </div>
                {activeScripts.length === 0 && (
                  <p className="mt-1.5 text-xs text-bad">
                    暂无已启用话术，请先到
                    <Link to="/scripts" className="mx-1 text-brand-hover underline underline-offset-2">
                      话术工作台
                    </Link>
                    生成并启用话术
                  </p>
                )}
              </div>

              <div>
                <FieldLabel>直播平台</FieldLabel>
                <div className="grid grid-cols-4 gap-1 rounded-[10px] border border-line bg-ink-input p-1">
                  {PLATFORMS.map((p) => (
                    <button
                      key={p}
                      type="button"
                      disabled={isLive || isEnded}
                      onClick={() => setPlatform(p)}
                      className={cn(
                        'relative h-8 rounded-[8px] text-[13px] transition-colors',
                        platform === p ? 'text-fg' : 'text-fg-tertiary hover:text-fg-secondary',
                      )}
                    >
                      {platform === p && (
                        <motion.span
                          layoutId="platform-seg"
                          className="absolute inset-0 rounded-[8px] bg-brand-soft"
                          transition={{ type: 'spring', stiffness: 260, damping: 24 }}
                        />
                      )}
                      <span className="relative z-10">{p}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <FieldLabel>计划时长</FieldLabel>
                  <span className="font-mono text-xs text-signal">{plannedMinutes} 分钟</span>
                </div>
                <Slider
                  value={[plannedMinutes]}
                  min={30}
                  max={480}
                  step={10}
                  disabled={isLive || isEnded}
                  onValueChange={([v]) => setPlannedMinutes(v)}
                  aria-label="计划时长"
                />
              </div>

              <div className="space-y-3 rounded-[10px] border border-line bg-ink-input/50 p-3">
                <div className="flex items-center justify-between">
                  <span className="text-[13px] text-fg-secondary">话术循环播报</span>
                  <Switch checked={loopPlay} onCheckedChange={setLoopPlay} disabled={isLive || isEnded} />
                </div>
                {loopPlay && (
                  <div className="flex items-center justify-between border-t border-line pt-3">
                    <span className="text-[13px] text-fg-tertiary">每场循环后随机插入互动话术</span>
                    <Switch
                      checked={insertInteraction}
                      onCheckedChange={setInsertInteraction}
                      disabled={isLive || isEnded}
                    />
                  </div>
                )}
              </div>
            </div>
          </Card>

          {/* ---- OBS 推流信息卡 ---- */}
          <Card
            title="OBS 推流配置"
            icon={<Zap className="h-4 w-4" />}
            extra={
              <span className="flex items-center gap-1.5 text-xs text-fg-tertiary">
                <span
                  className={cn(
                    'h-1.5 w-1.5 rounded-full',
                    isLive ? 'bg-ok animate-live-breathe' : 'bg-fg-tertiary',
                  )}
                />
                {isLive ? '已连接' : '未推流'}
              </span>
            }
          >
            <div className="space-y-4">
              <div>
                <FieldLabel>服务器地址</FieldLabel>
                <div className="flex items-center gap-1">
                  <input
                    className={cn(inputCls, 'font-mono text-[13px]')}
                    value={rtmpUrl}
                    onChange={(e) => setRtmpUrl(e.target.value)}
                    placeholder="rtmp://push.xxx.com/live/"
                    disabled={isLive || isEnded}
                  />
                  <CopyButton
                    text={rtmpUrl || 'rtmp://push.xxx.com/live/'}
                    toastText="已复制，去 OBS 粘贴吧"
                  />
                </div>
              </div>
              <div>
                <FieldLabel>串流密钥</FieldLabel>
                <StreamKeyField
                  value={streamKey}
                  onChange={setStreamKey}
                  disabled={isLive || isEnded}
                />
              </div>

              <div className="space-y-1.5 rounded-[10px] border border-line bg-ink-input/50 p-3">
                <p className="mb-2 flex items-center gap-1.5 text-[13px] font-medium text-fg-secondary">
                  <ListChecks className="h-3.5 w-3.5 text-brand" />
                  开播检查清单
                </p>
                {checklist.map((c) => (
                  <CheckRow
                    key={c.label}
                    label={c.label}
                    checked={c.checked}
                    auto={c.auto}
                    onToggle={c.toggle}
                  />
                ))}
              </div>

              <Link
                to="/tutorial#obs"
                className="flex items-center gap-1.5 text-[13px] text-brand-hover transition-colors hover:underline underline-offset-2"
              >
                <BookOpen className="h-3.5 w-3.5" />
                查看图文教程
              </Link>
            </div>
          </Card>

          {/* ---- 直播控制卡 ---- */}
          <Card title="直播控制" icon={<Play className="h-4 w-4" />}>
            {isLive ? (
              <div className="space-y-3">
                <div className="flex items-center justify-center gap-2 rounded-[10px] bg-[rgba(255,77,109,0.10)] py-3">
                  <span className="h-2 w-2 rounded-full bg-live animate-live-breathe" />
                  <span className="text-sm font-medium text-live">
                    直播中 · 已播 <span className="font-mono">{formatElapsed(elapsedSec)}</span>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfirmStop(true)}
                  disabled={stopMut.isPending}
                  className="flex h-11 w-full items-center justify-center gap-2 rounded-[10px] border border-live/50 text-sm font-medium text-live transition-colors hover:bg-[rgba(255,77,109,0.10)] disabled:opacity-50"
                >
                  {stopMut.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Square className="h-4 w-4" />
                  )}
                  结束直播
                </button>
              </div>
            ) : isEnded ? (
              <div className="space-y-3">
                <div className="rounded-[10px] border border-line bg-ink-input/50 p-3 text-[13px] text-fg-secondary">
                  <p className="mb-1 font-medium text-fg">本场已结束</p>
                  <p className="flex justify-between">
                    <span>开始于</span>
                    <span className="font-mono text-fg-tertiary">
                      {selectedSession?.startedAt
                        ? new Date(selectedSession.startedAt).toLocaleString('zh-CN')
                        : '—'}
                    </span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedId('new')
                    resetForm()
                  }}
                  className="flex h-11 w-full items-center justify-center gap-2 rounded-[10px] text-sm font-medium text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
                >
                  <Plus className="h-4 w-4" />
                  创建下一场
                </button>
              </div>
            ) : (
              <div title={!checklistDone ? '请先完成开播检查清单' : undefined}>
                <motion.button
                  type="button"
                  onClick={handleStart}
                  disabled={connecting || !checklistDone}
                  whileHover={checklistDone && !connecting ? { scale: 1.02 } : undefined}
                  whileTap={checklistDone && !connecting ? { scale: 0.97 } : undefined}
                  className={cn(
                    'flex h-[52px] w-full items-center justify-center gap-2 rounded-[10px] text-[15px] font-bold text-white transition-opacity',
                    checklistDone ? 'bg-live' : 'cursor-not-allowed bg-live/40',
                  )}
                  animate={
                    checklistDone && !connecting && !reduceMotion
                      ? {
                          boxShadow: [
                            '0 0 0 rgba(255,77,109,0)',
                            '0 0 24px rgba(255,77,109,0.45)',
                            '0 0 0 rgba(255,77,109,0)',
                          ],
                        }
                      : { boxShadow: '0 0 0 rgba(255,77,109,0)' }
                  }
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  {connecting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      正在连接推流…
                    </>
                  ) : (
                    <>
                      <Radio className="h-4 w-4" />
                      开始直播
                    </>
                  )}
                </motion.button>
                {!checklistDone && (
                  <p className="mt-2 text-center text-xs text-fg-tertiary">
                    请先完成开播检查清单
                  </p>
                )}
              </div>
            )}
          </Card>

          {/* ---- 实时数据卡 ---- */}
          <Card title="实时数据" icon={<TrendingUp className="h-4 w-4" />}>
            <div className={cn(!isLive && 'pointer-events-none opacity-40')}>
              <div className="grid grid-cols-2 gap-2">
                <StatCell icon={Users} label="当前观看" value={viewers} accent />
                <StatCell icon={TrendingUp} label="新增粉丝" value={fans} />
                <StatCell icon={Heart} label="点赞" value={likes} />
                <StatCell icon={MessageCircle} label="评论数" value={comments} />
              </div>
              <div className="mt-3 h-20">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData.length > 1 ? chartData : [{ t: 0, v: 0 }]}>
                    <defs>
                      <linearGradient id="liveViewers" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#06B6D4" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="#06B6D4" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <Area
                      type="monotone"
                      dataKey="v"
                      stroke="#06B6D4"
                      strokeWidth={1.5}
                      fill="url(#liveViewers)"
                      isAnimationActive={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-3 border-t border-line pt-3">
                <div className="mb-1.5 flex items-center justify-between text-xs">
                  <span className="text-fg-tertiary">
                    本场已消耗 <span className="font-mono text-fg-secondary">{tokensUsed.toLocaleString()}</span> tokens
                  </span>
                  <span className="font-mono text-fg-tertiary">预算 50,000</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-[rgba(30,36,48,0.12)]">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, (tokensUsed / 50000) * 100)}%`,
                      background: 'var(--accent-gradient)',
                    }}
                  />
                </div>
              </div>
            </div>
            {!isLive && (
              <p className="mt-2 text-center text-xs text-fg-tertiary">开播后激活</p>
            )}
          </Card>
        </div>
      </div>

      {/* ===== 结束直播确认 Modal ===== */}
      <AnimatePresence>
        {confirmStop && (
          <ModalShell onClose={() => setConfirmStop(false)}>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[rgba(255,77,109,0.12)]">
                <Square className="h-4 w-4 text-live" />
              </span>
              <div>
                <h3 className="text-[15px] font-semibold text-fg">确定结束直播？</h3>
                <p className="mt-0.5 text-[13px] text-fg-secondary">本场数据将归档。</p>
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmStop(false)}
                className="h-9 rounded-[10px] px-4 text-[13px] font-medium text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
              >
                再播一会
              </button>
              <button
                type="button"
                onClick={handleStop}
                className="h-9 rounded-[10px] bg-live px-4 text-[13px] font-medium text-white transition-opacity hover:opacity-90"
              >
                结束直播
              </button>
            </div>
          </ModalShell>
        )}
      </AnimatePresence>

      {/* ===== 本场复盘 Modal ===== */}
      <AnimatePresence>
        {recap && (
          <ModalShell onClose={() => setRecap(null)}>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-soft">
                <PartyPopper className="h-4 w-4 text-brand-hover" />
              </span>
              <div>
                <h3 className="text-[15px] font-semibold text-fg">本场复盘</h3>
                <p className="mt-0.5 text-[13px] text-fg-secondary">辛苦了，来看看 AI 主播的战绩。</p>
              </div>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <RecapCell label="直播时长" value={recap.duration} mono />
              <RecapCell label="峰值观看" value={recap.peak.toLocaleString()} mono />
              <RecapCell label="互动总量" value={recap.interactions.toLocaleString()} mono />
              <RecapCell label="消耗 Token" value={recap.tokens.toLocaleString()} mono />
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setRecap(null)}
                className="h-9 rounded-[10px] px-4 text-[13px] font-medium text-fg-secondary transition-colors hover:bg-ink-hover hover:text-fg"
              >
                知道了
              </button>
              <button
                type="button"
                onClick={() => navigate('/scripts')}
                className="flex h-9 items-center gap-1.5 rounded-[10px] px-4 text-[13px] font-medium text-white transition-opacity hover:opacity-90"
                style={{ background: 'var(--accent-gradient)' }}
              >
                查看话术表现
              </button>
            </div>
          </ModalShell>
        )}
      </AnimatePresence>
    </div>
  )
}

/* ======================================================================
 * 页面级辅助组件
 * ==================================================================== */

function StatCell({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: typeof Users
  label: string
  value: number
  accent?: boolean
}) {
  return (
    <div className="rounded-[10px] border border-line bg-ink-input/50 p-3">
      <p className="flex items-center gap-1.5 text-xs text-fg-tertiary">
        <Icon className="h-3 w-3" />
        {label}
      </p>
      <div className="relative mt-1 h-7 overflow-hidden">
        <AnimatePresence mode="popLayout">
          <motion.span
            key={value}
            className={cn(
              'absolute font-display text-xl font-bold leading-7',
              accent ? 'text-signal' : 'text-fg',
            )}
            initial={{ y: 8, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -8, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {value.toLocaleString()}
          </motion.span>
        </AnimatePresence>
      </div>
    </div>
  )
}

function RecapCell({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-[10px] border border-line bg-ink-input/50 p-3">
      <p className="text-xs text-fg-tertiary">{label}</p>
      <p className={cn('mt-1 text-lg font-bold text-fg', mono && 'font-display')}>{value}</p>
    </div>
  )
}

/** 串流密钥：密文 + Eye 切换 + 复制 */
function StreamKeyField({
  value,
  onChange,
  disabled,
}: {
  value: string
  onChange: (v: string) => void
  disabled?: boolean
}) {
  const [show, setShow] = useState(false)
  return (
    <div className="flex items-center gap-1">
      <div className="relative flex-1">
        <input
          type={show ? 'text' : 'password'}
          className={cn(inputCls, 'pr-9 font-mono text-[13px]')}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="粘贴平台后台的串流密钥"
          disabled={disabled}
        />
        <button
          type="button"
          onClick={() => setShow((v) => !v)}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-fg-tertiary transition-colors hover:text-fg"
          aria-label={show ? '隐藏密钥' : '显示密钥'}
        >
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
      <CopyButton text={value} toastText="已复制，去 OBS 粘贴吧" />
    </div>
  )
}

/** 居中 Modal 外壳（遮罩 + spring 入场） */
function ModalShell({ children, onClose }: { children: ReactNode; onClose: () => void }) {
  return (
    <motion.div
      className="fixed inset-0 z-[80] flex items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
    >
      <div
        className="absolute inset-0 bg-[rgba(30,36,48,0.45)] backdrop-blur-[4px]"
        onClick={onClose}
      />
      <motion.div
        className="relative w-full max-w-[480px] rounded-[20px] border border-line bg-ink-elevated p-6 shadow-overlay"
        initial={{ scale: 0.96, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.96, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 260, damping: 24 }}
      >
        {children}
      </motion.div>
    </motion.div>
  )
}
