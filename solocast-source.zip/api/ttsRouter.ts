import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";
import { createRouter, authedQuery } from "./middleware";

/** 常用中文音色白名单（与设置页可选项一致，外加兜底） */
const ALLOWED_VOICES = new Set([
  "zh-CN-XiaoxiaoNeural",
  "zh-CN-YunjianNeural",
  "zh-CN-XiaoyiNeural",
  "zh-CN-YunxiNeural",
  "zh-CN-XiaoxiaoMultilingualNeural",
  "zh-CN-liaoning-XiaobeiNeural",
  "zh-CN-shaanxi-XiaoniNeural",
]);

async function synthesize(text: string, voice: string, rate: number): Promise<Buffer> {
  const tts = new MsEdgeTTS();
  try {
    await tts.setMetadata(voice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);
    // msedge-tts 的 rate 为相对偏移：0 = 默认语速，0.2 = +20%
    const edgeRate = Math.min(1, Math.max(-0.5, rate - 1));
    const { audioStream } = await tts.toStream(text, { rate: edgeRate });
    const chunks: Buffer[] = [];
    for await (const chunk of audioStream) {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    }
    const audio = Buffer.concat(chunks);
    if (audio.length === 0) {
      throw new Error("empty audio");
    }
    return audio;
  } finally {
    try {
      await tts.close();
    } catch {
      // 忽略关闭异常
    }
  }
}

export const ttsRouter = createRouter({
  /**
   * 试听语音：调用微软 Edge TTS 在线服务合成中文语音，返回 base64 MP3。
   * 免费通道，适合一人公司零成本试听；高并发商用建议换正式 TTS 服务。
   */
  preview: authedQuery
    .input(
      z.object({
        text: z.string().min(1, "试听文本不能为空").max(300, "试听文本最多 300 字"),
        voice: z.string().max(64),
        rate: z.number().min(0.5).max(2).default(1),
      }),
    )
    .mutation(async ({ input }) => {
      const voice = ALLOWED_VOICES.has(input.voice) ? input.voice : "zh-CN-XiaoxiaoNeural";
      try {
        const audio = await synthesize(input.text, voice, input.rate);
        return { audioBase64: audio.toString("base64"), mime: "audio/mpeg" };
      } catch (err) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message:
            "语音合成服务暂时不可用，请稍后重试（Edge TTS 为免费通道，偶发限流）",
          cause: err,
        });
      }
    }),

  /** 可用音色列表（供前端展示） */
  voices: authedQuery.query(() => ({
    voices: [
      { id: "zh-CN-XiaoxiaoNeural", name: "晨曦", desc: "女声 · 亲切活泼，直播带货常用" },
      { id: "zh-CN-YunjianNeural", name: "云舟", desc: "男声 · 磁性稳重，数码家电合适" },
      { id: "zh-CN-XiaoyiNeural", name: "小满", desc: "女声 · 温柔知性，美妆个护合适" },
      { id: "zh-CN-YunxiNeural", name: "老白", desc: "男声 · 年轻轻快，食品百货合适" },
    ],
  })),
});
